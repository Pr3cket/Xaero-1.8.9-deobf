package xaero.patreon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.Cipher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.util.ResourceLocation;
import xaero.patreon.decrypt.DecryptInputStream;

public class Patreon7 {
   private static boolean hasAutoUpdates;
   private static int onlineWidgetLevel;
   public static boolean notificationDisplayed;
   public static boolean loaded = false;
   public static String updateLocation;
   public static HashMap<String, PatreonMod4> mods = new HashMap();
   private static ArrayList<PatreonMod4> outdatedMods = new ArrayList();
   public static Cipher cipher = null;
   public static int KEY_VERSION = 2;
   public static String publicKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqg2aSbG53XaP+1b8kcP2x3hukI5WRWI6W+SzrLCIpAErFZGzzhkPuIPEwAie1hK0i6gBuGE4H47pF7dfaL8w53NzxSqVLzRbgzIcCf0VIhW4PfAmyBFsTQcrGJZESSWCxyj6aG5ERSqEualXycum6/v2d9Ux5tXTElnJDttEr/cBB37dJBisjJjlzQeVtnS7VMD2/WVGSVsI5MRzEZT4WEW6b81DaJT9Hoy0nJIEIYEAxPYRNwOhEJahfFiOXcx0YWYGqeuuyKpBeKkkGc7VnTaQNaZtoUJPo7a2Dp/XRhJ/vCzixbymMnaPT+OVlnGGfXxM5z9nb8pp9hQfoGidsQIDAQAB";
   public static File optionsFile;

   public static void checkPatreon() {
      synchronized(mods) {
         if (!loaded) {
            loadSettings();
            String s = "http://data.chocolateminecraft.com/Versions_" + KEY_VERSION + "/Patreon2.txt";
            s = s.replaceAll(" ", "%20");

            try {
               URL url = new URL(s);
               URLConnection conn = url.openConnection();
               conn.setReadTimeout(900);
               conn.setConnectTimeout(900);
               if (conn.getContentLengthLong() > 524288L) {
                  throw new IOException("Input too long to trust!");
               }

               BufferedReader reader = new BufferedReader(new InputStreamReader(new DecryptInputStream(conn.getInputStream(), cipher)));
               boolean parsingPatrons = false;
               String localPlayerName = Minecraft.func_71410_x().func_110432_I().func_148256_e().getName();

               while(true) {
                  String line;
                  String[] rewards;
                  while((line = reader.readLine()) != null && !line.equals("LAYOUTS")) {
                     if (line.startsWith("PATREON")) {
                        parsingPatrons = true;
                     } else if (parsingPatrons) {
                        rewards = line.split(";");
                        if (rewards.length > 1 && rewards[0].equalsIgnoreCase(localPlayerName)) {
                           for(int i = 1; i < rewards.length; ++i) {
                              String rewardString = rewards[i].trim();
                              if ("updates".equals(rewardString)) {
                                 hasAutoUpdates = true;
                              } else {
                                 String[] keyAndValue = rewardString.split(":");
                                 if (keyAndValue.length >= 2 && keyAndValue[0].equals("widget_level")) {
                                    try {
                                       onlineWidgetLevel = Integer.parseInt(keyAndValue[1]);
                                    } catch (NumberFormatException var19) {
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }

                  updateLocation = reader.readLine();

                  while((line = reader.readLine()) != null) {
                     rewards = line.split("\\t");
                     mods.put(rewards[0], new PatreonMod4(rewards[0], rewards[1], rewards[2], rewards[3]));
                  }

                  reader.close();
                  break;
               }
            } catch (Throwable var20) {
               var20.printStackTrace();
               mods.clear();
            } finally {
               loaded = true;
            }

         }
      }
   }

   public static void addOutdatedMod(PatreonMod4 mod) {
      synchronized(getOutdatedMods()) {
         getOutdatedMods().add(mod);
      }
   }

   /** @deprecated */
   @Deprecated
   public static int getPatronPledge(String name) {
      return -1;
   }

   public static void saveSettings() {
      try {
         PrintWriter writer = new PrintWriter(new FileWriter(optionsFile));
         writer.close();
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public static void loadSettings() {
      try {
         if (!optionsFile.exists()) {
            saveSettings();
            return;
         }

         BufferedReader reader;
         String line;
         String[] var2;
         for(reader = new BufferedReader(new FileReader(optionsFile)); (line = reader.readLine()) != null; var2 = line.split(":")) {
         }

         reader.close();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

   }

   /** @deprecated */
   @Deprecated
   public static ResourceLocation getPlayerCape(String modID, AbstractClientPlayer playerEntity) {
      return null;
   }

   /** @deprecated */
   @Deprecated
   public static Boolean isWearingCape(String modID, AbstractClientPlayer playerEntity) {
      return null;
   }

   public static ArrayList<PatreonMod4> getOutdatedMods() {
      return outdatedMods;
   }

   public static boolean needsNotification() {
      return !notificationDisplayed && !outdatedMods.isEmpty();
   }

   public static boolean getHasAutoUpdates() {
      return hasAutoUpdates;
   }

   public static int getOnlineWidgetLevel() {
      return onlineWidgetLevel;
   }

   static {
      try {
         cipher = Cipher.getInstance("RSA");
         KeyFactory factory = KeyFactory.getInstance("RSA");
         byte[] byteKey = Base64.getDecoder().decode(publicKeyString.getBytes());
         X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
         PublicKey publicKey = factory.generatePublic(X509publicKey);
         cipher.init(2, publicKey);
      } catch (Exception var4) {
         cipher = null;
         var4.printStackTrace();
      }

      optionsFile = new File("./config/xaeropatreon.txt");
   }
}
