package xaero.patreon;

import java.awt.Desktop;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import org.apache.commons.codec.binary.Hex;

public class GuiUpdateAll3 extends GuiYesNo {
   public GuiUpdateAll3() {
      super((GuiYesNoCallback)null, "These mods are out-of-date: " + modListToNames(Patreon7.getOutdatedMods()), Patreon7.getHasAutoUpdates() ? "Would you like to automatically update them?" : "Would you like to update them (open the mod pages)?", 0);
      Patreon7.notificationDisplayed = true;
   }

   private static String modListToNames(List<PatreonMod4> list) {
      StringBuilder builder = new StringBuilder();

      for(int i = 0; i < list.size(); ++i) {
         if (i != 0) {
            builder.append(", ");
         }

         builder.append(((PatreonMod4)list.get(i)).modName);
      }

      return builder.toString();
   }

   public void func_73866_w_() {
      super.func_73866_w_();
      if (Patreon7.getHasAutoUpdates()) {
         this.field_146292_n.add(new GuiButton(201, this.field_146294_l / 2 - 100, this.field_146295_m / 6 + 120, "Changelogs"));
      }

      this.field_146292_n.add(new GuiButton(202, this.field_146294_l / 2 - 100, this.field_146295_m / 6 + 144, "Don't show again for these updates"));
   }

   protected void func_146284_a(GuiButton button) throws IOException {
      int i;
      PatreonMod4 m;
      Desktop d;
      switch(button.field_146127_k) {
      case 0:
         boolean shouldExit = false;
         if (!Patreon7.getHasAutoUpdates()) {
            shouldExit = true;

            for(i = 0; i < Patreon7.getOutdatedMods().size(); ++i) {
               m = (PatreonMod4)Patreon7.getOutdatedMods().get(i);

               try {
                  d = Desktop.getDesktop();
                  d.browse(new URI(m.changelogLink));
                  if (m.modJar != null) {
                     d.open(m.modJar.getParentFile());
                  }
               } catch (Exception var7) {
                  var7.printStackTrace();
                  shouldExit = false;
               }
            }
         } else {
            GuiButton b;
            for(Iterator var8 = this.field_146292_n.iterator(); var8.hasNext(); b.field_146124_l = false) {
               b = (GuiButton)var8.next();
            }

            shouldExit = this.autoUpdate();
         }

         if (shouldExit) {
            Minecraft.func_71410_x().func_71400_g();
         } else {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)null);
         }
         break;
      case 1:
         this.field_146297_k.func_147108_a((GuiScreen)null);
         break;
      case 201:
         for(i = 0; i < Patreon7.getOutdatedMods().size(); ++i) {
            m = (PatreonMod4)Patreon7.getOutdatedMods().get(i);

            try {
               d = Desktop.getDesktop();
               d.browse(new URI(m.changelogLink));
            } catch (URISyntaxException var6) {
               var6.printStackTrace();
            }
         }

         return;
      case 202:
         for(i = 0; i < Patreon7.getOutdatedMods().size(); ++i) {
            m = (PatreonMod4)Patreon7.getOutdatedMods().get(i);
            if (m.onVersionIgnore != null) {
               m.onVersionIgnore.run();
            }
         }

         this.field_146297_k.func_147108_a((GuiScreen)null);
      }

   }

   private static void download(BufferedOutputStream output, InputStream input, boolean closeInput) throws IOException {
      byte[] buffer = new byte[256];

      while(true) {
         int read = input.read(buffer, 0, buffer.length);
         if (read < 0) {
            output.flush();
            if (closeInput) {
               input.close();
            }

            output.close();
            return;
         }

         output.write(buffer, 0, read);
      }
   }

   public boolean autoUpdate() {
      try {
         MessageDigest digestMD5;
         try {
            digestMD5 = MessageDigest.getInstance("MD5");
         } catch (NoSuchAlgorithmException var21) {
            System.out.println("No algorithm for MD5.");
            return false;
         }

         PatreonMod4 autoupdater = (PatreonMod4)Patreon7.mods.get("autoupdater30");
         String jarLink = autoupdater.changelogLink;
         String jarMD5 = autoupdater.latestVersionLayout;
         URL url = new URL(jarLink);
         HttpURLConnection conn = (HttpURLConnection)url.openConnection();
         conn.setReadTimeout(900);
         conn.setConnectTimeout(900);
         conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11");
         if (conn.getContentLengthLong() > 2097152L) {
            throw new IOException("Input too long to trust!");
         } else {
            InputStream input = conn.getInputStream();
            InputStream input = new BufferedInputStream(input);
            DigestInputStream digestInput = new DigestInputStream(input, digestMD5);
            BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(new File("./xaero_autoupdater.jar")));
            download(output, digestInput, true);
            byte[] digest = digestMD5.digest();
            String fileMD5 = Hex.encodeHexString(digest);
            if (!jarMD5.equals(fileMD5)) {
               System.out.println("Invalid autoupdater MD5: " + fileMD5);
               return false;
            } else {
               ArrayList<String> command = new ArrayList();
               Path javaPath = (new File(System.getProperty("java.home"))).toPath().resolve("bin").resolve("java");
               command.add(javaPath.toString());
               command.add("-jar");
               command.add("./xaero_autoupdater.jar");
               command.add("6");
               command.add(Patreon7.updateLocation);

               for(int i = 0; i < Patreon7.getOutdatedMods().size(); ++i) {
                  PatreonMod4 m = (PatreonMod4)Patreon7.getOutdatedMods().get(i);
                  if (m.modJar != null) {
                     int canonicalPathAttempts = 10;
                     String jarPath = null;

                     while(canonicalPathAttempts-- > 0) {
                        try {
                           jarPath = m.modJar.getCanonicalPath();
                           break;
                        } catch (IOException var22) {
                           System.out.println("IO exception fetching the canonical path to the mod jar!");
                           if (canonicalPathAttempts == 0) {
                              throw var22;
                           }

                           var22.printStackTrace();
                           System.out.println("Retrying... (" + canonicalPathAttempts + ")");

                           try {
                              Thread.sleep(25L);
                           } catch (InterruptedException var20) {
                           }
                        }
                     }

                     command.add(jarPath);
                     command.add(m.latestVersionLayout);
                     command.add(m.currentVersion.split("_")[1]);
                     command.add(m.latestVersion);
                     command.add(m.currentVersion.split("_")[0]);
                     command.add(m.md5 == null ? "null" : m.md5);
                  }
               }

               System.out.println(String.join(", ", command));
               Runtime.getRuntime().exec((String[])command.toArray(new String[0]));
               return true;
            }
         }
      } catch (IOException var23) {
         var23.printStackTrace();
         return false;
      }
   }
}
