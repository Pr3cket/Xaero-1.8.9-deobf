package xaero.map;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import xaero.map.cache.BlockStateColorTypeCache;
import xaero.map.controls.ControlsHandler;
import xaero.map.core.IWorldMapClientPlayNetHandler;
import xaero.map.core.XaeroWorldMapCore;
import xaero.map.file.MapSaveLoad;
import xaero.map.file.worldsave.WorldDataHandler;
import xaero.map.file.worldsave.WorldDataReader;
import xaero.map.graphics.TextureUploader;

public class WorldMapSession {
   private ControlsHandler controlsHandler;
   private MapProcessor mapProcessor;
   private MapWriter mapWriter;
   private boolean usable;

   public void init() throws NoSuchFieldException {
      MapSaveLoad mapSaveLoad = new MapSaveLoad(WorldMap.overlayManager, WorldMap.pngExporter);
      TextureUploader textureUploader = new TextureUploader(WorldMap.normalTextureUploadPool, WorldMap.normalWithDownloadTextureUploadPool, WorldMap.compressedTextureUploadPool, WorldMap.branchUpdatePool, WorldMap.branchUpdateAllocatePool, WorldMap.branchDownloadPool, WorldMap.textureUploadBenchmark);
      BlockStateColorTypeCache blockStateColorTypeCache = new BlockStateColorTypeCache();
      blockStateColorTypeCache.updateGrassColor();
      WorldDataReader worldDataReader = new WorldDataReader(WorldMap.overlayManager, blockStateColorTypeCache);
      WorldDataHandler worldDataHandler = new WorldDataHandler(worldDataReader);
      this.mapWriter = new MapWriter(WorldMap.overlayManager, blockStateColorTypeCache);
      this.mapProcessor = new MapProcessor(mapSaveLoad, this.mapWriter, WorldMap.mapLimiter, WorldMap.bufferDeallocator, WorldMap.tilePool, WorldMap.overlayManager, textureUploader, worldDataHandler, WorldMap.mapBiomes, WorldMap.branchTextureRenderer);
      this.mapWriter.setMapProcessor(this.mapProcessor);
      mapSaveLoad.setMapProcessor(this.mapProcessor);
      worldDataReader.setMapProcessor(this.mapProcessor);
      this.controlsHandler = new ControlsHandler(this.mapProcessor);
      this.mapProcessor.onInit();
      this.usable = true;
      System.out.println("New world map session initialized!");
   }

   public void cleanup() {
      try {
         if (this.usable) {
            this.mapProcessor.stop();
            System.out.println("Finalizing world map session...");
            WorldMap.mapRunnerThread.interrupt();

            while(!this.mapProcessor.isFinished()) {
               try {
                  Thread.sleep(20L);
               } catch (InterruptedException var2) {
                  var2.printStackTrace();
               }
            }
         }

         System.out.println("World map session finalized.");
      } catch (Throwable var3) {
         System.out.println("World map session failed to finalize properly.");
         var3.printStackTrace();
      }

      this.usable = false;
   }

   public ControlsHandler getControlsHandler() {
      return this.controlsHandler;
   }

   public MapProcessor getMapProcessor() {
      return this.mapProcessor;
   }

   public static WorldMapSession getCurrentSession() {
      WorldMapSession session = getForPlayer(Minecraft.func_71410_x().field_71439_g);
      if (session == null && XaeroWorldMapCore.currentSession != null && XaeroWorldMapCore.currentSession.usable) {
         session = XaeroWorldMapCore.currentSession;
      }

      return session;
   }

   public static WorldMapSession getForPlayer(EntityPlayerSP player) {
      return player != null && player.field_71174_a != null ? ((IWorldMapClientPlayNetHandler)player.field_71174_a).getXaero_worldmapSession() : null;
   }

   public boolean isUsable() {
      return this.usable;
   }
}
