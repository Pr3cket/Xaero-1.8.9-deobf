package xaero.map;

public class BlockPos {
   private int x;
   private int y;
   private int z;

   public BlockPos() {
   }

   public BlockPos(int x, int y, int z) {
      this.x = x;
      this.y = y;
      this.z = z;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public String toString() {
      return "[" + this.x + ", " + this.y + ", " + this.z + "]";
   }

   public void setPos(int x, int y, int z) {
      this.x = x;
      this.y = y;
      this.z = z;
   }

   public boolean equals(int x, int y, int z) {
      return this.x == x && this.y == y && this.z == z;
   }

   public boolean equals(Object otherObject) {
      if (this == otherObject) {
         return true;
      } else if (!(otherObject instanceof BlockPos)) {
         return false;
      } else {
         BlockPos other = (BlockPos)otherObject;
         return this.getX() == other.getX() && this.getY() == other.getY() && this.getZ() == other.getZ();
      }
   }
}
