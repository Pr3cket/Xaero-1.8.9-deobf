package xaero.map.pool;

public interface PoolUnit {
   void create(Object... var1);
}
