package xaero.map;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldProviderHell;
import net.minecraft.world.chunk.Chunk;
import org.lwjgl.opengl.GL11;
import xaero.deallocator.ByteBufferDeallocator;
import xaero.map.biome.MapBiomes;
import xaero.map.controls.ControlsRegister;
import xaero.map.file.MapSaveLoad;
import xaero.map.file.RegionDetection;
import xaero.map.file.worldsave.WorldDataHandler;
import xaero.map.graphics.TextureUploader;
import xaero.map.gui.GuiMap;
import xaero.map.mcworld.WorldMapClientWorldData;
import xaero.map.mcworld.WorldMapClientWorldDataHelper;
import xaero.map.misc.Misc;
import xaero.map.pool.MapTilePool;
import xaero.map.region.LeveledRegion;
import xaero.map.region.LeveledRegionManager;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTile;
import xaero.map.region.MapTileChunk;
import xaero.map.region.OverlayManager;
import xaero.map.region.texture.BranchTextureRenderer;
import xaero.map.region.texture.RegionTexture;
import xaero.map.task.MapRunnerTask;
import xaero.map.world.MapDimension;
import xaero.map.world.MapWorld;

public class MapProcessor {
   public static final int DEFAULT_LIGHT_LEVELS = 4;
   private MapSaveLoad mapSaveLoad;
   private MapWriter mapWriter;
   private MapLimiter mapLimiter;
   private WorldDataHandler worldDataHandler;
   private ByteBufferDeallocator bufferDeallocator;
   private TextureUploader textureUploader;
   private BranchTextureRenderer branchTextureRenderer;
   private WorldClient world;
   private WorldClient newWorld;
   public final Object mainStuffSync;
   public WorldClient mainWorld;
   public double mainPlayerX;
   public double mainPlayerY;
   public double mainPlayerZ;
   private boolean mainWorldUnloaded;
   private ArrayList<Double[]> footprints = new ArrayList();
   private int footprintsTimer;
   private boolean mapWorldUsable;
   private MapWorld mapWorld;
   private String currentWorldId;
   private String currentDimId;
   private String currentMWId;
   private boolean mapWorldUsableRequest;
   private boolean caveStartDetermined;
   private int caveStart;
   public final Object renderThreadPauseSync = new Object();
   private int pauseUploading;
   private int pauseRendering;
   private int pauseWriting;
   public final Object processorThreadPauseSync = new Object();
   private int pauseProcessing;
   public final Object loadingSync = new Object();
   public final Object uiSync = new Object();
   private boolean waitingForWorldUpdate;
   private ArrayList<LeveledRegion<?>>[] toProcessLevels;
   private ArrayList<MapRegion> toRefresh = new ArrayList();
   private static final int SPAWNPOINT_TIMEOUT = 3000;
   private net.minecraft.util.BlockPos spawnToRestore;
   private long mainWorldChangedTime = -1L;
   private MapTilePool tilePool;
   private int firstBranchLevel;
   private long lastRenderProcessTime = -1L;
   private int workingFramesCount;
   public long freeFramePeriod = -1L;
   private int testingFreeFrame = 1;
   private boolean currentMapNeedsDeletion;
   private OverlayManager overlayManager;
   private MapBiomes mapBiomes;
   private long renderStartTime;
   private Field scheduledTasksField;
   private Callable<Object> renderStartTimeUpdater;
   private boolean finalizing;
   private int state;
   private String[] dimensionsToIgnore = new String[]{"FZHammer"};
   public Field selectedField = null;

   public MapProcessor(MapSaveLoad mapSaveLoad, MapWriter mapWriter, MapLimiter mapLimiter, ByteBufferDeallocator bufferDeallocator, MapTilePool tilePool, OverlayManager overlayManager, TextureUploader textureUploader, WorldDataHandler worldDataHandler, MapBiomes mapBiomes, BranchTextureRenderer branchTextureRenderer) throws NoSuchFieldException {
      this.branchTextureRenderer = branchTextureRenderer;
      this.mapSaveLoad = mapSaveLoad;
      this.mapWriter = mapWriter;
      this.mapLimiter = mapLimiter;
      this.bufferDeallocator = bufferDeallocator;
      this.tilePool = tilePool;
      this.overlayManager = overlayManager;
      this.textureUploader = textureUploader;
      this.worldDataHandler = worldDataHandler;
      this.mapBiomes = mapBiomes;

      try {
         this.scheduledTasksField = Minecraft.class.getDeclaredField("field_152351_aB");
      } catch (NoSuchFieldException var15) {
         try {
            this.scheduledTasksField = Minecraft.class.getDeclaredField("scheduledTasks");
         } catch (NoSuchFieldException var13) {
            throw var13;
         } catch (SecurityException var14) {
            throw var14;
         }
      } catch (SecurityException var16) {
         throw var16;
      }

      Runnable renderStartTimeUpdaterRunnable = new Runnable() {
         public void run() {
            MapProcessor.this.updateRenderStartTime();
         }
      };
      this.renderStartTimeUpdater = Executors.callable(renderStartTimeUpdaterRunnable);
      this.mainStuffSync = new Object();
      this.caveStart = -1;
      this.toProcessLevels = new ArrayList[4];

      for(int i = 0; i < this.toProcessLevels.length; ++i) {
         this.toProcessLevels[i] = new ArrayList();
      }

   }

   public void onInit() {
      String mainId = this.getMainId(true, false);
      this.fixIPv6Folder(mainId);
      this.mapWorld = new MapWorld(mainId, this.getMainId(false, false), this);
      this.mapWorld.load();
   }

   public void run(MapRunner runner) {
      if (this.state < 2) {
         while(true) {
            try {
               if (this.state < 2 && WorldMap.crashHandler.getCrashedBy() == null) {
                  synchronized(this.processorThreadPauseSync) {
                     if (!this.isProcessingPaused()) {
                        this.updateWorld();
                        if (this.world != null) {
                           this.updateCaveStart(this.mainPlayerX, this.mainPlayerZ, this.world);
                           this.updateFootprints(this.world, Minecraft.func_71410_x().field_71462_r instanceof GuiMap ? 1 : 10);
                        }

                        if (this.mapWorldUsable) {
                           this.mapLimiter.applyLimit(this.mapWorld, this);
                           long currentTime = System.currentTimeMillis();

                           for(int l = 0; l < this.toProcessLevels.length; ++l) {
                              ArrayList<LeveledRegion<?>> regionsToProcess = this.toProcessLevels[l];

                              for(int i = 0; i < regionsToProcess.size(); ++i) {
                                 LeveledRegion leveledRegion;
                                 synchronized(regionsToProcess) {
                                    if (i >= regionsToProcess.size()) {
                                       break;
                                    }

                                    leveledRegion = (LeveledRegion)regionsToProcess.get(i);
                                 }

                                 this.mapSaveLoad.updateSave(leveledRegion, currentTime);
                              }
                           }
                        }

                        this.mapSaveLoad.run(this.world);
                        this.handleRefresh(this.world);
                        runner.doTasks(this);
                     }
                  }

                  try {
                     Thread.sleep(this.world != null && !Misc.screenShouldSkipWorldRender(Minecraft.func_71410_x().field_71462_r, true) && this.state <= 0 ? 1000L : 40L);
                  } catch (InterruptedException var12) {
                  }
                  continue;
               }
            } catch (Throwable var15) {
               WorldMap.crashHandler.setCrashedBy(var15);
            }

            if (this.state < 2) {
               this.forceClean();
            }
            break;
         }
      }

      if (this.state == 2) {
         this.state = 3;
      }

   }

   public void onRenderProcess(Minecraft mc, ScaledResolution scaledRes) throws RuntimeException {
      try {
         this.mapWriter.onRender();
         long renderProcessTime = System.nanoTime();
         if (this.testingFreeFrame == 1) {
            this.testingFreeFrame = 2;
         } else {
            synchronized(this.renderThreadPauseSync) {
               if (this.lastRenderProcessTime == -1L) {
                  this.lastRenderProcessTime = renderProcessTime;
               }

               long sinceLastProcessTime = renderProcessTime - this.lastRenderProcessTime;
               if (this.testingFreeFrame == 2) {
                  this.freeFramePeriod = sinceLastProcessTime;
                  this.testingFreeFrame = 0;
               }

               if (this.pauseUploading == 0 && this.mapWorldUsable && this.currentWorldId != null) {
                  while(true) {
                     if (GL11.glGetError() == 0) {
                        GlStateManager.func_179082_a(0.0F, 0.0F, 0.0F, 0.0F);
                        GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
                        GL11.glPixelStorei(3317, 4);
                        GL11.glPixelStorei(3316, 0);
                        GL11.glPixelStorei(3315, 0);
                        GL11.glPixelStorei(3314, 0);
                        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                        int globalRegionCacheHashCode = WorldMap.settings.getRegionCacheHashCode();
                        boolean detailedDebug = WorldMap.settings.detailed_debug;
                        long uploadStart = System.nanoTime();
                        long totalTime = Math.min(sinceLastProcessTime, this.freeFramePeriod);
                        long passed = uploadStart - this.renderStartTime;
                        long timeAvailable = Math.max(3000000L, totalTime - passed);
                        long uploadUntil = uploadStart + timeAvailable / 4L;
                        long gpuLimit = Minecraft.func_71410_x().field_71462_r instanceof GuiMap ? Math.max(1000000L, totalTime * 5L / 12L) : Math.min(totalTime / 5L, timeAvailable);
                        int firstLevel = 0;
                        boolean branchesCatchup = (int)(Math.random() * 5.0D) == 0;
                        if (branchesCatchup) {
                           firstLevel = 1 + this.firstBranchLevel;
                        }

                        this.firstBranchLevel = (this.firstBranchLevel + 1) % (this.toProcessLevels.length - 1);

                        for(int j = 0; j < this.toProcessLevels.length; ++j) {
                           int level = (firstLevel + j) % this.toProcessLevels.length;
                           ArrayList<LeveledRegion<?>> toProcess = this.toProcessLevels[level];

                           for(int i = 0; i < toProcess.size(); ++i) {
                              LeveledRegion region;
                              synchronized(toProcess) {
                                 if (i >= toProcess.size()) {
                                    break;
                                 }

                                 region = (LeveledRegion)toProcess.get(i);
                              }

                              if (region != null) {
                                 synchronized(region) {
                                    if (region.shouldBeProcessed()) {
                                       boolean cleanAndCacheRequestsBlocked = region.cleanAndCacheRequestsBlocked();
                                       boolean allCleaned = true;
                                       boolean allCached = true;
                                       boolean allUploaded = true;
                                       boolean isEmpty = true;
                                       boolean hasLoadedChunks = false;

                                       for(int x = 0; x < 8; ++x) {
                                          for(int z = 0; z < 8; ++z) {
                                             RegionTexture texture = region.getTexture(x, z);
                                             if (texture != null) {
                                                isEmpty = false;
                                                if (texture.canUpload()) {
                                                   hasLoadedChunks = true;
                                                   if (gpuLimit > 0L && System.nanoTime() < uploadUntil) {
                                                      texture.preUpload(this, region, detailedDebug);
                                                      if (texture.shouldUpload()) {
                                                         if (texture.getTimer() == 0) {
                                                            gpuLimit -= texture.uploadBuffer(this.textureUploader, region, this.branchTextureRenderer, x, z, scaledRes);
                                                         } else {
                                                            texture.decTimer();
                                                         }
                                                      }
                                                   }

                                                   texture.postUpload(this, region, cleanAndCacheRequestsBlocked);
                                                }

                                                if (texture.hasSourceData()) {
                                                   allCleaned = false;
                                                }

                                                if (!texture.isCachePrepared()) {
                                                   allCached = false;
                                                }

                                                if (!texture.isUploaded()) {
                                                   allUploaded = false;
                                                }
                                             }
                                          }
                                       }

                                       if (hasLoadedChunks) {
                                          region.processWhenLoadedChunksExist(globalRegionCacheHashCode);
                                       }

                                       allUploaded = allUploaded && region.isLoaded() && !cleanAndCacheRequestsBlocked;
                                       allCached = allCached && allUploaded && !isEmpty;
                                       if ((!region.shouldCache() || !region.recacheHasBeenRequested()) && region.shouldEndProcessingAfterUpload() && allCleaned && allUploaded) {
                                          region.onProcessingEnd();
                                          region.deleteGLBuffers();
                                          synchronized(toProcess) {
                                             if (i < toProcess.size()) {
                                                toProcess.remove(i);
                                                --i;
                                             }
                                          }

                                          if (WorldMap.settings.debug) {
                                             System.out.println("Region freed: " + region + " " + this.mapWriter.getUpdateCounter() + " " + this.currentWorldId + " " + this.currentDimId);
                                          }
                                       }

                                       if (allCached && !region.isAllCachePrepared()) {
                                          region.setAllCachePrepared(true);
                                       }

                                       if (region.shouldCache() && region.recacheHasBeenRequested() && region.isAllCachePrepared() && !cleanAndCacheRequestsBlocked) {
                                          this.getMapSaveLoad().requestCache(region);
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        ++this.workingFramesCount;
                        if (this.workingFramesCount >= 30) {
                           this.testingFreeFrame = 1;
                           this.workingFramesCount = 0;
                        }

                        this.textureUploader.uploadTextures();
                        break;
                     }
                  }
               }
            }
         }

         this.mapLimiter.updateAvailableVRAM();
         this.lastRenderProcessTime = renderProcessTime;
      } catch (Throwable var46) {
         WorldMap.crashHandler.setCrashedBy(var46);
      }

      WorldMap.crashHandler.checkForCrashes();
   }

   public boolean ignoreWorld(World world) {
      for(int i = 0; i < this.dimensionsToIgnore.length; ++i) {
         if (this.dimensionsToIgnore[i].equals(world.field_73011_w.func_80007_l())) {
            return true;
         }
      }

      return false;
   }

   public String getDimensionName(int id) {
      String name = "null";
      if (id != 0) {
         name = "DIM" + id;
      }

      return name;
   }

   public String getDimensionLegacyName(WorldProvider worldProvider) {
      String legacyName = worldProvider.getSaveFolder();
      if (legacyName != null) {
         legacyName = legacyName.replaceAll("_", "^us^");
      }

      return legacyName;
   }

   public synchronized void changeWorld(WorldClient world) {
      this.pushWriterPause();
      synchronized(this.loadingSync) {
         this.waitingForWorldUpdate = true;
      }

      this.newWorld = world;
      if (world == null) {
         this.mapWorldUsableRequest = false;
      } else {
         this.mapWorldUsableRequest = true;
         int dimId = world.field_73011_w.func_177502_q();
         Object autoIdBase = this.getAutoIdBase(world);
         MapDimension mapDimension = this.mapWorld.getDimension(dimId);
         if (mapDimension == null) {
            mapDimension = this.mapWorld.createDimensionUnsynced(world, dimId);
         }

         this.mapWorld.setFutureDimensionId(dimId);
         mapDimension.updateFutureAutomaticUnsynced(Minecraft.func_71410_x(), autoIdBase);
         mapDimension.resetCustomMultiworldUnsynced();
      }

      this.popWriterPause();
   }

   private String getMainId(boolean rootFolderFormat, boolean preIP6Fix) {
      Minecraft mc = Minecraft.func_71410_x();
      String result = null;
      if (mc.func_71401_C() != null) {
         result = mc.func_71401_C().func_71270_I().replaceAll("_", "^us^");
         if (this.isWorldMultiplayer(this.isWorldRealms(result), result)) {
            result = "^e^" + result;
         }
      } else if (mc.func_147104_D() != null) {
         String serverIP = WorldMap.settings.differentiateByServerAddress ? mc.func_147104_D().field_78845_b : "Any Address";
         int portDivider;
         if (rootFolderFormat && !preIP6Fix && serverIP.indexOf(":") != serverIP.lastIndexOf(":")) {
            portDivider = serverIP.lastIndexOf("]:") + 1;
         } else {
            portDivider = serverIP.indexOf(":");
         }

         if (portDivider > 0) {
            serverIP = serverIP.substring(0, portDivider);
         }

         while(rootFolderFormat && serverIP.endsWith(".")) {
            serverIP = serverIP.substring(0, serverIP.length() - 1);
         }

         result = "Multiplayer_" + serverIP.replaceAll(":", "§");
      } else {
         result = "Multiplayer_Unknown";
      }

      return result;
   }

   public synchronized void toggleMultiworldType(MapDimension dim) {
      if (this.mapWorldUsable && !this.waitingForWorldUpdate && this.mapWorld.isMultiplayer() && this.mapWorld.getCurrentDimension() == dim) {
         this.mapWorld.toggleMultiworldTypeUnsynced();
      }

   }

   public synchronized void quickConfirmMultiworld() {
      if (this.mapWorldUsable && this.mapWorld.getCurrentDimension().hasConfirmedMultiworld()) {
         this.confirmMultiworld(this.mapWorld.getCurrentDimension());
      }

   }

   public synchronized boolean confirmMultiworld(MapDimension dim) {
      if (this.mapWorldUsable && this.mapWorld.isMultiplayer() && this.mainWorld != null && this.mainWorld.field_73011_w.func_177502_q() == this.mapWorld.getCurrentDimensionId() && this.mapWorld.getCurrentDimension() == dim) {
         this.mapWorld.confirmMultiworldTypeUnsynced();
         this.mapWorld.getCurrentDimension().confirmMultiworldUnsynced();
         return true;
      } else {
         return false;
      }
   }

   public synchronized void setMultiworld(MapDimension dimToCompare, String customMW) {
      if (this.mapWorldUsable && this.mapWorld.isMultiplayer() && dimToCompare == this.mapWorld.getCurrentDimension()) {
         this.mapWorld.getCurrentDimension().setMultiworldUnsynced(customMW);
      }

   }

   public String getCrosshairMessage() {
      synchronized(this.uiSync) {
         if (this.mapWorldUsable && !this.mapWorld.getCurrentDimension().futureMultiworldWritable && this.mainWorld.field_73011_w.func_177502_q() == this.mapWorld.getCurrentDimensionId()) {
            String selectedMWName = this.mapWorld.getCurrentDimension().getMultiworldName(this.mapWorld.getCurrentDimension().getFutureMultiworldUnsynced());
            String message = "§2(" + GameSettings.func_74298_c(ControlsRegister.keyOpenMap.func_151463_i()).toUpperCase() + ")§r " + I18n.func_135052_a("gui.xaero_map_unconfirmed", new Object[0]);
            if (this.mapWorld.getCurrentDimension().hasConfirmedMultiworld()) {
               message = message + " §2" + GameSettings.func_74298_c(ControlsRegister.keyQuickConfirm.func_151463_i()).toUpperCase() + "§r for map \"" + selectedMWName + "\"";
            }

            return message;
         } else {
            return null;
         }
      }
   }

   private synchronized void checkForWorldUpdate() {
      if (this.mainWorld != null) {
         Object autoIdBase = this.getAutoIdBase(this.mainWorld);
         if (autoIdBase != null) {
            boolean baseChanged = !autoIdBase.equals(this.getUsedAutoIdBase(this.mainWorld));
            if (baseChanged && this.mapWorldUsable) {
               MapDimension mapDimension = this.mapWorld.getDimension(this.mainWorld.field_73011_w.func_177502_q());
               if (mapDimension != null) {
                  mapDimension.updateFutureAutomaticUnsynced(Minecraft.func_71410_x(), autoIdBase);
               }
            }

            if (this.mainWorld != this.world) {
               this.changeWorld(this.mainWorld);
            }

            Object updatedAutoIdBase = this.getAutoIdBase(this.mainWorld);
            if (updatedAutoIdBase != null) {
               this.setUsedAutoIdBase(this.mainWorld, updatedAutoIdBase);
            } else {
               this.removeUsedAutoIdBase(this.mainWorld);
            }
         }
      }

   }

   private void updateWorld() throws IOException {
      this.updateWorldSynced();
      if (this.mapWorldUsable && !this.mapSaveLoad.isRegionDetectionComplete()) {
         this.mapSaveLoad.detectRegions();
         this.mapSaveLoad.setRegionDetectionComplete(true);
      }

   }

   private synchronized void updateWorldSynced() throws IOException {
      synchronized(this.uiSync) {
         if (this.mapWorldUsable != this.mapWorldUsableRequest || this.mapWorldUsableRequest && (this.mapWorld.getFutureDimension() != this.mapWorld.getCurrentDimension() || !this.mapWorld.getFutureDimension().getFutureMultiworldUnsynced().equals(this.mapWorld.getFutureDimension().getCurrentMultiworld()))) {
            String newMultiworldId = !this.mapWorldUsableRequest ? null : this.mapWorld.getFutureMultiworldUnsynced();
            this.pushRenderPause(true, true);
            this.pushWriterPause();
            String newWorldId = !this.mapWorldUsableRequest ? null : this.mapWorld.getMainId();
            String newMWId = !this.mapWorld.isMultiplayer() ? null : newMultiworldId;
            boolean shouldClearAllDimensions = this.state == 1;
            boolean shouldClearNewDimension = this.mapWorldUsableRequest && !this.mapWorld.getFutureMultiworldUnsynced().equals(this.mapWorld.getFutureDimension().getCurrentMultiworld());
            this.mapSaveLoad.getToSave().clear();
            MapDimension reqDim;
            if (this.mapWorld.getCurrentDimensionId() != null) {
               MapDimension currentDim = this.mapWorld.getCurrentDimension();
               reqDim = !this.mapWorldUsableRequest ? null : this.mapWorld.getFutureDimension();
               boolean shouldFinishCurrentDim = this.mapWorldUsable && !this.currentMapNeedsDeletion;
               boolean currentDimChecked = false;
               if (shouldFinishCurrentDim) {
                  this.mapSaveLoad.saveAll = true;
               }

               Iterator var11;
               LeveledRegion region;
               if (shouldFinishCurrentDim || shouldClearNewDimension && reqDim == currentDim) {
                  var11 = currentDim.getMapRegions().getUnsyncedList().iterator();

                  label232:
                  while(true) {
                     do {
                        if (!var11.hasNext()) {
                           currentDimChecked = true;
                           break label232;
                        }

                        region = (LeveledRegion)var11.next();
                        if (shouldFinishCurrentDim) {
                           if (region.getLevel() == 0 && region.recacheHasBeenRequested() && region.getCacheFile() != null) {
                              Files.deleteIfExists(region.getCacheFile().toPath());
                              if (WorldMap.settings.debug) {
                                 System.out.println(String.format("Deleting cache for region %s because it might be outdated.", region));
                              }
                           }

                           region.setReloadHasBeenRequested(false, "world/dim change");
                           region.onCurrentDimFinish(this.mapSaveLoad, this);
                        }
                     } while(!shouldClearAllDimensions && (!shouldClearNewDimension || reqDim != currentDim));

                     region.onDimensionClear(this);
                  }
               }

               if (reqDim != currentDim && shouldClearNewDimension) {
                  var11 = reqDim.getMapRegions().getUnsyncedList().iterator();

                  while(var11.hasNext()) {
                     region = (LeveledRegion)var11.next();
                     region.onDimensionClear(this);
                  }
               }

               if (shouldClearAllDimensions) {
                  var11 = this.mapWorld.getDimensionsList().iterator();

                  label208:
                  while(true) {
                     MapDimension dim;
                     do {
                        if (!var11.hasNext()) {
                           break label208;
                        }

                        dim = (MapDimension)var11.next();
                     } while(currentDimChecked && dim == currentDim);

                     Iterator var13 = dim.getMapRegions().getUnsyncedList().iterator();

                     while(var13.hasNext()) {
                        LeveledRegion<?> region = (LeveledRegion)var13.next();
                        region.onDimensionClear(this);
                     }
                  }
               }

               if (this.currentMapNeedsDeletion) {
                  this.mapWorld.getCurrentDimension().deleteMultiworldMapDataUnsynced(this.mapWorld.getCurrentDimension().getCurrentMultiworld());
               }
            }

            this.currentMapNeedsDeletion = false;
            Iterator var17;
            if (!shouldClearAllDimensions) {
               if (shouldClearNewDimension) {
                  this.mapWorld.getFutureDimension().regionsToCache.clear();
                  this.mapWorld.getFutureDimension().clearLists();
                  if (WorldMap.settings.debug) {
                     System.out.println("Dimension map data cleared!");
                  }
               }
            } else {
               if (this.mapWorld.getCurrentDimensionId() != null) {
                  var17 = this.mapWorld.getDimensionsList().iterator();

                  while(var17.hasNext()) {
                     reqDim = (MapDimension)var17.next();
                     reqDim.clearLists();
                  }
               }

               if (WorldMap.settings.debug) {
                  System.out.println("All map data cleared!");
               }

               if (this.state == 1) {
                  System.out.println("World map cleaned normally!");
                  this.state = 2;
               }
            }

            if (WorldMap.settings.debug) {
               System.out.println("World changed!");
            }

            this.mapWorldUsable = this.mapWorldUsableRequest;
            if (this.mapWorldUsableRequest) {
               this.mapWorld.switchToFutureUnsynced();
            }

            this.caveStartDetermined = false;
            this.caveStart = -1;
            this.currentWorldId = newWorldId;
            this.currentDimId = !this.mapWorldUsableRequest ? null : this.getDimensionName(this.mapWorld.getFutureDimensionId());
            this.currentMWId = newMWId;
            this.footprints.clear();
            this.mapSaveLoad.clearToLoad();
            this.mapSaveLoad.setNextToLoadByViewing((MapRegion)null);
            this.clearToRefresh();

            for(int i = 0; i < this.toProcessLevels.length; ++i) {
               this.toProcessLevels[i].clear();
            }

            if (this.mapWorldUsable) {
               var17 = this.mapWorld.getCurrentDimension().getMapRegions().getUnsyncedList().iterator();

               while(var17.hasNext()) {
                  LeveledRegion<?> region = (LeveledRegion)var17.next();
                  if (region.shouldBeProcessed()) {
                     this.addToProcess(region);
                  }
               }
            }

            this.mapSaveLoad.updateCacheFolderList(this.mapSaveLoad.getMWSubFolder(this.currentWorldId, this.currentDimId, this.currentMWId));
            this.mapWriter.resetPosition();
            this.world = this.newWorld;
            if (WorldMap.settings.debug) {
               System.out.println("World/dimension changed to: " + this.currentWorldId + " " + this.currentDimId + " " + this.currentMWId);
            }

            this.worldDataHandler.prepareSingleplayer(this.world, this);
            if (this.worldDataHandler.getWorldDir() == null && this.currentWorldId != null && !this.mapWorld.isMultiplayer()) {
               this.currentWorldId = this.currentDimId = null;
            }

            boolean shouldDetect = this.mapWorldUsable && this.mapWorld.getCurrentDimension().getDetectedRegions() == null;
            this.mapSaveLoad.setRegionDetectionComplete(!shouldDetect);
            this.popRenderPause(true, true);
            this.popWriterPause();
         } else if (this.newWorld != this.world) {
            this.pushWriterPause();
            this.world = this.newWorld;
            this.popWriterPause();
         }

         if (this.mapWorldUsable) {
            this.mapWorld.getCurrentDimension().switchToFutureMultiworldWritableValueUnsynced();
            this.mapWorld.switchToFutureMultiworldTypeUnsynced();
         }

         this.waitingForWorldUpdate = false;
      }
   }

   public void updateFootprints(World world, int step) {
      if (WorldMap.settings.footsteps) {
         if (this.footprintsTimer > 0) {
            this.footprintsTimer -= step;
         } else {
            Double[] coords = new Double[]{this.mainPlayerX, this.mainPlayerZ};
            synchronized(this.footprints) {
               this.footprints.add(coords);
               if (this.footprints.size() > 32) {
                  this.footprints.remove(0);
               }
            }

            this.footprintsTimer = 20;
         }
      }

   }

   public void addToRefresh(MapRegion region) {
      synchronized(this.toRefresh) {
         if (!this.toRefresh.contains(region)) {
            this.toRefresh.add(0, region);
         }

      }
   }

   public void removeToRefresh(MapRegion region) {
      synchronized(this.toRefresh) {
         this.toRefresh.remove(region);
      }
   }

   private void clearToRefresh() {
      synchronized(this.toRefresh) {
         this.toRefresh.clear();
      }
   }

   private void handleRefresh(World world) throws RuntimeException {
      synchronized(this.loadingSync) {
         if (!this.waitingForWorldUpdate && !this.toRefresh.isEmpty()) {
            MapRegion region = (MapRegion)this.toRefresh.get(0);
            if (!region.isRefreshing()) {
               throw new RuntimeException(String.format("Trying to refresh region %s, which is not marked as being refreshed!", region));
            }

            int globalReloadVersion = WorldMap.settings.reloadVersion;
            int globalCacheHashCode = WorldMap.settings.getRegionCacheHashCode();
            boolean regionLoaded;
            synchronized(region) {
               regionLoaded = region.getLoadState() == 2;
               if (regionLoaded) {
                  if (WorldMap.settings.reloadEverything && region.getReloadVersion() != globalReloadVersion || region.getCacheHashCode() != globalCacheHashCode || region.hasVersion() && region.getVersion() != WorldMap.globalVersion || !region.hasVersion() && region.getInitialVersion() != WorldMap.globalVersion) {
                     region.setRecacheHasBeenRequested(true, "refresh handle");
                     region.setShouldCache(true, "refresh handle");
                  }

                  region.setVersion(WorldMap.globalVersion);
                  region.setCacheHashCode(globalCacheHashCode);
                  region.setReloadVersion(globalReloadVersion);
               }
            }

            boolean isEmpty = true;
            if (regionLoaded) {
               synchronized(region) {
                  region.setAllCachePrepared(false);
               }

               int i = 0;

               while(true) {
                  if (i >= 8) {
                     if (WorldMap.settings.debug) {
                        System.out.println("Region refreshed: " + region + " " + region + " " + this.mapWriter.getUpdateCounter());
                     }
                     break;
                  }

                  for(int j = 0; j < 8; ++j) {
                     MapTileChunk chunk = region.getChunk(i, j);
                     if (chunk != null && chunk.getLoadState() == 2) {
                        chunk.setToUpdateBuffers(true);
                        isEmpty = false;
                     }
                  }

                  ++i;
               }
            }

            synchronized(region) {
               region.setRefreshing(false);
               if (isEmpty) {
                  region.setRecacheHasBeenRequested(false, "refresh handle");
                  region.setShouldCache(false, "refresh handle");
               }
            }

            this.removeToRefresh(region);
         }

      }
   }

   public boolean regionExists(int x, int z) {
      if (!this.mapSaveLoad.isRegionDetectionComplete()) {
         return false;
      } else {
         Hashtable<Integer, RegionDetection> column = (Hashtable)this.mapWorld.getCurrentDimension().getDetectedRegions().get(x);
         return column != null && column.containsKey(z);
      }
   }

   public void addRegionDetection(MapDimension dimension, RegionDetection regionDetection) {
      Hashtable<Integer, Hashtable<Integer, RegionDetection>> current = dimension.getDetectedRegions();
      Hashtable<Integer, RegionDetection> column = (Hashtable)current.get(regionDetection.getRegionX());
      if (column == null) {
         current.put(regionDetection.getRegionX(), column = new Hashtable());
      }

      column.put(regionDetection.getRegionZ(), regionDetection);
   }

   public RegionDetection getRegionDetection(int x, int z) {
      Hashtable<Integer, RegionDetection> column = (Hashtable)this.mapWorld.getCurrentDimension().getDetectedRegions().get(x);
      return column != null ? (RegionDetection)column.get(z) : null;
   }

   private void removeRegionDetection(int x, int z) {
      Hashtable<Integer, Hashtable<Integer, RegionDetection>> current = this.mapWorld.getCurrentDimension().getDetectedRegions();
      Hashtable<Integer, RegionDetection> column = (Hashtable)current.get(x);
      if (column != null) {
         column.remove(z);
      }

      if (column.isEmpty()) {
         current.remove(x);
      }

   }

   public void removeMapRegion(LeveledRegion<?> region) {
      MapDimension regionDim = region.getDim();
      LeveledRegionManager regions = regionDim.getMapRegions();
      if (region.getLevel() == 0) {
         regions.remove(region.getRegionX(), region.getRegionZ(), region.getLevel());
         regions.removeListRegion(region);
      }

      regions.removeLoadedRegion(region);
      this.removeToProcess(region);
   }

   public LeveledRegion<?> getLeveledRegion(int leveledRegX, int leveledRegZ, int level) {
      MapDimension mapDimension = this.mapWorld.getCurrentDimension();
      LeveledRegionManager regions = mapDimension.getMapRegions();
      return regions.get(leveledRegX, leveledRegZ, level);
   }

   public MapRegion getMapRegion(int regX, int regZ, boolean create) {
      MapDimension mapDimension = this.mapWorld.getCurrentDimension();
      LeveledRegionManager regions = mapDimension.getMapRegions();
      MapRegion region = regions.getLeaf(regX, regZ);
      if (region == null) {
         if (!create) {
            return null;
         }

         if (!Minecraft.func_71410_x().func_152345_ab()) {
            throw new IllegalAccessError();
         }

         region = new MapRegion(this.currentWorldId, this.currentDimId, this.currentMWId, mapDimension, regX, regZ, this.getGlobalVersion(), this.mapWorld.isMultiplayer());
         RegionDetection regionDetection = this.getRegionDetection(regX, regZ);
         if (regionDetection != null) {
            regionDetection.transferInfoTo(region);
            this.removeRegionDetection(regX, regZ);
         }

         regions.putLeaf(regX, regZ, region);
         regions.addListRegion(region);
         if (regionDetection != null) {
            regionDetection.transferInfoPostAddTo(region, this);
         }
      }

      return region;
   }

   public MapTileChunk getMapChunk(int chunkX, int chunkZ) {
      int regionX = chunkX >> 3;
      int regionZ = chunkZ >> 3;
      MapRegion region = this.getMapRegion(regionX, regionZ, false);
      if (region == null) {
         return null;
      } else {
         int localChunkX = chunkX & 7;
         int localChunkZ = chunkZ & 7;
         return region.getChunk(localChunkX, localChunkZ);
      }
   }

   public MapTile getMapTile(int x, int z) {
      MapTileChunk tileChunk = this.getMapChunk(x >> 2, z >> 2);
      if (tileChunk == null) {
         return null;
      } else {
         int tileX = x & 3;
         int tileZ = z & 3;
         return tileChunk.getTile(tileX, tileZ);
      }
   }

   public void updateWorldSpawn(net.minecraft.util.BlockPos newSpawn, WorldClient world) {
      int dimId = world.field_73011_w.func_177502_q();
      WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getWorldData(world);
      worldData.latestSpawn = newSpawn;
      if (WorldMap.settings.debug) {
         System.out.println("Updated spawn for dimension " + dimId + " " + newSpawn);
      }

      this.spawnToRestore = newSpawn;
      if (world == this.mainWorld) {
         this.mainWorldChangedTime = -1L;
         if (WorldMap.settings.debug) {
            System.out.println("Done waiting for main spawn.");
         }
      }

      this.checkForWorldUpdate();
   }

   public void onServerLevelId(int serverLevelId) {
      WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getCurrentWorldData();
      worldData.serverLevelId = serverLevelId;
      if (WorldMap.settings.debug) {
         System.out.println("Updated server level id " + serverLevelId);
      }

      this.checkForWorldUpdate();
   }

   public void onWorldUnload() {
      if (!this.mainWorldUnloaded) {
         if (WorldMap.settings.debug) {
            System.out.println("Changing worlds, pausing the world map...");
         }

         this.mainWorldUnloaded = true;
         this.mainWorldChangedTime = -1L;
         this.changeWorld((WorldClient)null);
      }
   }

   public void onGuiClosed() {
      WorldClient world = Minecraft.func_71410_x().field_71441_e;
      if (world != null) {
         WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getCurrentWorldData();
         if (worldData.latestSpawn == null && this.spawnToRestore != null && Minecraft.func_71410_x().func_71401_C() != null) {
            if (WorldMap.settings.debug) {
               System.out.println("SINGLEPLAYER RESTORE");
            }

            this.updateWorldSpawn(this.spawnToRestore, world);
         }
      }

   }

   public void onClientTickStart() throws RuntimeException {
      if (this.mainWorld != null && this.spawnToRestore != null && this.mainWorldChangedTime != -1L && System.currentTimeMillis() - this.mainWorldChangedTime >= 3000L) {
         if (WorldMap.settings.debug) {
            System.out.println("SPAWN SET TIME OUT");
         }

         this.updateWorldSpawn(this.spawnToRestore, this.mainWorld);
      }

   }

   private void updateRenderStartTime() {
      if (this.renderStartTime == -1L) {
         this.renderStartTime = System.nanoTime();
      }

   }

   public void pushWriterPause() {
      synchronized(this.renderThreadPauseSync) {
         ++this.pauseWriting;
      }
   }

   public void popWriterPause() {
      synchronized(this.renderThreadPauseSync) {
         --this.pauseWriting;
      }
   }

   public void pushRenderPause(boolean rendering, boolean uploading) {
      synchronized(this.renderThreadPauseSync) {
         if (rendering) {
            ++this.pauseRendering;
         }

         if (uploading) {
            ++this.pauseUploading;
         }

      }
   }

   public void popRenderPause(boolean rendering, boolean uploading) {
      synchronized(this.renderThreadPauseSync) {
         if (rendering) {
            --this.pauseRendering;
         }

         if (uploading) {
            --this.pauseUploading;
         }

      }
   }

   public boolean isWritingPaused() {
      return this.pauseWriting > 0;
   }

   public boolean isRenderingPaused() {
      return this.pauseRendering > 0;
   }

   public boolean isUploadingPaused() {
      return this.pauseUploading > 0;
   }

   public boolean isProcessingPaused() {
      return this.pauseProcessing > 0;
   }

   public boolean isProcessed(LeveledRegion<?> region) {
      ArrayList<LeveledRegion<?>> toProcess = this.toProcessLevels[region.getLevel()];
      synchronized(toProcess) {
         return toProcess.contains(region);
      }
   }

   public void addToProcess(LeveledRegion<?> region) {
      ArrayList<LeveledRegion<?>> toProcess = this.toProcessLevels[region.getLevel()];
      synchronized(toProcess) {
         toProcess.add(region);
      }
   }

   public void removeToProcess(LeveledRegion<?> region) {
      ArrayList<LeveledRegion<?>> toProcess = this.toProcessLevels[region.getLevel()];
      synchronized(toProcess) {
         toProcess.remove(region);
      }
   }

   public int getProcessedCount() {
      int total = 0;

      for(int i = 0; i < this.toProcessLevels.length; ++i) {
         total += this.toProcessLevels[i].size();
      }

      return total;
   }

   public int getAffectingLoadingFrequencyCount() {
      int total = 0;

      for(int i = 0; i < this.toProcessLevels.length; ++i) {
         ArrayList<LeveledRegion<?>> processed = this.toProcessLevels[i];

         for(int j = 0; j < processed.size(); ++j) {
            synchronized(processed) {
               if (j >= processed.size()) {
                  break;
               }

               if (((LeveledRegion)processed.get(j)).shouldAffectLoadingRequestFrequency()) {
                  ++total;
               }
            }
         }
      }

      return total;
   }

   public MapSaveLoad getMapSaveLoad() {
      return this.mapSaveLoad;
   }

   public WorldClient getWorld() {
      return this.world;
   }

   public WorldClient getNewWorld() {
      return this.newWorld;
   }

   public String getCurrentWorldId() {
      return this.currentWorldId;
   }

   public String getCurrentDimId() {
      return this.currentDimId;
   }

   public String getCurrentMWId() {
      return this.currentMWId;
   }

   public MapWriter getMapWriter() {
      return this.mapWriter;
   }

   public MapLimiter getMapLimiter() {
      return this.mapLimiter;
   }

   public ArrayList<Double[]> getFootprints() {
      return this.footprints;
   }

   public ByteBufferDeallocator getBufferDeallocator() {
      return this.bufferDeallocator;
   }

   public MapTilePool getTilePool() {
      return this.tilePool;
   }

   public OverlayManager getOverlayManager() {
      return this.overlayManager;
   }

   public int getGlobalVersion() {
      return WorldMap.globalVersion;
   }

   public void setGlobalVersion(int globalVersion) {
      WorldMap.globalVersion = globalVersion;
   }

   public long getRenderStartTime() {
      return this.renderStartTime;
   }

   public void resetRenderStartTime() {
      this.renderStartTime = -1L;
   }

   public Queue<FutureTask<?>> getMinecraftScheduledTasks() {
      this.scheduledTasksField.setAccessible(true);

      Queue result;
      try {
         result = (Queue)this.scheduledTasksField.get(Minecraft.func_71410_x());
      } catch (IllegalArgumentException var3) {
         result = null;
      } catch (IllegalAccessException var4) {
         result = null;
      }

      this.scheduledTasksField.setAccessible(false);
      return result;
   }

   public Callable<Object> getRenderStartTimeUpdater() {
      return this.renderStartTimeUpdater;
   }

   public boolean isWaitingForWorldUpdate() {
      return this.waitingForWorldUpdate;
   }

   public WorldDataHandler getWorldDataHandler() {
      return this.worldDataHandler;
   }

   public void setMainValues() {
      synchronized(this.mainStuffSync) {
         Entity player = Minecraft.func_71410_x().func_175606_aa();
         if (player != null) {
            WorldClient worldToChangeTo = !this.ignoreWorld(player.field_70170_p) && player.field_70170_p instanceof WorldClient ? (WorldClient)player.field_70170_p : this.mainWorld;
            boolean worldChanging = worldToChangeTo != this.mainWorld;
            if (worldChanging) {
               this.mainWorldChangedTime = -1L;
               if (this.spawnToRestore != null) {
                  WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getWorldData(worldToChangeTo);
                  if (worldData.latestSpawn == null) {
                     this.mainWorldChangedTime = System.currentTimeMillis();
                  }
               }

               this.mainWorldUnloaded = false;
            }

            this.mainWorld = worldToChangeTo;
            this.mainPlayerX = player.field_70165_t;
            this.mainPlayerY = player.field_70163_u;
            this.mainPlayerZ = player.field_70161_v;
            if (worldChanging) {
               this.checkForWorldUpdate();
            }
         } else {
            if (this.mainWorld != null && !this.mainWorldUnloaded) {
               this.onWorldUnload();
            }

            this.mainWorld = null;
         }

      }
   }

   public void updateCaveStart(double playerX, double playerZ, World world) {
      if (!this.caveStartDetermined) {
         int chunkX = (int)Math.floor(playerX) >> 4;
         int chunkZ = (int)Math.floor(playerZ) >> 4;
         Chunk chunk = world.func_72964_e(chunkX, chunkZ);
         if (chunk != null && chunk.func_177410_o()) {
            if (world.func_72940_L() < 256 && (world.field_73011_w instanceof WorldProviderHell || Math.abs(chunk.func_76611_b(0, 0) - world.func_72940_L()) < 16)) {
               this.caveStart = world.func_72940_L() - 1;
            }

            this.caveStartDetermined = true;
         }
      }

   }

   public boolean caveStartIsDetermined() {
      return this.caveStartDetermined;
   }

   public int getCaveStart() {
      return this.caveStart;
   }

   public float getBrightness() {
      return this.getBrightness(WorldMap.settings.lighting);
   }

   public float getBrightness(boolean lighting) {
      if (this.world == null) {
         return 1.0F;
      } else {
         float sunBrightness = lighting && this.caveStart == -1 ? this.world.getSunBrightnessFactor(1.0F) : 1.0F;
         return 0.375F + 0.625F * MathHelper.func_76131_a(sunBrightness, 0.0F, 1.0F);
      }
   }

   public MapBiomes getMapBiomes() {
      return this.mapBiomes;
   }

   public boolean isWorldRealms(String world) {
      return world.startsWith("Realms_");
   }

   public boolean isWorldMultiplayer(boolean realms, String world) {
      return realms || world.startsWith("Multiplayer_");
   }

   public MapWorld getMapWorld() {
      return this.mapWorld;
   }

   public boolean isCurrentMultiworldWritable() {
      return this.mapWorldUsable && this.mapWorld.getCurrentDimension().currentMultiworldWritable;
   }

   public String getCurrentDimension() {
      return "placeholder";
   }

   public void requestCurrentMapDeletion() {
      if (this.currentMapNeedsDeletion) {
         throw new RuntimeException("Requesting map deletion at a weird time!");
      } else {
         this.currentMapNeedsDeletion = true;
      }
   }

   public boolean isFinalizing() {
      return this.finalizing;
   }

   public void stop() {
      this.finalizing = true;
      WorldMap.mapRunner.addTask(new MapRunnerTask() {
         public void run(MapProcessor doNotUse) {
            if (MapProcessor.this.state == 0) {
               MapProcessor.this.state = 1;
               if (!MapProcessor.this.mapWorldUsable) {
                  MapProcessor.this.forceClean();
               } else {
                  MapProcessor.this.changeWorld((WorldClient)null);
               }
            }

         }
      });
   }

   private synchronized void forceClean() {
      this.pushRenderPause(true, true);
      this.pushWriterPause();
      if (this.mapWorld != null) {
         Iterator var1 = this.mapWorld.getDimensionsList().iterator();

         while(var1.hasNext()) {
            MapDimension dim = (MapDimension)var1.next();
            Iterator var3 = dim.getMapRegions().getUnsyncedList().iterator();

            while(var3.hasNext()) {
               LeveledRegion<?> region = (LeveledRegion)var3.next();
               region.onDimensionClear(this);
            }
         }
      }

      this.popRenderPause(true, true);
      this.popWriterPause();
      this.state = 2;
      System.out.println("World map force-cleaned!");
   }

   public boolean isMapWorldUsable() {
      return this.mapWorldUsable;
   }

   private Object getAutoIdBase(WorldClient world) {
      return this.hasServerLevelId() ? WorldMapClientWorldDataHelper.getCurrentWorldData().serverLevelId : WorldMapClientWorldDataHelper.getWorldData(world).latestSpawn;
   }

   private Object getUsedAutoIdBase(WorldClient world) {
      WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getWorldData(world);
      return this.hasServerLevelId() ? WorldMapClientWorldDataHelper.getCurrentWorldData().usedServerLevelId : worldData.usedSpawn;
   }

   private void setUsedAutoIdBase(WorldClient world, Object autoIdBase) {
      WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getWorldData(world);
      if (this.hasServerLevelId()) {
         WorldMapClientWorldDataHelper.getCurrentWorldData().usedServerLevelId = (Integer)autoIdBase;
      } else {
         worldData.usedSpawn = (net.minecraft.util.BlockPos)autoIdBase;
      }

   }

   private void removeUsedAutoIdBase(WorldClient world) {
      WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getWorldData(world);
      if (this.hasServerLevelId()) {
         WorldMapClientWorldDataHelper.getCurrentWorldData().usedServerLevelId = null;
      } else {
         worldData.usedSpawn = null;
      }

   }

   private boolean hasServerLevelId() {
      WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getCurrentWorldData();
      if (worldData == null) {
         return false;
      } else {
         return worldData.serverLevelId != null && !this.mapWorld.isIgnoreServerLevelId();
      }
   }

   public boolean isEqual(String worldId, String dimId, String mwId) {
      return worldId.equals(this.currentWorldId) && dimId.equals(this.currentDimId) && (mwId == this.currentMWId || mwId != null && mwId.equals(this.currentMWId));
   }

   /** @deprecated */
   @Deprecated
   public String getCurrentWorldString() {
      return this.getCurrentWorldId();
   }

   public boolean isFinished() {
      return this.state == 3;
   }

   private void fixIPv6Folder(String mainId) {
      if (mainId.startsWith("Multiplayer_")) {
         String preIP6FixMainId = this.getMainId(true, true);
         if (!mainId.equals(preIP6FixMainId)) {
            Path preFixFolder = WorldMap.saveFolder.toPath().resolve(preIP6FixMainId);
            if (Files.exists(preFixFolder, new LinkOption[0])) {
               Path fixedFolder = WorldMap.saveFolder.toPath().resolve(mainId);
               if (!Files.exists(fixedFolder, new LinkOption[0])) {
                  try {
                     Files.move(preFixFolder, fixedFolder);
                  } catch (IOException var6) {
                     throw new RuntimeException("failed to auto-restore old IPv6 world map folder", var6);
                  }
               }
            }
         }
      }

   }
}
