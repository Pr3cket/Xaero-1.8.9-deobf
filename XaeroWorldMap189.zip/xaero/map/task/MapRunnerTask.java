package xaero.map.task;

import xaero.map.MapProcessor;

public abstract class MapRunnerTask {
   public abstract void run(MapProcessor var1);
}
