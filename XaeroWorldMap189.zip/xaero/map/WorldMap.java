package xaero.map;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;
import xaero.deallocator.ByteBufferDeallocator;
import xaero.map.biome.MapBiomes;
import xaero.map.controls.ControlsRegister;
import xaero.map.events.Events;
import xaero.map.events.FMLEvents;
import xaero.map.file.PNGExporter;
import xaero.map.graphics.GLObjectDeleter;
import xaero.map.graphics.TextureUploadBenchmark;
import xaero.map.message.LevelMapPropertiesConsumer;
import xaero.map.misc.Internet;
import xaero.map.mods.SupportMods;
import xaero.map.mods.gui.WaypointSymbolCreator;
import xaero.map.pool.MapTilePool;
import xaero.map.pool.TextureUploadPool;
import xaero.map.region.OverlayManager;
import xaero.map.region.texture.BranchTextureRenderer;
import xaero.map.server.WorldMapServer;
import xaero.map.server.core.XaeroWorldMapServerCore;
import xaero.map.server.level.LevelMapProperties;
import xaero.map.settings.ModSettings;
import xaero.map.task.MapRunnerTask;
import xaero.patreon.Patreon7;
import xaero.patreon.PatreonMod4;

@Mod(
   modid = "XaeroWorldMap",
   name = "Xaero's World Map",
   version = "1.14.1.31",
   guiFactory = "xaero.map.gui.ConfigGuiFactory",
   acceptedMinecraftVersions = "[1.8.9]",
   acceptableRemoteVersions = "*"
)
public class WorldMap {
   @Instance("XaeroWorldMap")
   public static WorldMap instance;
   public static int MINIMAP_COMPATIBILITY_VERSION = 8;
   private static final String versionID_minecraft = "1.8.9";
   private static final String versionID_mod = ((Mod)WorldMap.class.getAnnotation(Mod.class)).version();
   public static final String versionID;
   public static int newestUpdateID;
   public static boolean isOutdated;
   public static String fileLayout;
   public static String fileLayoutID;
   public static String latestVersion;
   public static String latestVersionMD5;
   public static Events events;
   public static FMLEvents fmlEvents;
   public static ControlsRegister controlsRegister;
   public static WaypointSymbolCreator waypointSymbolCreator;
   public static ByteBufferDeallocator bufferDeallocator;
   public static TextureUploadBenchmark textureUploadBenchmark;
   public static OverlayManager overlayManager;
   public static PNGExporter pngExporter;
   public static TextureUploadPool.Normal normalTextureUploadPool;
   public static TextureUploadPool.NormalWithDownload normalWithDownloadTextureUploadPool;
   public static TextureUploadPool.Compressed compressedTextureUploadPool;
   public static TextureUploadPool.BranchUpdate branchUpdatePool;
   public static TextureUploadPool.BranchUpdate branchUpdateAllocatePool;
   public static TextureUploadPool.BranchDownload branchDownloadPool;
   public static MapTilePool tilePool;
   public static MapLimiter mapLimiter;
   public static GLObjectDeleter glObjectDeleter;
   public static MapRunner mapRunner;
   public static Thread mapRunnerThread;
   public static CrashHandler crashHandler;
   public static MapBiomes mapBiomes;
   public static BranchTextureRenderer branchTextureRenderer;
   public static final ResourceLocation guiTextures;
   public static ModSettings settings;
   public static int globalVersion;
   public static WorldMapClient worldMapClient;
   public static final SimpleNetworkWrapper network;
   private WorldMapServer worldmapServer;
   public static File modJAR;
   public static File configFolder;
   public static File optionsFile;
   public static File saveFolder;

   public static PatreonMod4 getPatreon() {
      return (PatreonMod4)Patreon7.mods.get(fileLayoutID);
   }

   @EventHandler
   public void preInit(FMLPreInitializationEvent event) throws IOException {
      if (event.getSide() != Side.SERVER) {
         String modId = ((Mod)this.getClass().getAnnotation(Mod.class)).modid();
         (worldMapClient = new WorldMapClient()).preInit(event, modId);
         if (event.getSourceFile().getName().endsWith(".jar")) {
            modJAR = event.getSourceFile();
         }

         Path gameDir = Minecraft.func_71410_x().field_71412_D.toPath().toAbsolutePath();
         configFolder = event.getModConfigurationDirectory();
         optionsFile = configFolder.toPath().resolve("xaeroworldmap.txt").toFile();
         saveFolder = gameDir.resolve("XaeroWorldMap").toFile();
         Path oldSaveFolder3 = configFolder.toPath().getParent().resolve("XaeroWorldMap");
         File oldOptionsFile = gameDir.resolve("xaeroworldmap.txt").toFile();
         File oldSaveFolder = gameDir.resolve("mods").resolve("XaeroWorldMap").toFile();
         File oldSaveFolder2 = gameDir.resolve("config").resolve("XaeroWorldMap").toFile();
         if (oldOptionsFile.exists() && !optionsFile.exists()) {
            Files.move(oldOptionsFile.toPath(), optionsFile.toPath());
         }

         if (oldSaveFolder.exists() && !saveFolder.exists()) {
            Files.move(oldSaveFolder.toPath(), saveFolder.toPath());
         }

         if (oldSaveFolder2.exists() && !saveFolder.exists()) {
            Files.move(oldSaveFolder2.toPath(), saveFolder.toPath());
         }

         if (oldSaveFolder3.toFile().exists() && !saveFolder.exists()) {
            Files.move(oldSaveFolder3, saveFolder.toPath());
         }

         if (!saveFolder.exists()) {
            Files.createDirectories(saveFolder.toPath());
         }

      }
   }

   @EventHandler
   public void load(FMLInitializationEvent event) throws IOException, ClassNotFoundException, NoSuchMethodException, SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
      if (event.getSide() == Side.SERVER) {
         this.worldmapServer = new WorldMapServer();
         this.worldmapServer.load(event);
         XaeroWorldMapServerCore.worldmapServer = this.worldmapServer;
      } else {
         events = new Events();
         fmlEvents = new FMLEvents();
         MinecraftForge.EVENT_BUS.register(events);
         MinecraftForge.EVENT_BUS.register(fmlEvents);
         Patreon7.checkPatreon();
         settings = new ModSettings();
         settings.loadSettings();
         Internet.checkModVersion();
         if (isOutdated) {
            PatreonMod4 patreonEntry = getPatreon();
            if (patreonEntry != null) {
               patreonEntry.modJar = modJAR;
               patreonEntry.currentVersion = versionID;
               patreonEntry.latestVersion = latestVersion;
               patreonEntry.md5 = latestVersionMD5;
               patreonEntry.onVersionIgnore = new Runnable() {
                  public void run() {
                     ModSettings.ignoreUpdate = WorldMap.newestUpdateID;

                     try {
                        WorldMap.settings.saveSettings();
                     } catch (IOException var2) {
                        var2.printStackTrace();
                     }

                  }
               };
               Patreon7.addOutdatedMod(patreonEntry);
            }
         }

         waypointSymbolCreator = new WaypointSymbolCreator();
         controlsRegister = new ControlsRegister();
         bufferDeallocator = new ByteBufferDeallocator();
         tilePool = new MapTilePool();
         overlayManager = new OverlayManager();
         pngExporter = new PNGExporter(configFolder.toPath().getParent().resolve("map exports"));
         mapLimiter = new MapLimiter();
         normalTextureUploadPool = new TextureUploadPool.Normal(256);
         normalWithDownloadTextureUploadPool = new TextureUploadPool.NormalWithDownload(256);
         compressedTextureUploadPool = new TextureUploadPool.Compressed(256);
         branchUpdatePool = new TextureUploadPool.BranchUpdate(256, false);
         branchUpdateAllocatePool = new TextureUploadPool.BranchUpdate(256, true);
         branchDownloadPool = new TextureUploadPool.BranchDownload(256);
         textureUploadBenchmark = new TextureUploadBenchmark(new int[]{512, 512, 512, 256, 256, 256});
         glObjectDeleter = new GLObjectDeleter();
         crashHandler = new CrashHandler();
         mapBiomes = new MapBiomes();
         (mapRunnerThread = new Thread(mapRunner = new MapRunner())).start();
      }
   }

   @EventHandler
   public void postInit(FMLPostInitializationEvent event) {
      if (event.getSide() == Side.SERVER) {
         this.worldmapServer.loadLater();
         this.worldmapServer = null;
      } else {
         settings.updateRegionCacheHashCode();
         network.registerMessage(LevelMapPropertiesConsumer.class, LevelMapProperties.class, 0, Side.CLIENT);
         SupportMods.load();
      }
   }

   public static void incrementGlobalVersion() {
      mapRunner.addTask(new MapRunnerTask() {
         public void run(MapProcessor mapProcessor) {
            ++WorldMap.globalVersion;
            if (mapProcessor != null) {
               mapProcessor.getMapSaveLoad().updateCacheFolderList(mapProcessor.getMapSaveLoad().getMWSubFolder(mapProcessor.getCurrentWorldId(), mapProcessor.getCurrentDimId(), mapProcessor.getCurrentMWId()));
            }

            if (WorldMap.settings.debug) {
               System.out.println("Version incremented to " + WorldMap.globalVersion);
            }

            try {
               WorldMap.settings.saveSettings();
            } catch (IOException var3) {
            }

         }
      });
   }

   static {
      versionID = "1.8.9_" + versionID_mod;
      isOutdated = true;
      fileLayout = "XaerosWorldMap_&mod_Forge_&mc.jar";
      fileLayoutID = "worldmap";
      guiTextures = new ResourceLocation("xaeroworldmap", "gui/gui.png");
      globalVersion = 1;
      network = NetworkRegistry.INSTANCE.newSimpleChannel("xaeroworldmap:main");
      modJAR = null;
   }
}
