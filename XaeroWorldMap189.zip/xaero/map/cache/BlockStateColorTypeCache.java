package xaero.map.cache;

import java.util.Hashtable;
import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import xaero.map.WorldMap;
import xaero.map.world.BlockAccessWrapper;

public class BlockStateColorTypeCache {
   private BlockAccessWrapper blockAccessWrapper;
   private Hashtable<IBlockState, Integer> colorTypes = new Hashtable();
   private Hashtable<IBlockState, Integer> overlayColorTypes = new Hashtable();
   private int grassColor;
   private int foliageColor;
   private IBlockState grassState;
   private IBlockState oakLeavesState;
   private IBlockState waterState;

   public BlockStateColorTypeCache() {
      this.grassState = Blocks.field_150349_c.func_176223_P();
      this.oakLeavesState = Blocks.field_150362_t.func_176223_P();
      this.waterState = Blocks.field_150355_j.func_176223_P();
      this.blockAccessWrapper = new BlockAccessWrapper();
   }

   public void getBlockBiomeColour(World world, IBlockState state, BlockPos pos, int[] dest, int biomeId) {
      dest[0] = dest[2] = 0;
      dest[1] = -1;
      Integer cachedColorType = (Integer)this.colorTypes.get(state);
      int colorType = cachedColorType != null ? cachedColorType : -1;
      int customColour = 16777215;
      boolean gotFullCC = false;
      boolean isRenderThread = Minecraft.func_71410_x().func_152345_ab();
      if (colorType == -1 && isRenderThread) {
         Block b = state.func_177230_c();
         boolean renderColorFailed = false;

         try {
            customColour = b.func_180644_h(state);
         } catch (Throwable var14) {
            renderColorFailed = true;
         }

         if (renderColorFailed || customColour != 16777215 && customColour != this.grassColor && customColour != this.foliageColor) {
            Material material = b.func_149688_o();
            if (material != null && (material.func_151565_r() == MapColor.field_151661_c || material.func_151565_r() == MapColor.field_151669_i)) {
               customColour = b.func_176202_d(this.blockAccessWrapper.withValues(world, state, pos), pos);
               gotFullCC = true;
               if (material.func_151565_r() == MapColor.field_151661_c && customColour == Blocks.field_150349_c.func_176202_d(this.blockAccessWrapper.withValues(world, this.grassState, pos), pos)) {
                  customColour = this.grassColor;
               } else if (material.func_151565_r() == MapColor.field_151669_i && customColour == Blocks.field_150362_t.func_176202_d(this.blockAccessWrapper.withValues(world, this.oakLeavesState, pos), pos)) {
                  customColour = this.foliageColor;
               }
            }
         }

         if (customColour == this.grassColor) {
            colorType = 1;
         } else if (customColour == this.foliageColor) {
            colorType = 2;
         } else {
            if (!gotFullCC) {
               customColour = b.func_176202_d(this.blockAccessWrapper.withValues(world, state, pos), pos);
               gotFullCC = true;
            }

            if (customColour != 16777215 && customColour != -1) {
               colorType = 3;
            } else {
               colorType = 0;
            }
         }

         this.colorTypes.put(state, colorType);
      } else if (colorType == 3 && !isRenderThread) {
         colorType = -1;
      }

      if ((colorType == 1 || colorType == 2) && biomeId == -1) {
         if (isRenderThread) {
            biomeId = world.func_180494_b(pos).field_76756_M;
         } else {
            colorType = -1;
         }
      }

      dest[0] = colorType;
      if (colorType == -1) {
         dest[1] = biomeId;
      } else if (colorType != 1 && colorType != 2) {
         if (colorType == 3) {
            if (!gotFullCC) {
               customColour = state.func_177230_c().func_176202_d(this.blockAccessWrapper.withValues(world, state, pos), pos);
            }

            dest[2] = customColour;
         }
      } else {
         dest[1] = biomeId;
      }

   }

   public void getOverlayBiomeColour(World world, IBlockState state, BlockPos pos, int[] dest, int biomeId) {
      dest[0] = dest[2] = 0;
      dest[1] = -1;
      Integer cachedColorType = (Integer)this.overlayColorTypes.get(state);
      int colorType = cachedColorType != null ? cachedColorType : -1;
      int customColour = -1;
      boolean gotFullCC = false;
      boolean isRenderThread = Minecraft.func_71410_x().func_152345_ab();
      if (colorType == -1 && isRenderThread) {
         Block b = state.func_177230_c();
         if (b != Blocks.field_150355_j && b != Blocks.field_150358_i) {
            customColour = b.func_176202_d(this.blockAccessWrapper.withValues(world, state, pos), pos);
            gotFullCC = true;
            colorType = 0;
            if (customColour != -1) {
               Material material = b.func_149688_o();
               if (material != null && material.func_151565_r() == MapColor.field_151662_n && customColour == Blocks.field_150355_j.func_176202_d(this.blockAccessWrapper.withValues(world, this.waterState, pos), pos)) {
                  colorType = 1;
               } else if (customColour != 16777215) {
                  colorType = 2;
               }
            }
         } else {
            colorType = 1;
         }

         this.overlayColorTypes.put(state, colorType);
      } else if (colorType == 2 && !isRenderThread) {
         colorType = -1;
      }

      dest[0] = colorType;
      if (colorType == 1) {
         if (biomeId == -1) {
            if (!gotFullCC) {
               customColour = state.func_177230_c().func_176202_d(this.blockAccessWrapper.withValues(world, state, pos), pos);
            }

            if (customColour == 16777215) {
               dest[0] = 0;
            } else {
               biomeId = world.func_180494_b(pos).field_76756_M;
               dest[1] = biomeId;
            }
         }

         dest[1] = biomeId;
      } else if (colorType == 2) {
         if (!gotFullCC) {
            customColour = state.func_177230_c().func_176202_d(this.blockAccessWrapper.withValues(world, state, pos), pos);
         }

         dest[2] = customColour;
      }

   }

   public void updateGrassColor() {
      this.grassColor = Blocks.field_150349_c.func_180644_h(this.grassState);
      this.foliageColor = Blocks.field_150362_t.func_180644_h(this.oakLeavesState);
      if (WorldMap.settings.debug) {
         System.out.println("Default grass colour: " + this.grassColor);
      }

   }
}
