package xaero.map.region.texture;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL11;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.exception.OpenGLException;
import xaero.map.graphics.TextureUploader;
import xaero.map.misc.Misc;
import xaero.map.region.LeveledRegion;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTileChunk;

public class LeafRegionTexture extends RegionTexture<LeafRegionTexture> {
   private MapTileChunk tileChunk;

   public LeafRegionTexture(MapTileChunk tileChunk) {
      super(tileChunk.getInRegion());
      this.tileChunk = tileChunk;
   }

   public void postBufferUpdate(boolean hasLight) {
      this.colorBufferFormat = -1;
      this.colorBufferCompressed = false;
      this.bufferHasLight = hasLight;
   }

   public void preUpload(MapProcessor mapProcessor, LeveledRegion<LeafRegionTexture> leveledRegion, boolean detailedDebug) {
      MapRegion region = (MapRegion)leveledRegion;
      if (this.tileChunk.getToUpdateBuffers() && !mapProcessor.isWritingPaused()) {
         synchronized(region.writerThreadPauseSync) {
            if (!region.isWritingPaused()) {
               this.tileChunk.updateBuffers(mapProcessor, detailedDebug);
            }
         }
      }

   }

   public void postUpload(MapProcessor mapProcessor, LeveledRegion<LeafRegionTexture> leveledRegion, boolean cleanAndCacheRequestsBlocked) {
      MapRegion region = (MapRegion)leveledRegion;
      if (region.getLoadState() >= 2 && !region.isBeingWritten() && (region.getLastVisited() == 0L || region.getTimeSinceVisit() > 1000L) && !cleanAndCacheRequestsBlocked && !this.tileChunk.getToUpdateBuffers() && this.tileChunk.getLoadState() != 3) {
         region.setLoadState((byte)3);
         this.tileChunk.setLoadState((byte)3);
         this.tileChunk.clean(mapProcessor);
      }

   }

   public boolean canUpload() {
      return this.tileChunk.getLoadState() >= 2;
   }

   public boolean isUploaded() {
      return super.isUploaded() && !this.tileChunk.getToUpdateBuffers();
   }

   public boolean hasSourceData() {
      return this.tileChunk.getLoadState() != 3;
   }

   protected long uploadNonCache(TextureUploader textureUploader, BranchTextureRenderer unused, ScaledResolution scaledRes) {
      this.writeToUnpackPBO(0, this.colorBuffer);
      if (this.textureVersion == -1) {
         this.updateTextureVersion(this.bufferedTextureVersion != -1 ? this.bufferedTextureVersion + 1 : 1 + (int)(Math.random() * 1000000.0D));
      } else {
         this.updateTextureVersion(this.textureVersion + 1);
      }

      this.textureHasLight = this.bufferHasLight;
      long totalEstimatedTime;
      if (WorldMap.settings.compression) {
         this.timer = 5;
         this.shouldDownloadFromPBO = true;
         this.bindPackPBO();
         this.unbindPackPBO();
         this.bindColorTexture(true, 9728);
         OpenGLException.checkGLError();
         totalEstimatedTime = textureUploader.requestNormalWithDownload(this.glColorTexture, this.unpackPbo[0], 3553, 0, 34030, 64, 64, 0, 0L, 32993, 32821, this.packPbo);
      } else {
         this.colorBuffer.position(0);
         this.colorBufferFormat = 32856;
         this.bufferedTextureVersion = this.textureVersion;
         this.bindColorTexture(true, 9728);
         OpenGLException.checkGLError();
         totalEstimatedTime = textureUploader.requestNormal(this.glColorTexture, this.unpackPbo[0], 3553, 0, 32856, 64, 64, 0, 0L, 32993, 32821);
      }

      boolean toUploadImmediately = this.tileChunk.getInRegion().isBeingWritten();
      if (toUploadImmediately) {
         textureUploader.finishNewestRequestImmediately();
      }

      return totalEstimatedTime;
   }

   protected void updateTextureVersion(int newVersion) {
      super.updateTextureVersion(newVersion);
      this.region.updateLeafTextureVersion(this.tileChunk.getX() & 7, this.tileChunk.getZ() & 7, newVersion);
   }

   public void addDebugLines(List<String> lines) {
      super.addDebugLines(lines);
      lines.add(this.tileChunk.getX() + " " + this.tileChunk.getZ());
      lines.add("loadState: " + this.tileChunk.getLoadState());
      lines.add(String.format("changed: %s include: %s", this.tileChunk.wasChanged(), this.tileChunk.includeInSave()));
   }

   protected void onDownloadedBuffer(ByteBuffer mappedPBO, int isCompressed) {
      int length;
      if (isCompressed == 1) {
         length = GL11.glGetTexLevelParameteri(3553, 0, 34464);
      } else {
         length = 16384;
      }

      this.colorBuffer.clear();
      mappedPBO.limit(length);
      this.colorBuffer.put(mappedPBO);
      this.colorBuffer.flip();
   }

   public void writeCacheMapData(DataOutputStream output, byte[] usableBuffer, byte[] integerByteBuffer, LeveledRegion<LeafRegionTexture> inRegion) throws IOException {
      super.writeCacheMapData(output, usableBuffer, integerByteBuffer, inRegion);
      this.tileChunk.writeCacheData(output, usableBuffer, integerByteBuffer, inRegion);
   }

   public void readCacheData(int cacheSaveVersion, DataInputStream input, byte[] usableBuffer, byte[] integerByteBuffer, LeveledRegion<LeafRegionTexture> inRegion, MapProcessor mapProcessor, int x, int y) throws IOException {
      super.readCacheData(cacheSaveVersion, input, usableBuffer, integerByteBuffer, inRegion, mapProcessor, x, y);
      this.tileChunk.readCacheData(cacheSaveVersion, input, usableBuffer, integerByteBuffer, mapProcessor, x, y);
   }

   public void resetHeights() {
      Misc.clearHeightsData586(this.heightValues.getData());
   }

   public boolean shouldHaveContentForBranchUpdate() {
      return this.tileChunk.getLoadState() > 0 && super.shouldHaveContentForBranchUpdate();
   }

   public void deleteTexturesAndBuffers() {
      synchronized(this.region.getLevel() == 3 ? this.region : this.region.getParent()) {
         synchronized(this.region) {
            this.tileChunk.setLoadState((byte)0);
         }
      }

      super.deleteTexturesAndBuffers();
   }
}
