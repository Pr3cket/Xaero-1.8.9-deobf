package xaero.map.region;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LeveledRegionManager {
   public static final int MAX_LEVEL = 3;
   private HashMap<Integer, HashMap<Integer, LeveledRegion<?>>> regionTextureMap = new HashMap();
   private Set<LeveledRegion<?>> regionsListAll = new HashSet();
   private List<LeveledRegion<?>> regionsListLoaded = new ArrayList();

   public void putLeaf(int X, int Z, MapRegion leaf) {
      int maxLevelX = X >> 3;
      int maxLevelZ = Z >> 3;
      HashMap column;
      synchronized(this.regionTextureMap) {
         column = (HashMap)this.regionTextureMap.get(maxLevelX);
         if (column == null) {
            column = new HashMap();
            this.regionTextureMap.put(maxLevelX, column);
         }
      }

      Object rootBranch;
      synchronized(column) {
         rootBranch = (LeveledRegion)column.get(maxLevelZ);
         if (rootBranch == null) {
            rootBranch = new BranchLeveledRegion(leaf.getWorldId(), leaf.getDimId(), leaf.getMwId(), leaf.getDim(), 3, maxLevelX, maxLevelZ, (BranchLeveledRegion)null);
            column.put(maxLevelZ, rootBranch);
            this.addListRegion((LeveledRegion)rootBranch);
         }
      }

      if (!(rootBranch instanceof MapRegion)) {
         ((LeveledRegion)rootBranch).putLeaf(X, Z, leaf);
      }

   }

   public MapRegion getLeaf(int X, int Z) {
      return (MapRegion)this.get(X, Z, 0);
   }

   public LeveledRegion<?> get(int leveledX, int leveledZ, int level) {
      if (level > 3) {
         throw new RuntimeException(new IllegalArgumentException());
      } else {
         int maxLevelX = leveledX >> 3 - level;
         int maxLevelZ = leveledZ >> 3 - level;
         HashMap column;
         synchronized(this.regionTextureMap) {
            column = (HashMap)this.regionTextureMap.get(maxLevelX);
         }

         if (column == null) {
            return null;
         } else {
            LeveledRegion rootBranch;
            synchronized(column) {
               rootBranch = (LeveledRegion)column.get(maxLevelZ);
            }

            if (rootBranch == null) {
               return null;
            } else {
               return level == 3 ? rootBranch : rootBranch.get(leveledX, leveledZ, level);
            }
         }
      }
   }

   public boolean remove(int leveledX, int leveledZ, int level) {
      if (level > 3) {
         throw new RuntimeException(new IllegalArgumentException());
      } else {
         int maxLevelX = leveledX >> 3 - level;
         int maxLevelZ = leveledZ >> 3 - level;
         HashMap column;
         synchronized(this.regionTextureMap) {
            column = (HashMap)this.regionTextureMap.get(maxLevelX);
         }

         if (column == null) {
            return false;
         } else {
            LeveledRegion rootBranch;
            synchronized(column) {
               rootBranch = (LeveledRegion)column.get(maxLevelZ);
            }

            if (rootBranch == null) {
               return false;
            } else if (!(rootBranch instanceof MapRegion)) {
               return rootBranch.remove(leveledX, leveledZ, level);
            } else {
               synchronized(column) {
                  column.remove(maxLevelZ);
                  return true;
               }
            }
         }
      }
   }

   public int loadedCount() {
      return this.regionsListLoaded.size();
   }

   public void removeListRegion(LeveledRegion<?> reg) {
      synchronized(this.regionsListAll) {
         this.regionsListAll.remove(reg);
      }
   }

   public void addListRegion(LeveledRegion<?> reg) {
      synchronized(this.regionsListAll) {
         this.regionsListAll.add(reg);
      }
   }

   public void bumpLoadedRegion(MapRegion reg) {
      this.bumpLoadedRegion((LeveledRegion)reg);
   }

   public void bumpLoadedRegion(LeveledRegion<?> reg) {
      synchronized(this.regionsListLoaded) {
         if (this.regionsListLoaded.remove(reg)) {
            this.regionsListLoaded.add(reg);
         }

      }
   }

   public void clear() {
      synchronized(this.regionTextureMap) {
         this.regionTextureMap.clear();
      }

      synchronized(this.regionsListAll) {
         this.regionsListAll.clear();
      }

      synchronized(this.regionsListLoaded) {
         this.regionsListLoaded.clear();
      }
   }

   public List<LeveledRegion<?>> getLoadedListUnsynced() {
      return this.regionsListLoaded;
   }

   public LeveledRegion<?> getLoadedRegion(int index) {
      synchronized(this.regionsListLoaded) {
         return (LeveledRegion)this.regionsListLoaded.get(index);
      }
   }

   public void addLoadedRegion(LeveledRegion<?> reg) {
      synchronized(this.regionsListLoaded) {
         this.regionsListLoaded.add(reg);
      }
   }

   public void removeLoadedRegion(LeveledRegion<?> reg) {
      synchronized(this.regionsListLoaded) {
         this.regionsListLoaded.remove(reg);
      }
   }

   public int size() {
      return this.regionsListAll.size();
   }

   public Set<LeveledRegion<?>> getUnsyncedList() {
      return this.regionsListAll;
   }
}
