package xaero.map.region;

import xaero.map.pool.PoolUnit;

public class MapTile implements PoolUnit {
   private boolean loaded;
   private int chunkX;
   private int chunkZ;
   private MapBlock[][] blocks = new MapBlock[16][16];
   private boolean writtenOnce;

   public MapTile(Object... args) {
      this.create(args);
   }

   public void create(Object... args) {
      this.chunkX = (Integer)args[1];
      this.chunkZ = (Integer)args[2];
      this.loaded = false;
      this.writtenOnce = false;
   }

   public boolean isLoaded() {
      return this.loaded;
   }

   public void setLoaded(boolean loaded) {
      this.loaded = loaded;
   }

   public MapBlock getBlock(int x, int z) {
      return this.blocks[x][z];
   }

   public MapBlock[] getBlockColumn(int x) {
      return this.blocks[x];
   }

   public void setBlock(int x, int z, MapBlock block) {
      this.blocks[x][z] = block;
   }

   public int getChunkX() {
      return this.chunkX;
   }

   public int getChunkZ() {
      return this.chunkZ;
   }

   public boolean wasWrittenOnce() {
      return this.writtenOnce;
   }

   public void setWrittenOnce(boolean writtenOnce) {
      this.writtenOnce = writtenOnce;
   }
}
