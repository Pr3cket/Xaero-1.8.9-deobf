package xaero.map.region;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.file.MapSaveLoad;
import xaero.map.region.texture.RegionTexture;
import xaero.map.world.MapDimension;

public abstract class LeveledRegion<T extends RegionTexture<T>> implements Comparable<LeveledRegion<T>> {
   public static final int SIDE_LENGTH = 8;
   private static int comparisonX = 0;
   private static int comparisonZ = 0;
   protected static int comparisonLevel;
   private static int comparisonLeafX = 0;
   private static int comparisonLeafZ = 0;
   protected BranchLeveledRegion parent;
   protected int regionX;
   protected int regionZ;
   protected int level;
   private boolean allCachePrepared;
   protected boolean shouldCache;
   protected boolean recacheHasBeenRequested;
   protected boolean reloadHasBeenRequested;
   protected File cacheFile = null;
   protected String worldId;
   protected String dimId;
   protected String mwId;
   protected MapDimension dim;
   public int activeBranchUpdateReferences;
   public int[][] leafTextureVersionSum = new int[8][8];
   protected int[][] cachedTextureVersions = new int[8][8];
   protected boolean metaLoaded;
   private int distanceFromPlayerCache;
   private int leafDistanceFromPlayerCache;
   protected long lastSaveTime;

   public LeveledRegion(String worldId, String dimId, String mwId, MapDimension dim, int level, int leveledX, int leveledZ, BranchLeveledRegion parent) {
      this.worldId = worldId;
      this.dimId = dimId;
      this.mwId = mwId;
      this.dim = dim;
      this.level = level;
      this.regionX = leveledX;
      this.regionZ = leveledZ;
      this.parent = parent;
   }

   public void onDimensionClear(MapProcessor mapProcessor) {
      this.deleteTexturesAndBuffers();
   }

   public void deleteTexturesAndBuffers() {
      synchronized(this) {
         this.setAllCachePrepared(false);
      }

      if (this.hasTextures()) {
         for(int i = 0; i < 8; ++i) {
            for(int j = 0; j < 8; ++j) {
               T texture = this.getTexture(i, j);
               if (texture != null) {
                  synchronized(this) {
                     this.setAllCachePrepared(false);
                     texture.setCachePrepared(false);
                  }

                  texture.deleteTexturesAndBuffers();
                  if (this.level > 0) {
                     this.putTexture(i, j, (RegionTexture)null);
                  }
               }
            }
         }
      }

   }

   public boolean hasTextures() {
      return true;
   }

   public void deleteBuffers() {
      synchronized(this) {
         this.setAllCachePrepared(false);
      }

      if (this.hasTextures()) {
         for(int i = 0; i < 8; ++i) {
            for(int j = 0; j < 8; ++j) {
               T texture = this.getTexture(i, j);
               if (texture != null && texture.getColorBuffer() != null) {
                  synchronized(this) {
                     this.setAllCachePrepared(false);
                     texture.setCachePrepared(false);
                  }

                  texture.setToUpload(false);
                  texture.deleteBuffers();
               }
            }
         }
      }

   }

   public void deleteGLBuffers() {
      if (this.hasTextures()) {
         for(int i = 0; i < 8; ++i) {
            for(int j = 0; j < 8; ++j) {
               T texture = this.getTexture(i, j);
               if (texture != null) {
                  texture.deletePBOs();
               }
            }
         }
      }

   }

   public boolean isAllCachePrepared() {
      return this.allCachePrepared;
   }

   public void setAllCachePrepared(boolean allCachePrepared) {
      if (this.allCachePrepared && !allCachePrepared && WorldMap.settings.detailed_debug) {
         System.out.println("Cancelling cache: " + this);
      }

      this.allCachePrepared = allCachePrepared;
   }

   public int getRegionX() {
      return this.regionX;
   }

   public int getRegionZ() {
      return this.regionZ;
   }

   public boolean shouldCache() {
      return this.shouldCache;
   }

   public int getLevel() {
      return this.level;
   }

   public void setShouldCache(boolean shouldCache, String by) {
      this.shouldCache = shouldCache;
      if (WorldMap.settings.detailed_debug) {
         System.out.println("shouldCache set to " + shouldCache + " by " + by + " for " + this);
      }

   }

   public boolean recacheHasBeenRequested() {
      return this.recacheHasBeenRequested;
   }

   public void setRecacheHasBeenRequested(boolean recacheHasBeenRequested, String by) {
      if (WorldMap.settings.detailed_debug && recacheHasBeenRequested != this.recacheHasBeenRequested) {
         System.out.println("Recache set to " + recacheHasBeenRequested + " by " + by + " for " + this);
      }

      this.recacheHasBeenRequested = recacheHasBeenRequested;
   }

   public File getCacheFile() {
      return this.cacheFile;
   }

   public void setCacheFile(File cacheFile) {
      this.cacheFile = cacheFile;
   }

   public MapDimension getDim() {
      return this.dim;
   }

   public String toString() {
      return this.regionX + "_" + this.regionZ + " L" + this.level + " " + super.toString();
   }

   public boolean reloadHasBeenRequested() {
      return this.reloadHasBeenRequested;
   }

   public void setReloadHasBeenRequested(boolean reloadHasBeenRequested, String by) {
      if (WorldMap.settings.detailed_debug && reloadHasBeenRequested != this.reloadHasBeenRequested) {
         System.out.println("Reload set to " + reloadHasBeenRequested + " by " + by + " for " + this);
      }

      this.reloadHasBeenRequested = reloadHasBeenRequested;
   }

   public static void setComparison(int x, int z, int level, int leafX, int leafZ) {
      comparisonX = x;
      comparisonZ = z;
      comparisonLevel = level;
      comparisonLeafX = leafX;
      comparisonLeafZ = leafZ;
   }

   protected int distanceFromPlayer() {
      int toRegionX = (this.regionX << this.level >> comparisonLevel) - comparisonX;
      int toRegionZ = (this.regionZ << this.level >> comparisonLevel) - comparisonZ;
      return (int)Math.sqrt((double)(toRegionX * toRegionX + toRegionZ * toRegionZ));
   }

   protected int leafDistanceFromPlayer() {
      int toRegionX = (this.regionX << this.level) - comparisonLeafX;
      int toRegionZ = (this.regionZ << this.level) - comparisonLeafZ;
      return (int)Math.sqrt((double)(toRegionX * toRegionX + toRegionZ * toRegionZ));
   }

   public void calculateSortingDistance() {
      this.distanceFromPlayerCache = this.distanceFromPlayer();
      this.leafDistanceFromPlayerCache = this.leafDistanceFromPlayer();
   }

   public int compareTo(LeveledRegion<T> arg0) {
      if (this.level == 3 && arg0.level != 3) {
         return -1;
      } else if (arg0.level == 3 && this.level != 3) {
         return 1;
      } else if (this.level == comparisonLevel && arg0.level != comparisonLevel) {
         return -1;
      } else if (arg0.level == comparisonLevel && this.level != comparisonLevel) {
         return 1;
      } else {
         int toRegion = this.distanceFromPlayerCache;
         int toRegion2 = arg0.distanceFromPlayerCache;
         if (toRegion > toRegion2) {
            return 1;
         } else if (toRegion == toRegion2) {
            toRegion = this.leafDistanceFromPlayerCache;
            toRegion2 = arg0.leafDistanceFromPlayerCache;
            if (toRegion > toRegion2) {
               return 1;
            } else {
               return toRegion == toRegion2 ? 0 : -1;
            }
         } else {
            return -1;
         }
      }
   }

   public void onProcessingEnd() {
   }

   public void addDebugLines(List<String> debugLines, MapProcessor mapProcessor, int textureX, int textureY) {
      debugLines.add("processed: " + mapProcessor.isProcessed(this));
      debugLines.add(String.format("recache: %s reload: %s metaLoaded: %s", this.recacheHasBeenRequested(), this.reloadHasBeenRequested(), this.metaLoaded));
      debugLines.add("shouldCache: " + this.shouldCache());
      debugLines.add("activeBranchUpdateReferences: " + this.activeBranchUpdateReferences);
      debugLines.add("leafTextureVersionSum: " + this.leafTextureVersionSum[textureX][textureY] + " cachedTextureVersions: " + this.cachedTextureVersions[textureX][textureY] + " [" + textureX + "," + textureY + "]");
   }

   protected void writeCacheMetaData(DataOutputStream output, byte[] usableBuffer, byte[] integerByteBuffer) throws IOException {
      for(int i = 0; i < 8; ++i) {
         for(int j = 0; j < 8; ++j) {
            T texture = this.getTexture(i, j);
            if (texture != null) {
               if (!texture.isCachePrepared()) {
                  throw new RuntimeException("Trying to save cache but " + i + " " + j + " in " + this + " is not prepared.");
               }

               output.write(i << 4 | j);
               int bufferedTextureVersion = texture.getBufferedTextureVersion();
               output.writeInt(bufferedTextureVersion);
            }
         }
      }

      output.write(255);
   }

   public void saveCacheTextures(File tempFile) throws IOException {
      if (WorldMap.settings.debug) {
         System.out.println("Saving cache: " + this);
      }

      ZipOutputStream zipOutput = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tempFile)));
      DataOutputStream output = new DataOutputStream(zipOutput);
      ZipEntry e = new ZipEntry("cache.xaero");
      zipOutput.putNextEntry(e);
      byte[] usableBuffer = new byte[16384];
      byte[] integerByteBuffer = new byte[4];
      output.writeInt(15);
      this.writeCacheMetaData(output, usableBuffer, integerByteBuffer);

      for(int i = 0; i < 8; ++i) {
         for(int j = 0; j < 8; ++j) {
            T texture = this.getTexture(i, j);
            if (texture != null) {
               if (!texture.isCachePrepared()) {
                  throw new RuntimeException("Trying to save cache but " + i + " " + j + " in " + this + " is not prepared.");
               }

               output.write(i << 4 | j);
               texture.writeCacheMapData(output, usableBuffer, integerByteBuffer, this);
            }
         }
      }

      output.write(255);
      zipOutput.closeEntry();
      output.close();
   }

   protected void readCacheMetaData(DataInputStream input, int cacheSaveVersion, byte[] usableBuffer, byte[] integerByteBuffer, MapProcessor mapProcessor) throws IOException {
      if (cacheSaveVersion == 8 || cacheSaveVersion >= 12) {
         this.readCacheInput(true, input, cacheSaveVersion, usableBuffer, integerByteBuffer, mapProcessor);
      }

   }

   public boolean loadCacheTextures(MapProcessor mapProcessor, boolean justMetaData) {
      if (this.cacheFile == null) {
         return false;
      } else {
         if (this.cacheFile.exists()) {
            ZipInputStream zipInput = null;
            DataInputStream input = null;

            try {
               zipInput = new ZipInputStream(new BufferedInputStream(new FileInputStream(this.cacheFile)));
               input = new DataInputStream(zipInput);
               ZipEntry entry = zipInput.getNextEntry();
               if (entry != null) {
                  byte[] integerByteBuffer = new byte[4];
                  int cacheSaveVersion = input.readInt();
                  if (cacheSaveVersion <= 15 && cacheSaveVersion != 7) {
                     byte[] usableBuffer = new byte[16384];
                     boolean var9;
                     if (cacheSaveVersion >= 8) {
                        this.readCacheMetaData(input, cacheSaveVersion, usableBuffer, integerByteBuffer, mapProcessor);
                        this.metaLoaded = true;
                        if (justMetaData && (cacheSaveVersion == 8 || cacheSaveVersion >= 12)) {
                           var9 = true;
                           return var9;
                        }
                     }

                     if (cacheSaveVersion < 15) {
                        this.shouldCache = true;
                     }

                     this.preCacheLoad();
                     this.readCacheInput(false, input, cacheSaveVersion, usableBuffer, integerByteBuffer, mapProcessor);
                     this.metaLoaded = true;
                     zipInput.closeEntry();
                     var9 = false;
                     return var9;
                  }

                  input.close();
                  System.out.println("Trying to load newer region cache " + this + " using an older version of Xaero's World Map!");
                  mapProcessor.getMapSaveLoad().backupFile(this.cacheFile, cacheSaveVersion);
                  this.cacheFile = null;
                  this.shouldCache = true;
                  boolean var8 = false;
                  return var8;
               }
            } catch (Throwable var29) {
               this.cacheFile = null;
               this.shouldCache = true;
               System.out.println("Failed to load cache for region " + this + "! " + this.cacheFile);
               var29.printStackTrace();
            } finally {
               if (input != null) {
                  try {
                     input.close();
                  } catch (IOException var28) {
                  }
               } else if (zipInput != null) {
                  try {
                     zipInput.close();
                  } catch (IOException var27) {
                  }
               }

            }
         } else {
            this.cacheFile = null;
            this.shouldCache = true;
         }

         return false;
      }
   }

   private void readCacheInput(boolean isMeta, DataInputStream input, int cacheSaveVersion, byte[] usableBuffer, byte[] integerByteBuffer, MapProcessor mapProcessor) throws IOException {
      for(int textureCoords = input.read(); textureCoords != -1 && textureCoords != 255; textureCoords = input.read()) {
         int x = textureCoords >> 4;
         int y = textureCoords & 15;
         if (isMeta) {
            int cachedTextureVersion = input.readInt();
            this.cachedTextureVersions[x][y] = cachedTextureVersion;
            this.updateLeafTextureVersion(x, y, cachedTextureVersion);
         } else {
            RegionTexture<T> texture = this.hasTextures() ? this.getTexture(x, y) : null;
            if (texture == null) {
               texture = this.createTexture(x, y);
            }

            texture.readCacheData(cacheSaveVersion, input, usableBuffer, integerByteBuffer, this, mapProcessor, x, y);
         }
      }

   }

   public int getCachedTextureVersions(int x, int y) {
      return this.cachedTextureVersions[x][y];
   }

   public BranchLeveledRegion getParent() {
      return this.parent;
   }

   public boolean shouldAffectLoadingRequestFrequency() {
      return this.shouldBeProcessed();
   }

   protected void preCacheLoad() {
   }

   public void processWhenLoadedChunksExist(int globalRegionCacheHashCode) {
   }

   public boolean isMetaLoaded() {
      return this.metaLoaded;
   }

   public LeveledRegion<?> getRootRegion() {
      LeveledRegion<?> result = this;
      if (this.parent != null) {
         result = this.parent.getRootRegion();
      }

      return result;
   }

   public void checkForUpdates(MapProcessor mapProcessor, boolean prevWaitingForBranchCache, boolean[] waitingForBranchCache, ArrayList<BranchLeveledRegion> branchRegionBuffer, int viewedLevel, int minViewedLeafX, int minViewedLeafZ, int maxViewedLeafX, int maxViewedLeafZ) {
   }

   public abstract boolean shouldEndProcessingAfterUpload();

   protected abstract T createTexture(int var1, int var2);

   public abstract void putTexture(int var1, int var2, T var3);

   public abstract T getTexture(int var1, int var2);

   protected abstract void putLeaf(int var1, int var2, MapRegion var3);

   protected abstract boolean remove(int var1, int var2, int var3);

   protected abstract LeveledRegion<?> get(int var1, int var2, int var3);

   public abstract boolean loadingAnimation();

   public abstract boolean cleanAndCacheRequestsBlocked();

   public abstract boolean shouldBeProcessed();

   public abstract boolean isLoaded();

   public abstract void preCache();

   public abstract void postCache(File var1, MapSaveLoad var2) throws IOException;

   public abstract boolean skipCaching(MapProcessor var1);

   public abstract File findCacheFile(MapSaveLoad var1) throws IOException;

   public abstract void onCurrentDimFinish(MapSaveLoad var1, MapProcessor var2);

   public abstract void onLimiterRemoval(MapProcessor var1);

   public abstract void afterLimiterRemoval(MapProcessor var1);

   public String getExtraInfo() {
      return "";
   }

   public void updateLeafTextureVersion(int localTextureX, int localTextureZ, int newVersion) {
   }

   public boolean hasRemovableSourceData() {
      return false;
   }
}
