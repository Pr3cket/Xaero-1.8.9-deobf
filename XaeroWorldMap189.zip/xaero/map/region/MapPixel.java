package xaero.map.region;

import java.util.ArrayList;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.world.World;
import xaero.map.MapWriter;
import xaero.map.WorldMap;
import xaero.map.misc.Misc;

public class MapPixel {
   private static final float DEFAULT_AMBIENT_LIGHT = 0.7F;
   private static final float DEFAULT_AMBIENT_LIGHT_COLORED = 0.2F;
   private static final float DEFAULT_AMBIENT_LIGHT_WHITE = 0.5F;
   private static final float DEFAULT_MAX_DIRECT_LIGHT = 0.6666667F;
   private static final float GLOWING_MAX_DIRECT_LIGHT = 0.22222224F;
   protected int state = 0;
   protected byte colourType = -1;
   protected int customColour;
   protected byte light = 0;
   protected boolean glowing = false;

   public void getPixelColours(int[] result_dest, MapWriter mapWriter, World world, MapTileChunk tileChunk, MapTileChunk prevChunk, MapTileChunk prevChunkDiagonal, MapTileChunk prevChunkHorisontal, MapTile mapTile, int x, int z, MapBlock block, int height, ArrayList<Overlay> overlays, MutableBlockPos mutableGlobalPos, float shadowR, float shadowG, float shadowB) {
      int colour = 0;
      int topLightValue = this.light;
      int lightMin = 9;
      float brightnessR = 1.0F;
      float brightnessG = 1.0F;
      float brightnessB = 1.0F;
      mutableGlobalPos.func_181079_c(mapTile.getChunkX() * 16 + x, height, mapTile.getChunkZ() * 16 + z);
      if (this.state != 0) {
         if (WorldMap.settings.colours == 0) {
            colour = mapWriter.loadBlockColourFromTexture(this.state, true, mutableGlobalPos);
         } else {
            try {
               IBlockState blockState = Misc.getStateById(this.state);
               if (blockState.func_177230_c() instanceof BlockLiquid && blockState.func_177230_c().func_149717_k() != 255 && blockState.func_177230_c().func_149717_k() != 0) {
                  colour = 25825;
               } else {
                  colour = blockState.func_177230_c().func_180659_g(blockState).field_76291_p;
               }
            } catch (Exception var44) {
            }
         }
      }

      int r = colour >> 16 & 255;
      int g = colour >> 8 & 255;
      int b = colour & 255;
      boolean isFinalBlock = this instanceof MapBlock;
      if (this.colourType == -1) {
         IBlockState blockState = Misc.getStateById(this.state);
         if (isFinalBlock) {
            mapWriter.getColorTypeCache().getBlockBiomeColour(world, blockState, mutableGlobalPos, result_dest, block.getBiome());
            this.colourType = (byte)result_dest[0];
            if (result_dest[1] != -1) {
               block.setBiome(result_dest[1]);
            }

            this.customColour = result_dest[2];
         } else {
            mapWriter.getColorTypeCache().getOverlayBiomeColour(world, blockState, mutableGlobalPos, result_dest, 1);
            this.colourType = (byte)result_dest[0];
            this.customColour = result_dest[2];
         }
      }

      float rMultiplier;
      float gMultiplier;
      float currentTransparencyMultiplier;
      int overlayRed;
      if (this.colourType != 0 && (WorldMap.settings.biomeColorsVanillaMode || WorldMap.settings.colours == 0)) {
         overlayRed = this.customColour;
         if (isFinalBlock) {
            if (this.colourType == 1) {
               overlayRed = mapWriter.getBiomeColor(0, mutableGlobalPos, mapTile, world);
            } else if (this.colourType == 2) {
               overlayRed = mapWriter.getBiomeColor(1, mutableGlobalPos, mapTile, world);
            }
         } else if (this.colourType == 1) {
            overlayRed = mapWriter.getBiomeColor(2, mutableGlobalPos, mapTile, world);
         }

         rMultiplier = (float)r / 255.0F;
         gMultiplier = (float)g / 255.0F;
         currentTransparencyMultiplier = (float)b / 255.0F;
         r = (int)((float)(overlayRed >> 16 & 255) * rMultiplier);
         g = (int)((float)(overlayRed >> 8 & 255) * gMultiplier);
         b = (int)((float)(overlayRed & 255) * currentTransparencyMultiplier);
      }

      if (this.glowing) {
         overlayRed = r + g + b;
         rMultiplier = 407.0F;
         gMultiplier = Math.max(1.0F, rMultiplier / (float)overlayRed);
         r = (int)((float)r * gMultiplier);
         g = (int)((float)g * gMultiplier);
         b = (int)((float)b * gMultiplier);
         topLightValue = 15;
      }

      overlayRed = 0;
      int overlayGreen = 0;
      int overlayBlue = 0;
      currentTransparencyMultiplier = 1.0F;
      int slopes;
      float ambientLightColored;
      if (overlays != null && !overlays.isEmpty()) {
         int sun = 15;

         for(slopes = 0; slopes < overlays.size(); ++slopes) {
            Overlay o = (Overlay)overlays.get(slopes);
            o.getPixelColour(block, result_dest, mapWriter, world, tileChunk, prevChunk, prevChunkDiagonal, prevChunkHorisontal, mapTile, x, z, mutableGlobalPos, shadowR, shadowG, shadowB);
            if (slopes == 0) {
               topLightValue = o.light;
            }

            float transparency = o.getTransparency();
            ambientLightColored = this.getBlockBrightness((float)lightMin, o.light, sun) * transparency * currentTransparencyMultiplier;
            overlayRed = (int)((float)overlayRed + (float)result_dest[0] * ambientLightColored);
            overlayGreen = (int)((float)overlayGreen + (float)result_dest[1] * ambientLightColored);
            overlayBlue = (int)((float)overlayBlue + (float)result_dest[2] * ambientLightColored);
            sun -= o.getOpacity();
            if (sun < 0) {
               sun = 0;
            }

            currentTransparencyMultiplier *= 1.0F - transparency;
         }

         if (!this.glowing) {
            brightnessR = brightnessG = brightnessB = this.getBlockBrightness((float)lightMin, this.light, sun);
         }
      }

      if (isFinalBlock) {
         if (block.slopeUnknown) {
            if (block.getState() != 0) {
               block.fixHeightType(x, z, mapTile, tileChunk, prevChunk, prevChunkDiagonal, prevChunkHorisontal, block.getHeight(), false);
            } else {
               block.setVerticalSlope((byte)0);
               block.setDiagonalSlope((byte)0);
               block.slopeUnknown = false;
            }
         }

         float depthBrightness = 1.0F;
         slopes = WorldMap.settings.terrainSlopes;
         float ambientLightWhite;
         float maxDirectLight;
         if (!this.glowing) {
            int block_height = block.getHeight();
            boolean caving = block.isCaveBlock() && block_height != -1 && block_height < 127;
            ambientLightColored = (float)block_height / 127.0F;
            if (caving) {
               brightnessB = ambientLightColored;
               brightnessG = ambientLightColored;
               brightnessR = ambientLightColored;
            }

            if (!caving && WorldMap.settings.terrainDepth && block_height != -1) {
               depthBrightness = (float)height / 63.0F;
               ambientLightWhite = slopes >= 2 ? 1.0F : 1.15F;
               maxDirectLight = slopes >= 2 ? 0.9F : 0.7F;
               if (depthBrightness > ambientLightWhite) {
                  depthBrightness = ambientLightWhite;
               } else if (depthBrightness < maxDirectLight) {
                  depthBrightness = maxDirectLight;
               }
            }
         }

         if (slopes > 0 && !block.slopeUnknown) {
            int verticalSlope = block.getVerticalSlope();
            if (slopes == 1) {
               if (verticalSlope > 0) {
                  depthBrightness = (float)((double)depthBrightness * 1.15D);
               } else if (verticalSlope < 0) {
                  depthBrightness = (float)((double)depthBrightness * 0.85D);
               }
            } else {
               int diagonalSlope = block.getDiagonalSlope();
               ambientLightColored = 0.2F;
               ambientLightWhite = 0.5F;
               maxDirectLight = 0.6666667F;
               if (this.glowing) {
                  ambientLightColored = 0.0F;
                  ambientLightWhite = 1.0F;
                  maxDirectLight = 0.22222224F;
               }

               float cos = 0.0F;
               float directLightClamped;
               float whiteLight;
               if (slopes == 2) {
                  directLightClamped = (float)(-verticalSlope);
                  if (directLightClamped < 1.0F) {
                     if (verticalSlope == 1 && diagonalSlope == 1) {
                        cos = 1.0F;
                     } else {
                        whiteLight = (float)(verticalSlope - diagonalSlope);
                        float cast = 1.0F - directLightClamped;
                        float crossMagnitude = (float)Math.sqrt((double)(whiteLight * whiteLight + 1.0F + directLightClamped * directLightClamped));
                        cos = (float)((double)(cast / crossMagnitude) / Math.sqrt(2.0D));
                     }
                  }
               } else if (verticalSlope >= 0) {
                  if (verticalSlope == 1) {
                     cos = 1.0F;
                  } else {
                     directLightClamped = (float)Math.sqrt((double)(verticalSlope * verticalSlope + 1));
                     whiteLight = (float)(verticalSlope + 1);
                     cos = (float)((double)(whiteLight / directLightClamped) / Math.sqrt(2.0D));
                  }
               }

               directLightClamped = 0.0F;
               if (cos == 1.0F) {
                  directLightClamped = maxDirectLight;
               } else if (cos > 0.0F) {
                  directLightClamped = (float)Math.ceil((double)(cos * 10.0F)) / 10.0F * maxDirectLight * 0.88388F;
               }

               whiteLight = ambientLightWhite + directLightClamped;
               brightnessR *= shadowR * ambientLightColored + whiteLight;
               brightnessG *= shadowG * ambientLightColored + whiteLight;
               brightnessB *= shadowB * ambientLightColored + whiteLight;
            }
         }

         brightnessR *= depthBrightness;
         brightnessG *= depthBrightness;
         brightnessB *= depthBrightness;
      }

      result_dest[0] = (int)((float)r * brightnessR * currentTransparencyMultiplier + (float)overlayRed);
      if (result_dest[0] > 255) {
         result_dest[0] = 255;
      }

      result_dest[1] = (int)((float)g * brightnessG * currentTransparencyMultiplier + (float)overlayGreen);
      if (result_dest[1] > 255) {
         result_dest[1] = 255;
      }

      result_dest[2] = (int)((float)b * brightnessB * currentTransparencyMultiplier + (float)overlayBlue);
      if (result_dest[2] > 255) {
         result_dest[2] = 255;
      }

      result_dest[3] = (int)(this.getPixelLight((float)lightMin, topLightValue) * 255.0F);
   }

   public float getBlockBrightness(float min, int l, int sun) {
      return (min + (float)Math.max(sun, l)) / (15.0F + min);
   }

   private float getPixelLight(float min, int topLightValue) {
      return topLightValue == 0 ? 0.0F : this.getBlockBrightness(min, topLightValue, 0);
   }

   public int getState() {
      return this.state;
   }

   public void setState(int state) {
      this.state = state;
   }

   public void setLight(byte light) {
      this.light = light;
   }

   public void setGlowing(boolean glowing) {
      this.glowing = glowing;
   }

   public byte getColourType() {
      return this.colourType;
   }

   public void setColourType(byte colourType) {
      this.colourType = colourType;
   }

   public int getCustomColour() {
      return this.customColour;
   }

   public void setCustomColour(int customColour) {
      this.customColour = customColour;
   }
}
