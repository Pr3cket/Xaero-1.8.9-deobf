package xaero.map.region;

import java.util.ArrayList;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.world.World;
import xaero.map.MapWriter;

public class MapBlock extends MapPixel {
   protected boolean slopeUnknown = true;
   private byte verticalSlope;
   private byte diagonalSlope;
   private byte signed_height;
   private ArrayList<Overlay> overlays;
   private boolean caveBlock = false;
   private int biome = -1;

   public boolean isGrass() {
      return (this.state & -65536) == 0 && (this.state & 4095) == 2;
   }

   public int getParametres() {
      int usedColourType = this.colourType < 0 ? 0 : this.colourType & 3;
      int parametres = 0;
      int parametres = parametres | (!this.isGrass() ? 1 : 0);
      parametres |= this.getNumberOfOverlays() != 0 ? 2 : 0;
      parametres |= usedColourType << 2;
      parametres |= this.caveBlock ? 128 : 0;
      parametres |= this.light << 8;
      parametres |= this.getHeight() << 12;
      parametres |= this.biome != -1 ? 1048576 : 0;
      return parametres;
   }

   public void getPixelColour(int[] result_dest, MapWriter mapWriter, World world, MapTileChunk tileChunk, MapTileChunk prevChunk, MapTileChunk prevChunkDiagonal, MapTileChunk prevChunkHorisontal, MapTile mapTile, int x, int z, MutableBlockPos mutableGlobalPos, float shadowR, float shadowG, float shadowB) {
      super.getPixelColours(result_dest, mapWriter, world, tileChunk, prevChunk, prevChunkDiagonal, prevChunkHorisontal, mapTile, x, z, this, this.getHeight(), this.overlays, mutableGlobalPos, shadowR, shadowG, shadowB);
   }

   public String toString() {
      return "S: " + this.getState() + ", VS: " + this.verticalSlope + ", DS: " + this.diagonalSlope + ", SU: " + this.slopeUnknown + ", H: " + this.getHeight() + ", CT: " + this.colourType + ", B: " + this.biome + ", CC: " + this.customColour + ", L: " + this.light + ", G: " + this.glowing + ", CB: " + this.caveBlock + ", O: " + this.getNumberOfOverlays();
   }

   public boolean equalsSlopesExcluded(MapBlock p) {
      boolean equal = p != null && this.state == p.state && this.colourType == p.colourType && this.light == p.light && this.signed_height == p.signed_height && this.caveBlock == p.caveBlock && this.getNumberOfOverlays() == p.getNumberOfOverlays() && this.biome == p.biome && (this.colourType != 3 || this.customColour == p.customColour);
      if (equal && this.getNumberOfOverlays() != 0) {
         for(int i = 0; i < this.overlays.size(); ++i) {
            if (!((Overlay)this.overlays.get(i)).equals((Overlay)p.overlays.get(i))) {
               return false;
            }
         }
      }

      return equal;
   }

   public boolean equals(MapBlock p, boolean equalsSlopesExcluded) {
      return p != null && this.verticalSlope == p.verticalSlope && this.diagonalSlope == p.diagonalSlope && this.slopeUnknown == p.slopeUnknown && equalsSlopesExcluded;
   }

   public void fixHeightType(int x, int z, MapTile mapTile, MapTileChunk tileChunk, MapTileChunk prevChunk, MapTileChunk prevChunkDiagonal, MapTileChunk prevChunkHorisontal, int height, boolean writing) {
      int prevHeight = -1;
      int prevHeightDiagonal = -1;
      if (z > 0) {
         prevHeight = mapTile.getBlock(x, z - 1).getHeight();
         if (x > 0) {
            prevHeightDiagonal = mapTile.getBlock(x - 1, z - 1).getHeight();
         }
      }

      if (prevHeight == -1 || prevHeightDiagonal == -1) {
         int inTileChunkX = (mapTile.getChunkX() & 3) * 16 + x;
         int inTileChunkZ = (mapTile.getChunkZ() & 3) * 16 + z;
         int inTileChunkXPrev = inTileChunkX - 1;
         int inTileChunkZPrev = inTileChunkZ - 1;
         MapTileChunk verticalSlopeSrc = tileChunk;
         MapTileChunk diagonalSlopeSrc = tileChunk;
         boolean verticalEdge = inTileChunkZPrev < 0;
         boolean horisontalEdge = inTileChunkXPrev < 0;
         if (verticalEdge) {
            diagonalSlopeSrc = prevChunk;
            verticalSlopeSrc = prevChunk;
            inTileChunkZPrev = 63;
         }

         if (horisontalEdge) {
            inTileChunkXPrev = 63;
            diagonalSlopeSrc = verticalEdge ? prevChunkDiagonal : prevChunkHorisontal;
         }

         if (prevHeight == -1 && verticalSlopeSrc != null && verticalSlopeSrc.getLoadState() >= 2) {
            prevHeight = verticalSlopeSrc.getLeafTexture().getHeight(inTileChunkX, inTileChunkZPrev);
         }

         if (prevHeightDiagonal == -1 && diagonalSlopeSrc != null && diagonalSlopeSrc.getLoadState() >= 2) {
            prevHeightDiagonal = diagonalSlopeSrc.getLeafTexture().getHeight(inTileChunkXPrev, inTileChunkZPrev);
         }

         if (prevHeight == -1 || prevHeightDiagonal == -1) {
            if (writing) {
               return;
            } else {
               int reX = x < 15 ? x + 1 : x;
               int reZ = z < 15 ? z + 1 : z;
               if (reX == x && reZ == z) {
                  this.verticalSlope = 0;
                  this.diagonalSlope = 0;
                  this.slopeUnknown = false;
                  return;
               } else {
                  MapBlock reBlock;
                  if (mapTile.isLoaded() && (reBlock = mapTile.getBlock(reX, reZ)) != null) {
                     this.fixHeightType(reX, reZ, mapTile, tileChunk, prevChunk, prevChunkDiagonal, prevChunkHorisontal, reBlock.getHeight(), writing);
                  }

                  return;
               }
            }
         }
      }

      this.verticalSlope = (byte)Math.max(-128, Math.min(127, height - prevHeight));
      this.diagonalSlope = (byte)Math.max(-128, Math.min(127, height - prevHeightDiagonal));
      this.slopeUnknown = false;
   }

   public void prepareForWriting() {
      if (this.overlays != null) {
         this.overlays.clear();
      }

      this.customColour = 0;
      this.colourType = 0;
      this.biome = -1;
      this.state = 0;
      this.slopeUnknown = true;
      this.light = 0;
      this.glowing = false;
      this.signed_height = 0;
   }

   public void write(int state, int height, int[] biomeStuff, byte light, boolean glowing, boolean cave) {
      this.state = state;
      this.setHeight(height);
      this.setColourType((byte)biomeStuff[0]);
      if (biomeStuff[1] != -1) {
         this.biome = biomeStuff[1];
      }

      this.setCustomColour(biomeStuff[2]);
      this.light = light;
      this.glowing = glowing;
      this.caveBlock = cave && !glowing;
      if (this.overlays != null && this.overlays.isEmpty()) {
         this.overlays = null;
      }

   }

   public void addOverlay(Overlay o) {
      if (this.overlays == null) {
         this.overlays = new ArrayList();
      }

      this.overlays.add(o);
   }

   public int getHeight() {
      return this.signed_height & 255;
   }

   public byte getSignedHeight() {
      return this.signed_height;
   }

   public void setHeight(int h) {
      this.signed_height = (byte)h;
   }

   public int getBiome() {
      return this.biome;
   }

   public void setBiome(int biome) {
      this.biome = biome;
   }

   public ArrayList<Overlay> getOverlays() {
      return this.overlays;
   }

   public byte getVerticalSlope() {
      return this.verticalSlope;
   }

   public void setVerticalSlope(byte slope) {
      this.verticalSlope = slope;
   }

   public byte getDiagonalSlope() {
      return this.diagonalSlope;
   }

   public void setDiagonalSlope(byte slope) {
      this.diagonalSlope = slope;
   }

   public void setSlopeUnknown(boolean slopeUnknown) {
      this.slopeUnknown = slopeUnknown;
   }

   public boolean isCaveBlock() {
      return this.caveBlock;
   }

   public void setCaveBlock(boolean caveBlock) {
      this.caveBlock = caveBlock;
   }

   public int getNumberOfOverlays() {
      return this.overlays == null ? 0 : this.overlays.size();
   }
}
