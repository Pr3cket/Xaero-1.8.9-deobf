package xaero.map.region;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.util.BlockPos.MutableBlockPos;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.file.MapRegionInfo;
import xaero.map.file.MapSaveLoad;
import xaero.map.file.RegionDetection;
import xaero.map.region.texture.LeafRegionTexture;
import xaero.map.world.MapDimension;

public class MapRegion extends LeveledRegion<LeafRegionTexture> implements MapRegionInfo {
   public static final int SIDE_LENGTH = 8;
   private Boolean saveExists;
   private File regionFile;
   private boolean beingWritten;
   private long lastVisited;
   private byte loadState;
   private int version = -1;
   private int initialVersion;
   private int reloadVersion;
   private final boolean isMultiplayer;
   private MapTileChunk[][] chunks = new MapTileChunk[8][8];
   private boolean isRefreshing;
   public final Object writerThreadPauseSync = new Object();
   private int pauseWriting;
   public boolean loadingPrioritized;
   public int loadingNeededForBranchLevel;
   private int cacheHashCode;
   private int[] pixelResultBuffer = new int[4];
   private MutableBlockPos mutableGlobalPos = new MutableBlockPos();

   public MapRegion(String worldId, String dimId, String mwId, MapDimension dim, int x, int z, int initialVersion, boolean isMultiplayer) {
      super(worldId, dimId, mwId, dim, 0, x, z, (BranchLeveledRegion)null);
      this.initialVersion = initialVersion;
      this.isMultiplayer = isMultiplayer;
      this.lastSaveTime = System.currentTimeMillis();
   }

   public void setParent(BranchLeveledRegion parent) {
      this.parent = parent;
   }

   public void destroyBufferUpdateObjects() {
      this.pixelResultBuffer = null;
      this.mutableGlobalPos = null;
   }

   public void restoreBufferUpdateObjects() {
      this.pixelResultBuffer = new int[4];
      this.mutableGlobalPos = new MutableBlockPos();
   }

   public void requestRefresh(MapProcessor mapProcessor) {
      if (!this.isRefreshing) {
         this.isRefreshing = true;
         mapProcessor.addToRefresh(this);
         if (WorldMap.settings.debug) {
            System.out.println(String.format("Requesting refresh for region %s.", this));
         }
      }

   }

   public void cancelRefresh(MapProcessor mapProcessor) {
      if (this.isRefreshing) {
         this.isRefreshing = false;
         mapProcessor.removeToRefresh(this);
         if (WorldMap.settings.debug) {
            System.out.println(String.format("Canceling refresh for region %s.", this));
         }
      }

   }

   protected int distanceFromPlayer() {
      return this.leafDistanceFromPlayer();
   }

   protected int leafDistanceFromPlayer() {
      return super.leafDistanceFromPlayer() + (comparisonLevel == 0 ? this.loadState * 3 / 2 : 0);
   }

   public void clean(MapProcessor mapProcessor) {
      for(int i = 0; i < this.chunks.length; ++i) {
         for(int j = 0; j < this.chunks.length; ++j) {
            MapTileChunk c = this.chunks[i][j];
            if (c != null) {
               c.clean(mapProcessor);
               this.chunks[i][j] = null;
            }
         }
      }

   }

   protected void writeCacheMetaData(DataOutputStream output, byte[] usableBuffer, byte[] integerByteBuffer) throws IOException {
      output.writeInt(this.cacheHashCode);
      output.writeInt(this.reloadVersion);
      super.writeCacheMetaData(output, usableBuffer, integerByteBuffer);
   }

   protected void readCacheMetaData(DataInputStream input, int cacheSaveVersion, byte[] usableBuffer, byte[] integerByteBuffer, MapProcessor mapProcessor) throws IOException {
      if (cacheSaveVersion >= 9) {
         int saveHashCode = input.readInt();
         this.setCacheHashCode(saveHashCode);
      }

      if (cacheSaveVersion >= 11) {
         this.reloadVersion = input.readInt();
      }

      super.readCacheMetaData(input, cacheSaveVersion, usableBuffer, integerByteBuffer, mapProcessor);
   }

   public void clearRegion(MapProcessor mapProcessor) {
      this.setRecacheHasBeenRequested(false, "clearing");
      this.cancelRefresh(mapProcessor);

      for(int i = 0; i < 8; ++i) {
         for(int j = 0; j < 8; ++j) {
            MapTileChunk c = this.getChunk(i, j);
            if (c != null) {
               c.setLoadState((byte)3);
               this.setLoadState((byte)3);
               c.clean(mapProcessor);
            }
         }
      }

      if (!mapProcessor.getMapSaveLoad().toCacheContains(this)) {
         this.deleteBuffers();
      }

      this.deleteGLBuffers();
      this.setLoadState((byte)4);
      if (WorldMap.settings.debug) {
         System.out.println("Cleared region! " + this + " " + this.getWorldId() + " " + this.getDimId() + " " + this.getMwId());
      }

   }

   public boolean isResting() {
      return this.loadState != 3 && this.loadState != 1 && !this.recacheHasBeenRequested;
   }

   public String getWorldId() {
      return this.worldId;
   }

   public String getDimId() {
      return this.dimId;
   }

   public String getMwId() {
      return this.mwId;
   }

   public int getVersion() {
      return this.version;
   }

   public void setVersion(int version) {
      this.version = version;
      if (WorldMap.settings.detailed_debug) {
         System.out.println("Version set to " + version + " by for " + this);
      }

   }

   public boolean isBeingWritten() {
      return this.beingWritten;
   }

   public void setBeingWritten(boolean beingWritten) {
      this.beingWritten = beingWritten;
   }

   public byte getLoadState() {
      return this.loadState;
   }

   public void setLoadState(byte loadState) {
      this.loadState = loadState;
   }

   public MapTileChunk getChunk(int x, int z) {
      return this.chunks[x][z];
   }

   public void setChunk(int x, int z, MapTileChunk chunk) {
      this.chunks[x][z] = chunk;
   }

   public int getInitialVersion() {
      return this.initialVersion;
   }

   public void setInitialVersion(int initialVersion) {
      this.initialVersion = initialVersion;
   }

   public int[] getPixelResultBuffer() {
      return this.pixelResultBuffer;
   }

   public MutableBlockPos getMutableGlobalPos() {
      return this.mutableGlobalPos;
   }

   public File getRegionFile() {
      return this.regionFile;
   }

   public void setRegionFile(File loadedFromFile) {
      this.regionFile = loadedFromFile;
   }

   public Boolean getSaveExists() {
      return this.saveExists;
   }

   public void setSaveExists(Boolean saveExists) {
      this.saveExists = saveExists;
   }

   public long getLastSaveTime() {
      return this.lastSaveTime;
   }

   public void setLastSaveTime(long lastSaveTime) {
      this.lastSaveTime = lastSaveTime;
   }

   public boolean isRefreshing() {
      return this.isRefreshing;
   }

   public void setRefreshing(boolean isRefreshing) {
      this.isRefreshing = isRefreshing;
   }

   public boolean isWritingPaused() {
      return this.pauseWriting > 0;
   }

   public void pushWriterPause() {
      synchronized(this.writerThreadPauseSync) {
         ++this.pauseWriting;
      }
   }

   public void popWriterPause() {
      synchronized(this.writerThreadPauseSync) {
         --this.pauseWriting;
      }
   }

   public boolean hasVersion() {
      return this.version != -1;
   }

   public boolean isMultiplayer() {
      return this.isMultiplayer;
   }

   public long getLastVisited() {
      return this.lastVisited;
   }

   public long getTimeSinceVisit() {
      return System.currentTimeMillis() - this.lastVisited;
   }

   public void registerVisit() {
      this.lastVisited = System.currentTimeMillis();
   }

   public int countChunks() {
      int count = 0;

      for(int i = 0; i < this.chunks.length; ++i) {
         for(int j = 0; j < this.chunks.length; ++j) {
            if (this.chunks[i][j] != null) {
               ++count;
            }
         }
      }

      return count;
   }

   protected void putLeaf(int X, int Z, MapRegion leaf) {
   }

   public void putTexture(int x, int y, LeafRegionTexture texture) {
      throw new RuntimeException(new IllegalAccessException());
   }

   public LeafRegionTexture getTexture(int x, int y) {
      MapTileChunk chunk = this.chunks[x][y];
      return chunk != null ? chunk.getLeafTexture() : null;
   }

   protected LeveledRegion<?> get(int leveledX, int leveledZ, int level) {
      if (level == 0) {
         return this;
      } else {
         throw new RuntimeException(new IllegalArgumentException());
      }
   }

   protected boolean remove(int leveledX, int leveledZ, int level) {
      throw new RuntimeException(new IllegalAccessException());
   }

   public boolean loadingAnimation() {
      return this.loadState < 2;
   }

   public boolean cleanAndCacheRequestsBlocked() {
      return this.isRefreshing;
   }

   public boolean shouldBeProcessed() {
      return this.loadState > 0 && this.loadState < 4;
   }

   public boolean isLoaded() {
      return this.loadState >= 2;
   }

   public boolean shouldEndProcessingAfterUpload() {
      return this.loadState == 3;
   }

   public void onProcessingEnd() {
      this.loadState = 4;
      this.destroyBufferUpdateObjects();
   }

   public void preCache() {
      this.pushWriterPause();
   }

   public void postCache(File permFile, MapSaveLoad mapSaveLoad) throws IOException {
      this.popWriterPause();
      if (permFile != null) {
         ArrayList<Path> cacheFolders = mapSaveLoad.getCacheFolders();

         for(int i = 0; i < cacheFolders.size(); ++i) {
            Path oldCacheFolder = (Path)cacheFolders.get(i);
            Path oldCacheFile = oldCacheFolder.resolve(permFile.getName());
            Path oldPngFile = oldCacheFolder.resolve(permFile.getName().substring(0, permFile.getName().indexOf(46)) + ".png");
            Files.deleteIfExists(oldCacheFile);
            Files.deleteIfExists(oldPngFile);
            if (oldCacheFolder.getFileName().toString().startsWith("cache_")) {
               Stream<Path> dirContent = Files.list(oldCacheFolder);
               if (!dirContent.iterator().hasNext()) {
                  Files.deleteIfExists(oldCacheFolder);
                  cacheFolders.remove(i--);
               }

               dirContent.close();
            }
         }
      }

   }

   public boolean skipCaching(MapProcessor mapProcessor) {
      return this.getVersion() != mapProcessor.getGlobalVersion();
   }

   public File findCacheFile(MapSaveLoad mapSaveLoad) throws IOException {
      return mapSaveLoad.getCacheFile(this, false, false);
   }

   public void onCurrentDimFinish(MapSaveLoad mapSaveLoad, MapProcessor mapProcessor) {
      if (this.getLoadState() == 2) {
         if (this.isBeingWritten()) {
            mapSaveLoad.getToSave().add(this);
         } else {
            this.clearRegion(mapProcessor);
         }
      } else {
         this.setBeingWritten(false);
         if (this.isRefreshing()) {
            throw new RuntimeException("Detected non-loadstate 2 region with refreshing value being true.");
         }
      }

   }

   public void onLimiterRemoval(MapProcessor mapProcessor) {
      this.pushWriterPause();
      RegionDetection restoredDetection = new RegionDetection(this.getWorldId(), this.getDimId(), this.getMwId(), this.getRegionX(), this.getRegionZ(), this.getRegionFile(), mapProcessor.getGlobalVersion());
      restoredDetection.transferInfoFrom(this);
      mapProcessor.addRegionDetection(this.dim, restoredDetection);
      mapProcessor.removeMapRegion(this);
   }

   public void afterLimiterRemoval(MapProcessor mapProcessor) {
      mapProcessor.getMapSaveLoad().removeToLoad(this);
      this.popWriterPause();
   }

   public void addDebugLines(List<String> debugLines, MapProcessor mapProcessor, int textureX, int textureY) {
      super.addDebugLines(debugLines, mapProcessor, textureX, textureY);
      debugLines.add("paused: " + this.isWritingPaused() + " loadingNeededForBranchLevel: " + this.loadingNeededForBranchLevel);
      debugLines.add(String.format("writing: %s refreshing: %s", this.isBeingWritten(), this.isRefreshing()));
      debugLines.add("saveExists: " + this.getSaveExists());
      debugLines.add(String.format("reg loadState: %s version: %d/%d hash: %d reloadVersion: %d", this.getLoadState(), this.getVersion(), mapProcessor.getGlobalVersion(), this.getCacheHashCode(), this.getReloadVersion()));
   }

   public String getExtraInfo() {
      return this.getLoadState() + " " + this.countChunks();
   }

   protected LeafRegionTexture createTexture(int x, int y) {
      return (this.chunks[x][y] = new MapTileChunk(this, this.regionX * 8 + x, this.regionZ * 8 + y)).getLeafTexture();
   }

   public void checkForUpdates(MapProcessor mapProcessor, boolean prevWaitingForBranchCache, boolean[] waitingForBranchCache, ArrayList<BranchLeveledRegion> branchRegionBuffer, int viewedLevel, int minViewedLeafX, int minViewedLeafZ, int maxViewedLeafX, int maxViewedLeafZ) {
      super.checkForUpdates(mapProcessor, prevWaitingForBranchCache, waitingForBranchCache, branchRegionBuffer, viewedLevel, minViewedLeafX, minViewedLeafZ, maxViewedLeafX, maxViewedLeafZ);
      synchronized(this) {
         if (!this.isLoaded()) {
            this.loadingNeededForBranchLevel = viewedLevel;
         }

      }
   }

   public int getReloadVersion() {
      return this.reloadVersion;
   }

   public void setReloadVersion(int reloadVersion) {
      this.reloadVersion = reloadVersion;
   }

   public void setCacheHashCode(int cacheHashCode) {
      this.cacheHashCode = cacheHashCode;
   }

   public int getCacheHashCode() {
      return this.cacheHashCode;
   }

   public void processWhenLoadedChunksExist(int globalRegionCacheHashCode) {
      super.processWhenLoadedChunksExist(globalRegionCacheHashCode);
      if (this.getCacheHashCode() != globalRegionCacheHashCode) {
         this.setVersion(Math.max(0, this.getVersion() - 1));
      }

   }

   public void updateLeafTextureVersion(int localTextureX, int localTextureZ, int newVersion) {
      int globalTextureX = (this.regionX << 3) + localTextureX;
      int globalTextureZ = (this.regionZ << 3) + localTextureZ;
      int oldVersion = this.leafTextureVersionSum[localTextureX][localTextureZ];
      this.leafTextureVersionSum[localTextureX][localTextureZ] = newVersion;
      BranchLeveledRegion parentRegion = this.getParent();
      if (parentRegion != null) {
         parentRegion.setShouldCheckForUpdatesRecursive(true);
      }

      for(int diff = newVersion - oldVersion; parentRegion != null; parentRegion = parentRegion.getParent()) {
         int parentLevel = parentRegion.getLevel();
         int parentTextureX = globalTextureX >> parentLevel & 7;
         int parentTextureY = globalTextureZ >> parentLevel & 7;
         int[] var10000 = parentRegion.leafTextureVersionSum[parentTextureX];
         var10000[parentTextureY] += diff;
      }

   }

   public void onDimensionClear(MapProcessor mapProcessor) {
      super.onDimensionClear(mapProcessor);
      if (this.loadState == 3) {
         this.clean(mapProcessor);
      }

   }

   public void restoreMetaData(int[][] cachedTextureVersions, int cacheHashCode, int reloadVersion, MapProcessor mapProcessor) {
      if (cachedTextureVersions != null) {
         this.setVersion(mapProcessor.getGlobalVersion());
         this.cacheHashCode = cacheHashCode;
         this.reloadVersion = reloadVersion;

         for(int i = 0; i < 8; ++i) {
            for(int j = 0; j < 8; ++j) {
               int storedVersion = cachedTextureVersions[i][j];
               this.cachedTextureVersions[i][j] = storedVersion;
               this.updateLeafTextureVersion(i, j, storedVersion);
            }
         }

         this.metaLoaded = true;
      }

   }

   public boolean shouldAffectLoadingRequestFrequency() {
      return this.loadState > 2 && super.shouldAffectLoadingRequestFrequency();
   }

   public boolean hasRemovableSourceData() {
      return this.loadState == 2 && !this.beingWritten;
   }
}
