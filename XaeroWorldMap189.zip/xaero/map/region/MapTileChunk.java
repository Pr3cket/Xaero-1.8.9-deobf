package xaero.map.region;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.world.World;
import xaero.map.MapProcessor;
import xaero.map.file.IOHelper;
import xaero.map.mcworld.WorldMapClientWorldData;
import xaero.map.mcworld.WorldMapClientWorldDataHelper;
import xaero.map.region.texture.LeafRegionTexture;

public class MapTileChunk {
   public static final int SIDE_LENGTH = 4;
   private MapRegion inRegion;
   private byte loadState = 0;
   private int X;
   private int Z;
   private MapTile[][] tiles = new MapTile[4][4];
   private byte[][] tileGridsCache;
   private LeafRegionTexture leafTexture;
   private boolean toUpdateBuffers;
   private boolean changed;
   private boolean includeInSave;

   public MapTileChunk(MapRegion r, int x, int z) {
      this.tileGridsCache = new byte[this.tiles.length][this.tiles.length];
      this.X = x;
      this.Z = z;
      this.inRegion = r;
      this.leafTexture = new LeafRegionTexture(this);
      synchronized(r) {
         r.setAllCachePrepared(false);
      }
   }

   public void updateBuffers(MapProcessor mapProcessor, boolean detailedDebug) {
      if (!Minecraft.func_71410_x().func_152345_ab()) {
         throw new RuntimeException("Wrong thread!");
      } else {
         if (detailedDebug) {
            System.out.println("Updating buffers: " + this.X + " " + this.Z + " " + this.loadState);
         }

         World world = mapProcessor.getWorld();
         this.leafTexture.resetTimer();
         synchronized(this.inRegion) {
            this.leafTexture.setCachePrepared(false);
            this.leafTexture.setShouldDownloadFromPBO(false);
            this.inRegion.setAllCachePrepared(false);
         }

         this.leafTexture.prepareBuffer();
         int[] result = this.inRegion.getPixelResultBuffer();
         boolean hasLight = false;
         MutableBlockPos mutableGlobalPos = this.inRegion.getMutableGlobalPos();
         MapTileChunk prevTileChunk = this.getNeighbourTileChunk(0, -1, mapProcessor, false);
         MapTileChunk prevTileChunkDiagonal = this.getNeighbourTileChunk(-1, -1, mapProcessor, false);
         MapTileChunk prevTileChunkHorisontal = this.getNeighbourTileChunk(-1, 0, mapProcessor, false);
         WorldMapClientWorldData worldData = WorldMapClientWorldDataHelper.getWorldData((WorldClient)world);
         float shadowR = worldData.shadowR;
         float shadowG = worldData.shadowG;
         float shadowB = worldData.shadowB;
         ByteBuffer colorBuffer = this.leafTexture.getColorBuffer();

         for(int o = 0; o < this.tiles.length; ++o) {
            int offX = o * 16;

            for(int p = 0; p < this.tiles.length; ++p) {
               MapTile tile = this.tiles[o][p];
               if (tile != null && tile.isLoaded()) {
                  int offZ = p * 16;

                  for(int z = 0; z < 16; ++z) {
                     for(int x = 0; x < 16; ++x) {
                        tile.getBlock(x, z).getPixelColour(result, mapProcessor.getMapWriter(), world, this, prevTileChunk, prevTileChunkDiagonal, prevTileChunkHorisontal, tile, x, z, mutableGlobalPos, shadowR, shadowG, shadowB);
                        this.putColour(offX + x, offZ + z, result[0], result[1], result[2], result[3], colorBuffer, 64);
                        if (result[3] != 0) {
                           hasLight = true;
                        }
                     }
                  }
               }
            }
         }

         this.leafTexture.postBufferUpdate(hasLight);
         this.toUpdateBuffers = false;
         this.leafTexture.setToUpload(true);
      }
   }

   public void putColour(int x, int y, int red, int green, int blue, int alpha, ByteBuffer buffer, int size) {
      int pos = (y * size + x) * 4;
      buffer.putInt(pos, blue << 24 | green << 16 | red << 8 | alpha);
   }

   public MapTileChunk getNeighbourTileChunk(int directionX, int directionZ, MapProcessor mapProcessor, boolean crossRegion) {
      int maxCoord = 7;
      int chunkXInsideRegion = this.X & maxCoord;
      int chunkZInsideRegion = this.Z & maxCoord;
      MapTileChunk prevTileChunk = null;
      int chunkXInsideRegionPrev = chunkXInsideRegion + directionX;
      int chunkZInsideRegionPrev = chunkZInsideRegion + directionZ;
      int regDirectionX = 0;
      int regDirectionZ = 0;
      if (chunkXInsideRegionPrev < 0 || chunkXInsideRegionPrev > maxCoord) {
         regDirectionX = directionX;
         chunkXInsideRegionPrev &= maxCoord;
      }

      if (chunkZInsideRegionPrev < 0 || chunkZInsideRegionPrev > maxCoord) {
         regDirectionZ = directionZ;
         chunkZInsideRegionPrev &= maxCoord;
      }

      MapRegion prevTileChunkSrc;
      if (regDirectionX == 0 && regDirectionZ == 0) {
         prevTileChunkSrc = this.inRegion;
      } else {
         prevTileChunkSrc = !crossRegion ? null : mapProcessor.getMapRegion(this.inRegion.getRegionX() + regDirectionX, this.inRegion.getRegionZ() + regDirectionZ, false);
      }

      if (prevTileChunkSrc != null) {
         prevTileChunk = prevTileChunkSrc.getChunk(chunkXInsideRegionPrev, chunkZInsideRegionPrev);
      }

      return prevTileChunk;
   }

   public void clean(MapProcessor mapProcessor) {
      for(int o = 0; o < 4; ++o) {
         for(int p = 0; p < 4; ++p) {
            MapTile tile = this.tiles[o][p];
            if (tile != null) {
               mapProcessor.getTilePool().addToPool(tile);
               this.tiles[o][p] = null;
            }
         }
      }

      this.toUpdateBuffers = false;
      this.includeInSave = false;
   }

   public int getX() {
      return this.X;
   }

   public int getZ() {
      return this.Z;
   }

   public byte[][] getTileGridsCache() {
      return this.tileGridsCache;
   }

   public int getLoadState() {
      return this.loadState;
   }

   public void setLoadState(byte loadState) {
      this.loadState = loadState;
   }

   public MapTile getTile(int x, int z) {
      return this.tiles[x][z];
   }

   public void setTile(int x, int z, MapTile tile) {
      LeafRegionTexture leafTexture = this.leafTexture;
      int i;
      int j;
      if (tile != null) {
         this.includeInSave = true;

         for(i = 0; i < 16; ++i) {
            for(j = 0; j < 16; ++j) {
               leafTexture.putHeight(x * 16 + i, z * 16 + j, tile.getBlock(i, j).getHeight());
            }
         }
      } else if (this.tiles[x][z] != null) {
         for(i = 0; i < 16; ++i) {
            for(j = 0; j < 16; ++j) {
               leafTexture.removeHeight(x * 16 + i, z * 16 + j);
            }
         }
      }

      this.tiles[x][z] = tile;
   }

   public MapRegion getInRegion() {
      return this.inRegion;
   }

   public boolean wasChanged() {
      return this.changed;
   }

   public void setChanged(boolean changed) {
      this.changed = changed;
   }

   public int getTimer() {
      return this.leafTexture.getTimer();
   }

   public void decTimer() {
      this.leafTexture.decTimer();
   }

   public boolean includeInSave() {
      return this.includeInSave;
   }

   public void unincludeInSave() {
      this.includeInSave = false;
   }

   public void resetHeights() {
      this.leafTexture.resetHeights();
   }

   public boolean getToUpdateBuffers() {
      return this.toUpdateBuffers;
   }

   public void setToUpdateBuffers(boolean toUpdateBuffers) {
      this.toUpdateBuffers = toUpdateBuffers;
   }

   /** @deprecated */
   @Deprecated
   public int getGlColorTexture() {
      return this.leafTexture.getGlColorTexture();
   }

   public LeafRegionTexture getLeafTexture() {
      return this.leafTexture;
   }

   public void writeCacheData(DataOutputStream output, byte[] usableBuffer, byte[] integerByteBuffer, LeveledRegion<LeafRegionTexture> inRegion2) throws IOException {
   }

   public void readCacheData(int cacheSaveVersion, DataInputStream input, byte[] usableBuffer, byte[] integerByteBuffer, MapProcessor mapProcessor, int x, int y) throws IOException {
      int hz;
      if (cacheSaveVersion == 4) {
         boolean hasBottomHeightValues = input.read() == 1;
         if (hasBottomHeightValues) {
            input.readByte();
            byte[] bottomHeights = new byte[64];
            IOHelper.readToBuffer(bottomHeights, 64, input);
            LeafRegionTexture leafTexture = this.leafTexture;

            for(hz = 0; hz < 64; ++hz) {
               leafTexture.putHeight(hz, 63, bottomHeights[hz]);
            }
         }
      } else if (cacheSaveVersion >= 5 && cacheSaveVersion < 13) {
         input.readInt();
         byte[] heights = new byte[64];
         LeafRegionTexture leafTexture = this.leafTexture;

         for(int hx = 0; hx < 64; ++hx) {
            IOHelper.readToBuffer(heights, 64, input);

            for(hz = 0; hz < 64; ++hz) {
               leafTexture.putHeight(hx, hz, heights[hz]);
            }
         }
      }

      if (cacheSaveVersion >= 4 && cacheSaveVersion < 10 && (this.Z & 7) == 0) {
         input.readByte();
      }

      this.loadState = 2;
   }

   public String toString() {
      return this.getX() + " " + this.getZ();
   }
}
