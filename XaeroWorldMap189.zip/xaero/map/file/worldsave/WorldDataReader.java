package xaero.map.file.worldsave;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.storage.RegionFile;
import net.minecraft.world.chunk.storage.RegionFileCache;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.biome.BiomeInfoSupplier;
import xaero.map.cache.BlockStateColorTypeCache;
import xaero.map.misc.Misc;
import xaero.map.region.MapBlock;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTile;
import xaero.map.region.MapTileChunk;
import xaero.map.region.OverlayBuilder;
import xaero.map.region.OverlayManager;

public class WorldDataReader {
   private MapProcessor mapProcessor;
   private boolean[] underair;
   private boolean[] blockFound;
   private byte[] lightLevels;
   private int[] biomeBuffer;
   private MapBlock buildingObject;
   private OverlayBuilder[] overlayBuilders;
   private MutableBlockPos mutableBlockPos;
   private BlockStateColorTypeCache colorTypeCache;
   private BiomeInfoSupplier biomeKeySupplier;

   public WorldDataReader(OverlayManager overlayManager, BlockStateColorTypeCache colorTypeCache) {
      this.colorTypeCache = colorTypeCache;
      this.buildingObject = new MapBlock();
      this.underair = new boolean[256];
      this.blockFound = new boolean[256];
      this.lightLevels = new byte[256];
      this.biomeBuffer = new int[3];
      this.overlayBuilders = new OverlayBuilder[256];
      this.mutableBlockPos = new MutableBlockPos();

      for(int i = 0; i < this.overlayBuilders.length; ++i) {
         this.overlayBuilders[i] = new OverlayBuilder(overlayManager);
      }

      this.biomeKeySupplier = new BiomeInfoSupplier() {
         public void getBiomeInfo(BlockStateColorTypeCache colorTypeCache, World world, IBlockState state, BlockPos pos, int[] dest, int biomeId) {
            colorTypeCache.getOverlayBiomeColour(world, state, pos, dest, biomeId);
         }
      };
   }

   public void setMapProcessor(MapProcessor mapProcessor) {
      this.mapProcessor = mapProcessor;
   }

   public boolean buildRegion(MapRegion region, File worldDir, World world, boolean loading, int[] chunkCountDest) {
      if (!loading) {
         region.pushWriterPause();
      }

      boolean result = true;
      int prevRegX = region.getRegionX();
      int prevRegZ = region.getRegionZ() - 1;
      MapRegion prevRegion = this.mapProcessor.getMapRegion(prevRegX, prevRegZ, false);
      boolean regionIsResting;
      synchronized(region) {
         regionIsResting = region.isResting();
         if (!loading && regionIsResting) {
            region.setBeingWritten(true);
            region.setShouldCache(false, "world save");
            region.setReloadHasBeenRequested(false, "world save");
            region.setVersion(this.mapProcessor.getGlobalVersion());
            region.setCacheHashCode(WorldMap.settings.getRegionCacheHashCode());
            if (region.getLoadState() != 2) {
               if (region.getLoadState() == 4) {
                  region.restoreBufferUpdateObjects();
               }

               region.setLoadState((byte)2);
               region.setLastSaveTime(System.currentTimeMillis() + 100000L);
               this.mapProcessor.addToProcess(region);
            } else {
               this.mapProcessor.removeToRefresh(region);
               region.setRefreshing(false);
            }
         }
      }

      int caveStart = this.mapProcessor.getCaveStart();
      boolean ignoreHeightmaps = WorldMap.settings.ignoreHeightmaps;
      boolean flowers = WorldMap.settings.flowers;
      if (loading || region.getLoadState() == 2 && regionIsResting) {
         RegionFile regionFile = RegionFileCache.func_76550_a(worldDir, region.getRegionX() * 32, region.getRegionZ() * 32);

         for(int i = 0; i < 8; ++i) {
            for(int j = 0; j < 8; ++j) {
               MapTileChunk tileChunk = region.getChunk(i, j);
               if (tileChunk == null) {
                  region.setChunk(i, j, tileChunk = new MapTileChunk(region, (region.getRegionX() << 3) + i, (region.getRegionZ() << 3) + j));
               }

               this.buildTileChunk(tileChunk, caveStart, ignoreHeightmaps, prevRegion, regionFile, world, flowers);
               tileChunk.setLoadState((byte)2);
               if (!tileChunk.includeInSave()) {
                  region.setChunk(i, j, (MapTileChunk)null);
                  tileChunk.getLeafTexture().deleteTexturesAndBuffers();
                  tileChunk = null;
               } else {
                  int var10002 = chunkCountDest[0]++;
               }
            }
         }

         if (region.isMultiplayer()) {
            region.setLastSaveTime(System.currentTimeMillis() - 60000L + 1500L);
         }
      } else {
         result = false;
      }

      if (!loading) {
         region.popWriterPause();
      }

      return result;
   }

   private void buildTileChunk(MapTileChunk tileChunk, int caveStart, boolean ignoreHeightmaps, MapRegion prevRegion, RegionFile regionFile, World world, boolean flowers) {
      tileChunk.unincludeInSave();
      tileChunk.resetHeights();

      for(int insideX = 0; insideX < 4; ++insideX) {
         for(int insideZ = 0; insideZ < 4; ++insideZ) {
            MapTile tile = tileChunk.getTile(insideX, insideZ);
            int chunkX = (tileChunk.getX() << 2) + insideX;
            int chunkZ = (tileChunk.getZ() << 2) + insideZ;
            DataInputStream datainputstream = regionFile.func_76704_a(chunkX & 31, chunkZ & 31);
            if (datainputstream == null) {
               if (tile != null) {
                  tileChunk.setChanged(true);
                  tileChunk.setTile(insideX, insideZ, (MapTile)null);
                  this.mapProcessor.getTilePool().addToPool(tile);
               }
            } else {
               boolean createdTile = false;
               if (tile == null) {
                  tile = this.mapProcessor.getTilePool().get(this.mapProcessor.getCurrentDimension(), chunkX, chunkZ);
                  createdTile = true;
               }

               NBTTagCompound nbttagcompound;
               try {
                  nbttagcompound = CompressedStreamTools.func_74794_a(datainputstream);
                  datainputstream.close();
               } catch (IOException var19) {
                  try {
                     datainputstream.close();
                  } catch (IOException var18) {
                     var18.printStackTrace();
                  }

                  System.out.println(String.format("Error loading chunk nbt for chunk %d %d!", chunkX, chunkZ));
                  var19.printStackTrace();
                  if (tile != null) {
                     tileChunk.setTile(insideX, insideZ, (MapTile)null);
                     this.mapProcessor.getTilePool().addToPool(tile);
                  }
                  continue;
               }

               if (this.buildTile(nbttagcompound, tile, tileChunk, chunkX, chunkZ, caveStart, ignoreHeightmaps, world, flowers)) {
                  tileChunk.setTile(insideX, insideZ, tile);
                  if (createdTile) {
                     tileChunk.setChanged(true);
                  }
               } else {
                  tileChunk.setTile(insideX, insideZ, (MapTile)null);
                  this.mapProcessor.getTilePool().addToPool(tile);
               }
            }
         }
      }

      if (tileChunk.wasChanged()) {
         tileChunk.setToUpdateBuffers(true);
         tileChunk.setChanged(false);
      }

   }

   private boolean buildTile(NBTTagCompound nbttagcompound, MapTile tile, MapTileChunk tileChunk, int chunkX, int chunkZ, int caveStart, boolean ignoreHeightmaps, World world, boolean flowers) {
      NBTTagCompound levelCompound = nbttagcompound.func_74775_l("Level");
      if (levelCompound.func_74771_c("LightPopulated") != 0 && levelCompound.func_74771_c("TerrainPopulated") != 0) {
         int fillCounter = 256;

         for(int i = 0; i < this.blockFound.length; ++i) {
            this.overlayBuilders[i].startBuilding();
            this.underair[i] = this.blockFound[i] = false;
            this.lightLevels[i] = 0;
         }

         int[] heightMap = levelCompound.func_74759_k("HeightMap");
         boolean heightMapExists = heightMap.length == 256;
         byte[] biomes = null;
         int[] biomesInt = null;
         boolean biomesDataExists = false;
         if (levelCompound.func_150297_b("Biomes", 7)) {
            biomes = levelCompound.func_74770_j("Biomes");
            biomesDataExists = biomes.length == 256;
         } else if (levelCompound.func_150297_b("Biomes", 11)) {
            biomesInt = levelCompound.func_74759_k("Biomes");
            biomesDataExists = biomesInt.length == 256;
         }

         boolean cave = caveStart != -1;
         NBTTagList sectionsList = levelCompound.func_150295_c("Sections", 10);
         if (sectionsList.func_74745_c() == 0) {
            return false;
         } else {
            for(int i = sectionsList.func_74745_c() - 1; i >= 0 && fillCounter > 0; --i) {
               NBTTagCompound sectionCompound = sectionsList.func_150305_b(i);
               boolean hasBlocks = sectionCompound.func_150297_b("Blocks", 7);
               boolean hasPalette = sectionCompound.func_150297_b("Palette", 11);
               byte[] blockIds_a = null;
               byte[] dataArray = null;
               byte[] addArray = null;
               byte[] add2Array = null;
               int[] palette = null;
               if (hasBlocks) {
                  blockIds_a = sectionCompound.func_74770_j("Blocks");
                  addArray = sectionCompound.func_150297_b("Add", 7) ? sectionCompound.func_74770_j("Add") : null;
                  add2Array = sectionCompound.func_150297_b("Add2", 7) ? sectionCompound.func_74770_j("Add2") : null;
                  dataArray = sectionCompound.func_74770_j("Data");
               }

               if (hasPalette) {
                  palette = sectionCompound.func_74759_k("Palette");
               }

               byte[] lightMap = null;
               if (sectionCompound.func_150297_b("BlockLight", 7)) {
                  lightMap = sectionCompound.func_74770_j("BlockLight");
                  if (lightMap.length != 2048) {
                     lightMap = null;
                  }
               }

               int sectionHeight = sectionCompound.func_74771_c("Y") * 16;
               int sectionBasedHeight = sectionHeight + 15;

               for(int z = 0; z < 16; ++z) {
                  for(int x = 0; x < 16; ++x) {
                     int pos_2d = (z << 4) + x;
                     if (!this.blockFound[pos_2d]) {
                        int startHeight;
                        int biome;
                        if (cave) {
                           startHeight = caveStart;
                        } else {
                           biome = heightMapExists ? heightMap[pos_2d] : 255;
                           if (!ignoreHeightmaps && biome != -1) {
                              startHeight = biome + 3;
                           } else {
                              startHeight = sectionBasedHeight;
                           }
                        }

                        if (i <= 0 || startHeight >= sectionHeight) {
                           biome = biomesDataExists ? (biomesInt != null ? biomesInt[pos_2d] : biomes[pos_2d] & 255) : 0;
                           int localStartHeight = 15;
                           if (!cave) {
                              this.underair[pos_2d] = true;
                           }

                           if (startHeight >> 4 << 4 == sectionHeight) {
                              localStartHeight = startHeight & 15;
                           }

                           for(int y = localStartHeight; y >= 0; --y) {
                              int h = sectionHeight + y;
                              int pos = y << 8 | pos_2d;
                              int blockId = 0;
                              int blockMeta = 0;
                              int stateId;
                              if (hasPalette) {
                                 stateId = hasBlocks ? (blockIds_a[pos] & 255) << 4 : 0;
                                 int paletteIndex = stateId | this.nibbleValue(dataArray, pos);
                                 int blockStateOtherId = palette[paletteIndex];
                                 blockId = blockStateOtherId >> 4;
                                 blockMeta = blockStateOtherId & 15;
                              } else if (hasBlocks) {
                                 blockId = blockIds_a[pos] & 255 | (addArray == null ? 0 : this.nibbleValue(addArray, pos) << 8);
                                 if (add2Array != null) {
                                    blockId |= this.nibbleValue(add2Array, pos) << 12;
                                 }

                                 blockMeta = this.nibbleValue(dataArray, pos);
                              }

                              stateId = Block.func_176210_f(Block.func_149729_e(blockId).func_176203_a(blockMeta));
                              this.mutableBlockPos.func_181079_c(chunkX << 4 | x, sectionHeight | y, chunkZ << 4 | z);
                              OverlayBuilder overlayBuilder = this.overlayBuilders[pos_2d];
                              byte light = this.lightLevels[pos_2d];
                              IBlockState state = Misc.getStateById(stateId);
                              boolean buildResult = this.buildPixel(this.buildingObject, state, stateId, x, h, z, pos_2d, this.biomeBuffer, light, biome, cave, overlayBuilder, world, this.mutableBlockPos, flowers);
                              if (!buildResult && y == 0 && i == 0) {
                                 h = 0;
                                 stateId = 0;
                                 state = Blocks.field_150350_a.func_176223_P();
                                 buildResult = true;
                              }

                              if (buildResult) {
                                 this.buildingObject.prepareForWriting();
                                 overlayBuilder.finishBuilding(this.buildingObject);
                                 this.colorTypeCache.getBlockBiomeColour(world, state, this.mutableBlockPos, this.biomeBuffer, biome);
                                 if (overlayBuilder.getOverlayBiome() != -1) {
                                    this.biomeBuffer[1] = overlayBuilder.getOverlayBiome();
                                 }

                                 boolean glowing = this.mapProcessor.getMapWriter().isGlowing(state.func_177230_c());
                                 this.buildingObject.write(stateId, h, this.biomeBuffer, light, glowing, cave);
                                 MapBlock currentPixel = tile.getBlock(x, z);
                                 boolean equalsSlopesExcluded = this.buildingObject.equalsSlopesExcluded(currentPixel);
                                 boolean fullyEqual = this.buildingObject.equals(currentPixel, equalsSlopesExcluded);
                                 if (!fullyEqual) {
                                    tile.setBlock(x, z, this.buildingObject);
                                    if (currentPixel != null) {
                                       this.buildingObject = currentPixel;
                                    } else {
                                       this.buildingObject = new MapBlock();
                                    }

                                    if (!equalsSlopesExcluded) {
                                       tileChunk.setChanged(true);
                                    }
                                 }

                                 this.blockFound[pos_2d] = true;
                                 --fillCounter;
                                 break;
                              }

                              this.lightLevels[pos_2d] = lightMap == null ? 0 : this.nibbleValue(lightMap, pos);
                           }
                        }
                     }
                  }
               }
            }

            tile.setWrittenOnce(true);
            tile.setLoaded(true);
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean buildPixel(MapBlock pixel, IBlockState state, int stateId, int x, int h, int z, int pos_2d, int[] biomeBuffer, byte light, int dataBiome, boolean cave, OverlayBuilder overlayBuilder, World world, MutableBlockPos mutableBlockPos, boolean flowers) {
      Block b = state.func_177230_c();
      if (b instanceof BlockAir) {
         this.underair[pos_2d] = true;
         return false;
      } else if (!this.underair[pos_2d] && cave) {
         return false;
      } else if (this.mapProcessor.getMapWriter().isInvisible(world, state, b, flowers)) {
         return false;
      } else {
         int lightOpacity = b.func_149717_k();
         if (this.mapProcessor.getMapWriter().shouldOverlay(b, lightOpacity)) {
            overlayBuilder.build(stateId, biomeBuffer, lightOpacity, light, world, this.mapProcessor, mutableBlockPos, dataBiome, this.colorTypeCache, this.biomeKeySupplier);
            return false;
         } else {
            return true;
         }
      }
   }

   private byte nibbleValue(byte[] array, int index) {
      byte b = array[index >> 1];
      return (index & 1) == 0 ? (byte)(b & 15) : (byte)(b >> 4 & 15);
   }
}
