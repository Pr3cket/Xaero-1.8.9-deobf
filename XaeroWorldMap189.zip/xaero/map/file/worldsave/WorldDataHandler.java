package xaero.map.file.worldsave;

import java.io.File;
import java.io.IOException;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;
import xaero.map.MapProcessor;
import xaero.map.region.MapRegion;

public class WorldDataHandler {
   private WorldDataReader worldDataReader;
   private WorldServer worldServer;
   private File worldDir;

   public WorldDataHandler(WorldDataReader worldDataReader) {
      this.worldDataReader = worldDataReader;
   }

   public void prepareSingleplayer(World world, MapProcessor mapProcessor) {
      String worldId = mapProcessor.getCurrentWorldId();
      if (world != null && !mapProcessor.isWorldMultiplayer(mapProcessor.isWorldRealms(worldId), worldId)) {
         this.worldServer = DimensionManager.getWorld(world.field_73011_w.func_177502_q());
         if (this.worldServer != null) {
            this.worldDir = this.worldServer.getChunkSaveLocation();
         } else {
            this.worldDir = null;
         }
      } else {
         this.worldDir = null;
      }

   }

   public WorldDataHandler.Result buildRegion(MapRegion region, World world, boolean loading, int[] chunkCountDest) throws IOException {
      if (this.worldServer == null) {
         System.out.println("Tried loading a region for a null server world!");
         return WorldDataHandler.Result.CANCEL;
      } else {
         boolean buildResult = this.worldDataReader.buildRegion(region, this.worldDir, world, loading, chunkCountDest);
         return buildResult ? WorldDataHandler.Result.SUCCESS : WorldDataHandler.Result.FAIL;
      }
   }

   public void onServerWorldUnload(WorldServer sw) {
      if (sw == this.worldServer) {
         this.worldServer = null;
      }

   }

   public WorldServer getWorldServer() {
      return this.worldServer;
   }

   public WorldDataReader getWorldDataReader() {
      return this.worldDataReader;
   }

   public File getWorldDir() {
      return this.worldDir;
   }

   public static enum Result {
      SUCCESS,
      FAIL,
      CANCEL;
   }
}
