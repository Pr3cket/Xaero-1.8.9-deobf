package xaero.map.file;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Stream;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.OpenGLException;
import org.lwjgl.opengl.Util;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.graphics.ImprovedFramebuffer;
import xaero.map.gui.GuiMap;
import xaero.map.misc.Misc;
import xaero.map.region.LeveledRegion;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTileChunk;
import xaero.map.region.texture.LeafRegionTexture;
import xaero.map.world.MapDimension;

public class PNGExporter {
   private Path destinationPath;

   public PNGExporter(Path destinationPath) {
      this.destinationPath = destinationPath;
   }

   public void export(MapProcessor mapProcessor) throws IllegalArgumentException, IllegalAccessException, OpenGLException {
      if (!mapProcessor.getMapSaveLoad().isRegionDetectionComplete()) {
         System.out.println("Can't export the PNG just yet!");
      } else {
         Set<LeveledRegion<?>> list = mapProcessor.getMapWorld().getCurrentDimension().getMapRegions().getUnsyncedList();
         if (!list.isEmpty()) {
            Integer minX = null;
            Integer maxX = null;
            Integer minZ = null;
            Integer maxZ = null;
            Iterator var7 = list.iterator();

            while(true) {
               LeveledRegion region;
               do {
                  do {
                     if (!var7.hasNext()) {
                        var7 = mapProcessor.getMapWorld().getCurrentDimension().getDetectedRegions().values().iterator();

                        label573:
                        while(var7.hasNext()) {
                           Hashtable<Integer, RegionDetection> column = (Hashtable)var7.next();
                           Iterator var9 = column.values().iterator();

                           while(true) {
                              RegionDetection regionDetection;
                              do {
                                 if (!var9.hasNext()) {
                                    continue label573;
                                 }

                                 regionDetection = (RegionDetection)var9.next();
                                 if (minX == null || regionDetection.getRegionX() < minX) {
                                    minX = regionDetection.getRegionX();
                                 }

                                 if (maxX == null || regionDetection.getRegionX() > maxX) {
                                    maxX = regionDetection.getRegionX();
                                 }

                                 if (minZ == null || regionDetection.getRegionZ() < minZ) {
                                    minZ = regionDetection.getRegionZ();
                                 }
                              } while(maxZ != null && regionDetection.getRegionZ() <= maxZ);

                              maxZ = regionDetection.getRegionZ();
                           }
                        }

                        int exportWidthInRegions = maxX - minX + 1;
                        int exportHeightInRegions = maxZ - minZ + 1;
                        long maxExportSizeInRegions = 204800L;
                        long exportSizeInRegions = (long)exportWidthInRegions * (long)exportHeightInRegions;
                        if (exportSizeInRegions > maxExportSizeInRegions) {
                           System.out.println("Can't export PNG because the map is too big: " + exportSizeInRegions);
                           return;
                        }

                        float scale = exportSizeInRegions < 400L ? 1.0F : (float)Math.sqrt(400.0D / (double)exportSizeInRegions);
                        float regionSize = 512.0F * scale;
                        int exportWidth = (int)((float)exportWidthInRegions * regionSize);
                        int exportHeight = (int)((float)exportHeightInRegions * regionSize);
                        int maxTextureSize = GL11.glGetInteger(3379);
                        Util.checkGLError();
                        int frameWidth = Math.min(1024, Math.min(maxTextureSize, exportWidth));
                        int frameHeight = Math.min(1024, Math.min(maxTextureSize, exportHeight));
                        int horizontalFrames = (int)Math.ceil((double)exportWidth / (double)frameWidth);
                        int verticalFrames = (int)Math.ceil((double)exportHeight / (double)frameHeight);
                        if (WorldMap.settings.debug) {
                           System.out.println(String.format("Exporting PNG of size %dx%d using a framebuffer of size %dx%d.", exportWidth, exportHeight, frameWidth, frameHeight));
                        }

                        BufferedImage image;
                        try {
                           image = new BufferedImage(exportWidth, exportHeight, 1);
                        } catch (OutOfMemoryError var54) {
                           System.out.println("Can't export PNG because java heap is out of memory. Required: " + (long)exportWidth * (long)exportHeight * 4L + " bytes");
                           return;
                        }

                        ImprovedFramebuffer exportFrameBuffer = new ImprovedFramebuffer(frameWidth, frameHeight, false);
                        ByteBuffer frameDataBuffer = BufferUtils.createByteBuffer(frameWidth * frameHeight * 4);
                        int[] bufferArray = new int[frameWidth * frameHeight];
                        if (exportFrameBuffer.field_147616_f == -1) {
                           System.out.println("Can't export PNG because FBOs are not supported.");
                           return;
                        }

                        GlStateManager.func_179123_a();
                        GlStateManager.func_179140_f();
                        GlStateManager.func_179128_n(5889);
                        GlStateManager.func_179096_D();
                        GlStateManager.func_179130_a(0.0D, (double)frameWidth, 0.0D, (double)frameHeight, 0.0D, 1000.0D);
                        GlStateManager.func_179128_n(5888);
                        GlStateManager.func_179094_E();
                        GlStateManager.func_179096_D();
                        GlStateManager.func_179129_p();
                        GlStateManager.func_179118_c();
                        GlStateManager.func_179084_k();
                        exportFrameBuffer.func_147610_a(true);
                        GlStateManager.func_179094_E();
                        GlStateManager.func_179152_a(scale, scale, 1.0F);

                        int exportNumber;
                        int minTileChunkZ;
                        for(int i = 0; i < horizontalFrames; ++i) {
                           for(exportNumber = 0; exportNumber < verticalFrames; ++exportNumber) {
                              GlStateManager.func_179144_i(0);
                              GlStateManager.func_179082_a(0.0F, 0.0F, 0.0F, 1.0F);
                              GlStateManager.func_179086_m(16640);
                              GlStateManager.func_179094_E();
                              float frameLeft = (float)minX * 512.0F + (float)(i * frameWidth) / scale;
                              float frameRight = (float)minX * 512.0F + (float)((i + 1) * frameWidth) / scale;
                              float frameTop = (float)minZ * 512.0F + (float)(exportNumber * frameHeight) / scale;
                              float frameBottom = (float)minZ * 512.0F + (float)((exportNumber + 1) * frameHeight) / scale;
                              int minTileChunkX = (int)Math.floor((double)frameLeft) >> 6;
                              int maxTileChunkX = (int)Math.floor((double)frameRight) >> 6;
                              minTileChunkZ = (int)Math.floor((double)frameTop) >> 6;
                              int maxTileChunkZ = (int)Math.floor((double)frameBottom) >> 6;
                              int minRegionX = minTileChunkX >> 3;
                              int minRegionZ = minTileChunkZ >> 3;
                              int maxRegionX = maxTileChunkX >> 3;
                              int maxRegionZ = maxTileChunkZ >> 3;
                              GlStateManager.func_179109_b(-frameLeft, -frameTop, 0.0F);

                              int regionX;
                              int regionZ;
                              for(regionX = minRegionX; regionX <= maxRegionX; ++regionX) {
                                 for(regionZ = minRegionZ; regionZ <= maxRegionZ; ++regionZ) {
                                    boolean specialRegion = false;
                                    MapRegion region = mapProcessor.getMapRegion(regionX, regionZ, false);
                                    if (region == null || region.getLoadState() < 4 && (!region.isBeingWritten() || region.getLoadState() != 2)) {
                                       File cacheFile = null;
                                       if (region != null) {
                                          cacheFile = region.getCacheFile();
                                       } else if (mapProcessor.regionExists(regionX, regionZ)) {
                                          cacheFile = mapProcessor.getRegionDetection(regionX, regionZ).getCacheFile();
                                       }

                                       if (cacheFile == null) {
                                          continue;
                                       }

                                       region = new MapRegion("png", "null", (String)null, (MapDimension)null, regionX, regionZ, 0, false);
                                       region.setCacheFile(cacheFile);
                                       region.loadCacheTextures(mapProcessor, false);
                                       specialRegion = true;
                                    }

                                    for(int localChunkX = 0; localChunkX < 8; ++localChunkX) {
                                       for(int localChunkZ = 0; localChunkZ < 8; ++localChunkZ) {
                                          MapTileChunk tileChunk = region.getChunk(localChunkX, localChunkZ);
                                          if (tileChunk != null) {
                                             LeafRegionTexture tileChunkTexture = tileChunk.getLeafTexture();
                                             if (tileChunk.getX() >= minTileChunkX && tileChunk.getX() <= maxTileChunkX && tileChunk.getZ() >= minTileChunkZ && tileChunk.getZ() <= maxTileChunkZ) {
                                                if (specialRegion) {
                                                   tileChunkTexture.bindColorTexture(true, 9728);
                                                   if (tileChunkTexture.isColorBufferCompressed()) {
                                                      GL13.glCompressedTexImage2D(3553, 0, tileChunkTexture.getColorBufferFormat(), 64, 64, 0, tileChunkTexture.getColorBuffer());
                                                   } else {
                                                      GL11.glTexImage2D(3553, 0, tileChunkTexture.getColorBufferFormat(), 64, 64, 0, 32993, 32821, tileChunkTexture.getColorBuffer());
                                                   }

                                                   tileChunkTexture.deleteBuffers();
                                                } else {
                                                   if (tileChunkTexture.getGlColorTexture() == -1) {
                                                      continue;
                                                   }

                                                   tileChunkTexture.bindColorTexture(false, 9728);
                                                }

                                                GL11.glTexParameteri(3553, 33085, 9);
                                                GL11.glTexParameterf(3553, 33083, 9.0F);
                                                exportFrameBuffer.generateMipmaps();
                                                GL11.glTexParameteri(3553, 10241, 9987);
                                                GuiMap.renderTexturedModalRect((float)(tileChunk.getX() * 64), (float)(tileChunk.getZ() * 64), 64.0F, 64.0F);
                                                GL11.glTexParameteri(3553, 10241, 9729);
                                                if (specialRegion) {
                                                   GlStateManager.func_179150_h(tileChunk.getLeafTexture().getGlColorTexture());
                                                }
                                             } else if (specialRegion) {
                                                tileChunkTexture.deleteBuffers();
                                             }
                                          }
                                       }
                                    }
                                 }
                              }

                              GlStateManager.func_179121_F();
                              GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
                              exportFrameBuffer.func_147612_c();
                              frameDataBuffer.clear();
                              GL11.glGetTexImage(3553, 0, 32993, 33639, frameDataBuffer);
                              frameDataBuffer.asIntBuffer().get(bufferArray);
                              regionX = Math.min(frameWidth, exportWidth - i * frameWidth);
                              regionZ = Math.min(frameHeight, exportHeight - exportNumber * frameWidth);
                              image.setRGB(i * frameWidth, exportNumber * frameHeight, regionX, regionZ, bufferArray, 0, frameWidth);
                           }
                        }

                        GlStateManager.func_179121_F();
                        GlStateManager.func_179099_b();
                        exportFrameBuffer.func_147609_e();
                        GlStateManager.func_179089_o();
                        GlStateManager.func_179141_d();
                        GlStateManager.func_179147_l();
                        GlStateManager.func_179121_F();
                        GlStateManager.func_179128_n(5889);
                        Misc.minecraftOrtho(new ScaledResolution(Minecraft.func_71410_x()));
                        GlStateManager.func_179128_n(5888);
                        GlStateManager.func_179144_i(0);
                        exportFrameBuffer.func_147608_a();
                        mapProcessor.getBufferDeallocator().deallocate(frameDataBuffer, WorldMap.settings.debug);
                        Stream exports = null;

                        try {
                           if (!Files.exists(this.destinationPath, new LinkOption[0])) {
                              Files.createDirectories(this.destinationPath);
                           }

                           exportNumber = 1;
                           exports = Files.list(this.destinationPath);
                           if (exports == null) {
                              return;
                           }

                           Object[] exportsArray = exports.toArray();
                           Object[] var63 = exportsArray;
                           int var64 = exportsArray.length;

                           for(int var65 = 0; var65 < var64; ++var65) {
                              Object o = var63[var65];
                              Path path = (Path)o;
                              if (path.getFileName().toString().endsWith("png")) {
                                 try {
                                    minTileChunkZ = Integer.parseInt(path.getFileName().toString().split("\\.")[0].split("_")[1]);
                                    if (minTileChunkZ >= exportNumber) {
                                       exportNumber = minTileChunkZ + 1;
                                    }
                                 } catch (Exception var53) {
                                 }
                              }
                           }

                           ImageIO.write(image, "png", this.destinationPath.resolve("export_" + exportNumber + ".png").toFile());
                        } catch (IOException var55) {
                           System.out.println("Failed to export PNG: ");
                           var55.printStackTrace();
                        } finally {
                           if (exports != null) {
                              exports.close();
                           }

                           image.flush();
                        }

                        return;
                     }

                     region = (LeveledRegion)var7.next();
                  } while(region.getLevel() != 0);

                  if (minX == null || region.getRegionX() < minX) {
                     minX = region.getRegionX();
                  }

                  if (maxX == null || region.getRegionX() > maxX) {
                     maxX = region.getRegionX();
                  }

                  if (minZ == null || region.getRegionZ() < minZ) {
                     minZ = region.getRegionZ();
                  }
               } while(maxZ != null && region.getRegionZ() <= maxZ);

               maxZ = region.getRegionZ();
            }
         }
      }
   }
}
