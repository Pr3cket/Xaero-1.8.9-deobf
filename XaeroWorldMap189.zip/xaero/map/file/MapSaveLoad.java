package xaero.map.file;

import java.awt.Desktop;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.biome.BiomeInfoSupplier;
import xaero.map.cache.BlockStateColorTypeCache;
import xaero.map.file.worldsave.WorldDataHandler;
import xaero.map.misc.Misc;
import xaero.map.region.BranchLeveledRegion;
import xaero.map.region.LeveledRegion;
import xaero.map.region.LeveledRegionManager;
import xaero.map.region.MapBlock;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTile;
import xaero.map.region.MapTileChunk;
import xaero.map.region.Overlay;
import xaero.map.region.OverlayBuilder;
import xaero.map.region.OverlayManager;
import xaero.map.task.MapRunnerTask;
import xaero.map.world.MapDimension;

public class MapSaveLoad {
   private static final int currentSaveMajorVersion = 0;
   private static final int currentSaveMinorVersion = 3;
   private static final int currentSaveVersion = 3;
   public static final int SAVE_TIME = 60000;
   public static final int currentCacheSaveVersion = 15;
   private ArrayList<MapRegion> toSave = new ArrayList();
   private ArrayList<MapRegion> toLoad = new ArrayList();
   private ArrayList<BranchLeveledRegion> toLoadBranchCache = new ArrayList();
   private ArrayList<File> cacheToConvertFromTemp = new ArrayList();
   private LeveledRegion<?> nextToLoadByViewing;
   private boolean regionDetectionComplete;
   private ArrayList<Path> cacheFolders = new ArrayList();
   public boolean loadingFiles;
   private OverlayBuilder overlayBuilder;
   private PNGExporter pngExporter;
   private List<MapDimension> workingDimList;
   public boolean saveAll;
   private MapProcessor mapProcessor;
   public int mainTextureLevel;
   private boolean exporting;

   public MapSaveLoad(OverlayManager overlayManager, PNGExporter pngExporter) {
      this.overlayBuilder = new OverlayBuilder(overlayManager);
      this.pngExporter = pngExporter;
      this.workingDimList = new ArrayList();
   }

   public void setMapProcessor(MapProcessor mapProcessor) {
      this.mapProcessor = mapProcessor;
   }

   public boolean exportPNG(final GuiScreen destScreen) {
      if (this.exporting) {
         return false;
      } else {
         this.exporting = true;
         WorldMap.mapRunner.addTask(new MapRunnerTask() {
            public void run(final MapProcessor mapProcessor) {
               Minecraft.func_71410_x().func_152344_a(new Runnable() {
                  public void run() {
                     try {
                        MapSaveLoad.this.pngExporter.export(mapProcessor);
                        Path exportsPath = WorldMap.configFolder.toPath().getParent().resolve("map exports");
                        if (Files.exists(exportsPath, new LinkOption[0])) {
                           Desktop d = Desktop.getDesktop();

                           try {
                              d.open(exportsPath.toFile());
                           } catch (IOException var4) {
                              var4.printStackTrace();
                           }
                        }
                     } catch (Throwable var5) {
                        System.out.println("Failed to export PNG with exception!");
                        WorldMap.crashHandler.setCrashedBy(var5);
                     }

                     MapSaveLoad.this.exporting = false;
                     Minecraft.func_71410_x().func_147108_a(destScreen);
                  }
               });

               while(MapSaveLoad.this.exporting) {
                  try {
                     Thread.sleep(100L);
                  } catch (InterruptedException var3) {
                  }
               }

            }
         });
         return true;
      }
   }

   private File getSecondaryFile(String extension, File realFile) {
      if (realFile == null) {
         return null;
      } else {
         String p = realFile.getPath();
         return new File(p.substring(0, p.lastIndexOf(".")) + extension);
      }
   }

   public File getTempFile(File realFile) {
      return this.getSecondaryFile(".zip.temp", realFile);
   }

   public void updateCacheFolderList(Path subFolder) {
      Stream allFiles;
      try {
         allFiles = Files.list(subFolder);
      } catch (Exception var6) {
         this.cacheFolders.clear();
         return;
      }

      Object[] filesArray = allFiles.toArray();
      allFiles.close();
      this.cacheFolders.clear();

      for(int i = 0; i < filesArray.length; ++i) {
         Path path = (Path)filesArray[i];
         if (Files.isDirectory(path, new LinkOption[0]) && path.getFileName().toString().startsWith("cache_") && !path.getFileName().toString().split("_")[1].equals("" + this.mapProcessor.getGlobalVersion())) {
            this.cacheFolders.add(path);
            if (WorldMap.settings.debug) {
               System.out.println(path.toString());
            }
         }
      }

      this.cacheFolders.add(subFolder);
   }

   public Path getCacheFolder(Path subFolder) {
      return subFolder != null ? subFolder.resolve("cache_" + this.mapProcessor.getGlobalVersion()) : null;
   }

   public File getCacheFile(MapRegionInfo region, boolean checkOldFolders, boolean requestCache) throws IOException {
      Path subFolder = this.getMWSubFolder(region.getWorldId(), region.getDimId(), region.getMwId());
      Path latestCacheFolder = this.getCacheFolder(subFolder);
      if (latestCacheFolder == null) {
         return null;
      } else {
         if (!Files.exists(latestCacheFolder, new LinkOption[0])) {
            Files.createDirectories(latestCacheFolder);
         }

         Path cacheFile = latestCacheFolder.resolve(region.getRegionX() + "_" + region.getRegionZ() + ".xwmc");
         if (checkOldFolders && !Files.exists(cacheFile, new LinkOption[0])) {
            if (requestCache) {
               region.setShouldCache(true, "cache file");
            }

            for(int i = 0; i < this.cacheFolders.size(); ++i) {
               Path oldCacheFolder = (Path)this.cacheFolders.get(i);
               Path oldCacheFile = oldCacheFolder.resolve(region.getRegionX() + "_" + region.getRegionZ() + ".xwmc");
               if (Files.exists(oldCacheFile, new LinkOption[0])) {
                  return oldCacheFile.toFile();
               }
            }

            return cacheFile.toFile();
         } else {
            return cacheFile.toFile();
         }
      }
   }

   public File getFile(MapRegion region) {
      if (region.getWorldId() == null) {
         return null;
      } else {
         File detectedFile = region.getRegionFile();
         boolean multiplayer = region.isMultiplayer();
         if (!multiplayer) {
            return detectedFile != null ? detectedFile : this.mapProcessor.getWorldDataHandler().getWorldDir().toPath().resolve("region").resolve("r." + region.getRegionX() + "." + region.getRegionZ() + ".mca").toFile();
         } else {
            Path mainFolder = this.getMainFolder(region.getWorldId(), region.getDimId());
            Path subFolder = this.getMWSubFolder(region.getWorldId(), mainFolder, region.getMwId());

            File zipFile;
            try {
               zipFile = subFolder.toFile();
               if (!zipFile.exists()) {
                  Files.createDirectories(zipFile.toPath());
               }
            } catch (IOException var7) {
               var7.printStackTrace();
            }

            if (detectedFile != null && detectedFile.getName().endsWith(".xaero")) {
               zipFile = subFolder.resolve(region.getRegionX() + "_" + region.getRegionZ() + ".zip").toFile();
               if (detectedFile.exists() && !zipFile.exists()) {
                  this.xaeroToZip(detectedFile);
               }

               region.setRegionFile(zipFile);
               return zipFile;
            } else {
               return detectedFile == null ? subFolder.resolve(region.getRegionX() + "_" + region.getRegionZ() + ".zip").toFile() : detectedFile;
            }
         }
      }
   }

   public static Path getRootFolder(String world) {
      return world == null ? null : WorldMap.saveFolder.toPath().resolve(world);
   }

   public Path getMainFolder(String world, String dim) {
      return world == null ? null : WorldMap.saveFolder.toPath().resolve(world).resolve(dim);
   }

   Path getMWSubFolder(String world, Path mainFolder, String mw) {
      if (world == null) {
         return null;
      } else {
         return mw == null ? mainFolder : mainFolder.resolve(mw);
      }
   }

   public Path getMWSubFolder(String world, String dim, String mw) {
      return world == null ? null : this.getMWSubFolder(world, this.getMainFolder(world, dim), mw);
   }

   public Path getOldFolder(String oldUnfixedMainId, String dim) {
      return oldUnfixedMainId == null ? null : WorldMap.saveFolder.toPath().resolve(oldUnfixedMainId + "_" + dim);
   }

   private void xaeroToZip(File xaero) {
      File zipFile = xaero.toPath().getParent().resolve(xaero.getName().substring(0, xaero.getName().lastIndexOf(46)) + ".zip").toFile();

      try {
         BufferedInputStream in = new BufferedInputStream(new FileInputStream(xaero), 1024);
         ZipOutputStream zipOutput = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
         ZipEntry e = new ZipEntry("region.xaero");
         zipOutput.putNextEntry(e);
         byte[] bytes = new byte[1024];

         int got;
         while((got = in.read(bytes)) > 0) {
            zipOutput.write(bytes, 0, got);
         }

         zipOutput.closeEntry();
         zipOutput.flush();
         zipOutput.close();
         in.close();
         Files.deleteIfExists(xaero.toPath());
      } catch (IOException var8) {
         var8.printStackTrace();
      }
   }

   public void detectRegions() {
      MapDimension mapDimension = this.mapProcessor.getMapWorld().getCurrentDimension();
      mapDimension.createDetectedRegions().clear();
      String worldId = this.mapProcessor.getCurrentWorldId();
      if (worldId != null) {
         String dimId = this.mapProcessor.getCurrentDimId();
         String mwId = this.mapProcessor.getCurrentMWId();
         if (this.mapProcessor.isWorldMultiplayer(this.mapProcessor.isWorldRealms(worldId), worldId)) {
            Path mapFolder = this.getMWSubFolder(worldId, dimId, mwId);
            if (!mapFolder.toFile().exists()) {
               return;
            }

            this.detectRegionsFromFiles(mapDimension, worldId, dimId, mwId, mapFolder, "^-?\\d+_-?\\d+\\.(zip|xaero)$", "_", 0, 1, 0);
         } else {
            File worldDir = this.mapProcessor.getWorldDataHandler().getWorldDir();
            if (worldDir == null) {
               return;
            }

            Path worldFolder = worldDir.toPath().resolve("region");
            if (!worldFolder.toFile().exists()) {
               return;
            }

            this.detectRegionsFromFiles(mapDimension, worldId, dimId, mwId, worldFolder, "^r\\.(-{0,1}[0-9]+\\.){2}mc[ar]$", "\\.", 1, 2, 8192);
         }

      }
   }

   public void detectRegionsFromFiles(MapDimension mapDimension, String worldId, String dimId, String mwId, Path folder, String regex, String splitRegex, int xIndex, int zIndex, int emptySize) {
      int total = 0;

      try {
         Stream<Path> files = Files.list(folder);
         Iterator iter = files.iterator();

         while(true) {
            if (this.mapProcessor.isFinalizing() || !iter.hasNext()) {
               files.close();
               break;
            }

            Path file = (Path)iter.next();
            if (!Files.isDirectory(file, new LinkOption[0])) {
               String regionName = file.getFileName().toString();
               if (regionName.matches(regex) && Files.size(file) > (long)emptySize) {
                  String[] args = regionName.substring(0, regionName.lastIndexOf(46)).split(splitRegex);
                  int x = Integer.parseInt(args[xIndex]);
                  int z = Integer.parseInt(args[zIndex]);
                  RegionDetection regionDetection = new RegionDetection(worldId, dimId, mwId, x, z, file.toFile(), this.mapProcessor.getGlobalVersion());
                  File cacheFile = this.getCacheFile(regionDetection, true, true);
                  regionDetection.setCacheFile(cacheFile);
                  this.mapProcessor.addRegionDetection(mapDimension, regionDetection);
                  ++total;
               }
            }
         }
      } catch (IOException var21) {
         var21.printStackTrace();
         return;
      }

      if (WorldMap.settings.debug) {
         System.out.println(String.format("%d regions detected!", total));
      }

   }

   public boolean saveRegion(MapRegion region) {
      try {
         if (!region.isMultiplayer()) {
            if (WorldMap.settings.debug) {
               System.out.println("Save not required for singleplayer: " + region + " " + region.getWorldId() + " " + region.getDimId());
            }

            return region.countChunks() > 0;
         } else {
            File permFile = this.getFile(region);
            File file = this.getTempFile(permFile);
            if (file == null) {
               return true;
            } else {
               if (!file.exists()) {
                  file.createNewFile();
               }

               boolean regionIsEmpty = true;
               DataOutputStream out = null;

               try {
                  ZipOutputStream zipOut = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
                  out = new DataOutputStream(zipOut);
                  ZipEntry e = new ZipEntry("region.xaero");
                  zipOut.putNextEntry(e);
                  out.write(255);
                  out.writeInt(3);

                  for(int o = 0; o < 8; ++o) {
                     for(int p = 0; p < 8; ++p) {
                        MapTileChunk chunk = region.getChunk(o, p);
                        if (chunk != null) {
                           if (!chunk.includeInSave()) {
                              region.setChunk(o, p, (MapTileChunk)null);
                              synchronized(chunk) {
                                 chunk.getLeafTexture().deleteTexturesAndBuffers();
                              }

                              BranchLeveledRegion parentRegion = region.getParent();
                              if (parentRegion != null) {
                                 parentRegion.setShouldCheckForUpdatesRecursive(true);
                              }
                           } else {
                              out.write(o << 4 | p);
                              boolean chunkIsEmpty = true;

                              for(int i = 0; i < 4; ++i) {
                                 for(int j = 0; j < 4; ++j) {
                                    MapTile tile = chunk.getTile(i, j);
                                    if (tile != null && tile.isLoaded()) {
                                       chunkIsEmpty = false;

                                       for(int x = 0; x < 16; ++x) {
                                          MapBlock[] c = tile.getBlockColumn(x);

                                          for(int z = 0; z < 16; ++z) {
                                             this.savePixel(c[z], out);
                                          }
                                       }
                                    } else {
                                       out.writeInt(-1);
                                    }
                                 }
                              }

                              if (!chunkIsEmpty) {
                                 regionIsEmpty = false;
                              }
                           }
                        }
                     }
                  }

                  zipOut.closeEntry();
               } finally {
                  if (out != null) {
                     out.close();
                  }

               }

               if (regionIsEmpty) {
                  this.safeDelete(permFile.toPath(), ".zip");
                  this.safeDelete(file.toPath(), ".temp");
                  if (WorldMap.settings.debug) {
                     System.out.println("Save cancelled because the region is empty: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId());
                  }

                  return false;
               } else {
                  this.safeMoveAndReplace(file.toPath(), permFile.toPath(), ".temp", ".zip");
                  if (WorldMap.settings.debug) {
                     System.out.println("Region saved: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId() + ", " + this.mapProcessor.getMapWriter().getUpdateCounter());
                  }

                  return true;
               }
            }
         }
      } catch (IOException var25) {
         var25.printStackTrace();
         return true;
      }
   }

   private Path getBackupFolder(Path filePath, int saveVersion, int backupVersion) {
      return filePath.getParent().resolve(saveVersion + "_backup_" + backupVersion);
   }

   public void backupFile(File file, int saveVersion) throws IOException {
      if (!file.getName().endsWith(".mca") && !file.getName().endsWith(".mcr")) {
         Path filePath = file.toPath();
         int backupVersion = 0;
         Path backupFolder = this.getBackupFolder(filePath, saveVersion, backupVersion);
         String backupName = filePath.getFileName().toString();

         Path backup;
         for(backup = backupFolder.resolve(backupName); Files.exists(backup, new LinkOption[0]); backup = backupFolder.resolve(backupName)) {
            ++backupVersion;
            backupFolder = this.getBackupFolder(filePath, saveVersion, backupVersion);
         }

         if (!Files.exists(backupFolder, new LinkOption[0])) {
            Files.createDirectories(backupFolder);
         }

         Files.move(file.toPath(), backup);
         System.out.println("File " + file.getPath() + " backed up to " + backupFolder.toFile().getPath());
      } else {
         throw new RuntimeException("World save protected: " + file);
      }
   }

   public boolean loadRegion(World world, MapRegion region) {
      boolean multiplayer = region.isMultiplayer();
      File file = this.getFile(region);
      if (file != null && file.exists()) {
         int saveVersion = -1;
         boolean versionReached = false;
         int[] overlayBiomeBuffer = new int[3];

         try {
            synchronized(region) {
               region.setLoadState((byte)1);
            }

            region.setSaveExists(true);
            region.restoreBufferUpdateObjects();
            int totalChunks = 0;
            if (multiplayer) {
               DataInputStream in = null;

               try {
                  ZipInputStream zipIn = new ZipInputStream(new BufferedInputStream(new FileInputStream(file), 2048));
                  in = new DataInputStream(zipIn);
                  zipIn.getNextEntry();
                  int firstByte = in.read();
                  if (firstByte == 255) {
                     saveVersion = in.readInt();
                     if (3 < saveVersion) {
                        zipIn.closeEntry();
                        in.close();
                        System.out.println("Trying to load a newer region " + region + " save using an older version of Xaero's World Map!");
                        this.backupFile(file, saveVersion);
                        region.setSaveExists((Boolean)null);
                        boolean var34 = false;
                        return var34;
                     }

                     firstByte = -1;
                  }

                  versionReached = true;

                  while(true) {
                     int chunkCoords = firstByte == -1 ? in.read() : firstByte;
                     if (chunkCoords == -1) {
                        zipIn.closeEntry();
                        break;
                     }

                     firstByte = -1;
                     int o = chunkCoords >> 4;
                     int p = chunkCoords & 15;
                     MapTileChunk chunk = region.getChunk(o, p);
                     if (chunk == null) {
                        region.setChunk(o, p, chunk = new MapTileChunk(region, region.getRegionX() * 8 + o, region.getRegionZ() * 8 + p));
                     }

                     chunk.setLoadState((byte)1);
                     chunk.resetHeights();

                     for(int i = 0; i < 4; ++i) {
                        for(int j = 0; j < 4; ++j) {
                           Integer nextTile = in.readInt();
                           if (nextTile != -1) {
                              MapTile tile = this.mapProcessor.getTilePool().get(this.mapProcessor.getCurrentDimension(), chunk.getX() * 4 + i, chunk.getZ() * 4 + j);

                              for(int x = 0; x < 16; ++x) {
                                 MapBlock[] c = tile.getBlockColumn(x);

                                 for(int z = 0; z < 16; ++z) {
                                    if (c[z] == null) {
                                       c[z] = new MapBlock();
                                    } else {
                                       c[z].prepareForWriting();
                                    }

                                    this.loadPixel(nextTile, c[z], in, saveVersion, world, tile.getChunkX() * 16 + x, tile.getChunkZ() * 16 + z, overlayBiomeBuffer);
                                    nextTile = null;
                                 }
                              }

                              chunk.setTile(i, j, tile);
                              tile.setLoaded(true);
                           }
                        }
                     }

                     if (!chunk.includeInSave()) {
                        region.setChunk(o, p, (MapTileChunk)null);
                        chunk.getLeafTexture().deleteTexturesAndBuffers();
                        chunk = null;
                     } else {
                        region.pushWriterPause();
                        ++totalChunks;
                        chunk.setToUpdateBuffers(true);
                        chunk.setLoadState((byte)2);
                        region.popWriterPause();
                     }
                  }
               } finally {
                  if (in != null) {
                     in.close();
                  }

               }

               if (totalChunks > 0) {
                  if (WorldMap.settings.debug) {
                     System.out.println("Region loaded: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId() + ", " + saveVersion);
                  }

                  return true;
               } else {
                  region.setSaveExists((Boolean)null);
                  this.safeDelete(file.toPath(), ".zip");
                  if (WorldMap.settings.debug) {
                     System.out.println("Cancelled loading an empty region: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId() + ", " + saveVersion);
                  }

                  return false;
               }
            } else {
               int[] chunkCount = new int[1];
               WorldDataHandler.Result buildResult = this.mapProcessor.getWorldDataHandler().buildRegion(region, world, true, chunkCount);
               if (buildResult == WorldDataHandler.Result.CANCEL) {
                  RegionDetection restoredDetection = new RegionDetection(region.getWorldId(), region.getDimId(), region.getMwId(), region.getRegionX(), region.getRegionZ(), region.getRegionFile(), this.mapProcessor.getGlobalVersion());
                  restoredDetection.transferInfoFrom(region);
                  this.mapProcessor.addRegionDetection(region.getDim(), restoredDetection);
                  this.mapProcessor.removeMapRegion(region);
                  System.out.println("Region cancelled from world save: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId());
                  return false;
               } else {
                  region.setRegionFile(file);
                  boolean result = buildResult == WorldDataHandler.Result.SUCCESS && chunkCount[0] > 0;
                  if (!result) {
                     region.setSaveExists((Boolean)null);
                     if (WorldMap.settings.debug) {
                        System.out.println("Region failed to load from world save: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId());
                     }
                  } else if (WorldMap.settings.debug) {
                     System.out.println("Region loaded from world save: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId());
                  }

                  return result;
               }
            }
         } catch (Throwable var29) {
            region.setSaveExists((Boolean)null);
            System.out.println("Region failed to load: " + region + (versionReached ? " " + saveVersion : ""));
            var29.printStackTrace();
            return false;
         }
      } else {
         if (region.getLoadState() == 4) {
            region.setBeingWritten(false);
            region.setSaveExists((Boolean)null);
         }

         return false;
      }
   }

   public boolean beingSaved(MapDimension dim, int regX, int regZ) {
      for(int i = 0; i < this.toSave.size(); ++i) {
         MapRegion r = (MapRegion)this.toSave.get(i);
         if (r != null && r.getDim() == dim && r.getRegionX() == regX && r.getRegionZ() == regZ) {
            return true;
         }
      }

      return false;
   }

   public void requestLoad(MapRegion region, String reason) {
      this.requestLoad(region, reason, true);
   }

   public void requestLoad(MapRegion region, String reason, boolean prioritize) {
      this.addToLoad(region, reason, prioritize);
      if (WorldMap.settings.debug && reason != null) {
         System.out.println("Requesting load for: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId() + ", " + reason);
      }

   }

   public void requestBranchCache(BranchLeveledRegion region, String reason) {
      this.requestBranchCache(region, reason, true);
      if (WorldMap.settings.debug && reason != null) {
         System.out.println("Requesting branch load for: " + region + ", " + reason);
      }

   }

   public void requestBranchCache(BranchLeveledRegion region, String reason, boolean prioritize) {
      synchronized(this.toLoadBranchCache) {
         if (prioritize) {
            this.toLoadBranchCache.remove(region);
            this.toLoadBranchCache.add(0, region);
         } else if (!this.toLoadBranchCache.contains(region)) {
            this.toLoadBranchCache.add(region);
         }

      }
   }

   public void addToLoad(MapRegion region, String reason, boolean prioritize) {
      synchronized(this.toLoad) {
         if (prioritize) {
            region.setReloadHasBeenRequested(true, reason);
            this.toLoad.remove(region);
            this.toLoad.add(0, region);
         } else if (!this.loadingFiles && !this.toLoad.contains(region)) {
            region.setReloadHasBeenRequested(true, reason);
            this.toLoad.add(region);
         }

      }
   }

   public void removeToLoad(MapRegion region) {
      synchronized(this.toLoad) {
         this.toLoad.remove(region);
      }
   }

   public void clearToLoad() {
      synchronized(this.toLoad) {
         this.toLoad.clear();
      }

      synchronized(this.toLoadBranchCache) {
         this.toLoadBranchCache.clear();
      }
   }

   public int getSizeOfToLoad() {
      return this.toLoad.size();
   }

   public boolean saveExists(MapRegion region) {
      if (region.getSaveExists() != null) {
         return region.getSaveExists();
      } else {
         boolean result = true;
         File file = this.getFile(region);
         if (file == null || !file.exists()) {
            result = false;
         }

         region.setSaveExists(result);
         return result;
      }
   }

   public void updateSave(LeveledRegion<?> leveledRegion, long currentTime) {
      if (leveledRegion.getLevel() == 0) {
         MapRegion region = (MapRegion)leveledRegion;
         if (region.getLoadState() == 2 && region.isBeingWritten() && currentTime - region.getLastSaveTime() > 60000L && !this.beingSaved(region.getDim(), region.getRegionX(), region.getRegionZ())) {
            this.toSave.add(region);
            region.setSaveExists(true);
            region.setLastSaveTime(currentTime);
         }
      } else {
         BranchLeveledRegion region = (BranchLeveledRegion)leveledRegion;
         if (region.eligibleForSaving(currentTime)) {
            region.startDownloadingTexturesForCache(this.mapProcessor);
         }
      }

   }

   public void run(World world) throws Exception {
      boolean skipCaching;
      if (!this.toLoad.isEmpty() && this.mapProcessor.caveStartIsDetermined()) {
         boolean loaded = false;
         synchronized(this.mapProcessor.loadingSync) {
            this.loadingFiles = true;

            MapRegion region;
            for(int limit = this.toLoad.size(); limit > 0 && !this.mapProcessor.isWaitingForWorldUpdate() && !loaded && !this.toLoad.isEmpty(); this.removeToLoad(region)) {
               --limit;
               synchronized(this.toLoad) {
                  if (this.toLoad.isEmpty()) {
                     break;
                  }

                  region = (MapRegion)this.toLoad.get(0);
               }

               int globalRegionCacheHashCode = WorldMap.settings.getRegionCacheHashCode();
               int globalReloadVersion = WorldMap.settings.reloadVersion;
               synchronized(region) {
                  skipCaching = region.getLoadState() == 0 || region.getLoadState() == 4;
                  if (skipCaching) {
                     if (region.getLoadState() == 4 || region.hasVersion() && region.getVersion() != this.mapProcessor.getGlobalVersion() || !region.hasVersion() && region.getInitialVersion() != this.mapProcessor.getGlobalVersion() || region.isMetaLoaded() && this.mainTextureLevel != region.getLevel() && globalRegionCacheHashCode != region.getCacheHashCode()) {
                        region.setShouldCache(true, "loading");
                     }

                     region.setVersion(this.mapProcessor.getGlobalVersion());
                  }
               }

               if (skipCaching) {
                  synchronized(region) {
                     region.setAllCachePrepared(false);
                  }

                  boolean justMetaData = false;
                  if (region.getLoadState() == 0 && !region.isBeingWritten()) {
                     justMetaData = region.loadCacheTextures(this.mapProcessor, !region.isMetaLoaded() && this.mainTextureLevel != region.getLevel());
                  }

                  if (justMetaData) {
                     if (WorldMap.settings.debug) {
                        System.out.println("Loaded meta data for " + region);
                     }
                  } else {
                     this.mapProcessor.addToProcess(region);
                     if (region.getLoadState() == 0) {
                        this.mapProcessor.getMapWorld().getCurrentDimension().getMapRegions().addLoadedRegion(region);
                     }

                     boolean shouldLoadProperly;
                     synchronized(region) {
                        boolean goingToPrepareCache = region.shouldCache() && (region.isMetaLoaded() && this.mainTextureLevel != region.getLevel() || region.getLoadState() == 4 || region.getCacheFile() == null || !region.getCacheFile().exists());
                        shouldLoadProperly = region.isBeingWritten() || goingToPrepareCache;
                        if (!shouldLoadProperly) {
                           region.setLoadState((byte)3);
                        } else if (region.shouldCache()) {
                           region.setRecacheHasBeenRequested(true, "loading");
                        }
                     }

                     if (shouldLoadProperly) {
                        region.setCacheHashCode(globalRegionCacheHashCode);
                        region.setReloadVersion(globalReloadVersion);
                        loaded = this.loadRegion(world, region);
                        if (!loaded) {
                           region.setShouldCache(false, "couldn't load");
                           region.setRecacheHasBeenRequested(false, "couldn't load");
                           if (region.getSaveExists() == null) {
                              synchronized(region) {
                                 region.setLoadState((byte)4);
                              }

                              region.deleteTexturesAndBuffers();
                              if (region.isBeingWritten()) {
                                 region.clean(this.mapProcessor);
                                 synchronized(region) {
                                    region.setLoadState((byte)1);
                                 }
                              } else {
                                 this.mapProcessor.removeMapRegion(region);
                              }
                           }
                        } else {
                           for(int i = 0; i < 8; ++i) {
                              for(int j = 0; j < 8; ++j) {
                                 MapTileChunk mapTileChunk = region.getChunk(i, j);
                                 if (mapTileChunk != null && !mapTileChunk.includeInSave()) {
                                    region.setChunk(i, j, (MapTileChunk)null);
                                    mapTileChunk.getLeafTexture().deleteTexturesAndBuffers();
                                 }
                              }
                           }
                        }

                        synchronized(region) {
                           if (region.getLoadState() <= 1) {
                              region.setLoadState((byte)2);
                           }

                           region.setLastSaveTime(System.currentTimeMillis());
                        }

                        BranchLeveledRegion parentRegion = region.getParent();
                        if (parentRegion != null) {
                           parentRegion.setShouldCheckForUpdatesRecursive(true);
                        }
                     } else if (WorldMap.settings.debug) {
                        System.out.println("Loaded from cache only for " + region);
                     }

                     region.loadingNeededForBranchLevel = 0;
                  }

                  region.setReloadHasBeenRequested(false, "loading");
               }
            }

            this.loadingFiles = false;
         }
      }

      MapRegion region;
      for(int regionsToSave = 3; !this.toSave.isEmpty() && (this.saveAll || regionsToSave > 0); this.toSave.remove(region)) {
         region = (MapRegion)this.toSave.get(0);
         boolean regionLoaded;
         synchronized(region) {
            regionLoaded = region.getLoadState() == 2;
         }

         if (regionLoaded) {
            if (!region.isBeingWritten()) {
               throw new Exception("Saving a weird region: " + region);
            }

            region.pushWriterPause();
            boolean notEmpty = this.saveRegion(region);
            if (notEmpty) {
               if (!region.isAllCachePrepared()) {
                  synchronized(region) {
                     region.requestRefresh(this.mapProcessor);
                  }
               }

               region.setRecacheHasBeenRequested(true, "saving");
               region.setShouldCache(true, "saving");
               region.setBeingWritten(false);
               --regionsToSave;
            } else {
               this.mapProcessor.removeMapRegion(region);
            }

            region.popWriterPause();
            if (region.getWorldId() == null || !this.mapProcessor.isEqual(region.getWorldId(), region.getDimId(), region.getMwId())) {
               if (region.getCacheFile() != null) {
                  try {
                     Files.deleteIfExists(region.getCacheFile().toPath());
                  } catch (IOException var25) {
                     var25.printStackTrace();
                  }

                  if (WorldMap.settings.debug) {
                     System.out.println(String.format("Deleting cache for region %s because it IS outdated.", region));
                  }
               }

               region.clearRegion(this.mapProcessor);
            }
         } else if (WorldMap.settings.debug) {
            System.out.println("Tried to save a weird region: " + region + " " + region.getWorldId() + " " + region.getDimId() + " " + region.getMwId() + " " + region.getLoadState());
         }
      }

      this.saveAll = false;
      int i;
      if (!this.toLoadBranchCache.isEmpty()) {
         i = this.toLoadBranchCache.size();
         synchronized(this.mapProcessor.loadingSync) {
            if (!this.mapProcessor.isWaitingForWorldUpdate()) {
               while(i > 0) {
                  --i;
                  BranchLeveledRegion region;
                  synchronized(this.toLoadBranchCache) {
                     if (this.toLoadBranchCache.isEmpty()) {
                        break;
                     }

                     region = (BranchLeveledRegion)this.toLoadBranchCache.get(0);
                  }

                  region.preCacheLoad();
                  LeveledRegionManager regionManager = this.mapProcessor.getMapWorld().getCurrentDimension().getMapRegions();
                  regionManager.addLoadedRegion(region);
                  this.mapProcessor.addToProcess(region);
                  region.setCacheFile(region.findCacheFile(this));
                  region.loadCacheTextures(this.mapProcessor, false);
                  if (region.getCacheFile() == null) {
                     region.setShouldCheckForUpdatesRecursive(true);
                  }

                  region.setShouldCache(false, "branch loading");
                  region.setLoaded(true);
                  if (WorldMap.settings.debug) {
                     System.out.println("Loaded cache for branch region " + region);
                  }

                  region.setReloadHasBeenRequested(false, "loading");
                  synchronized(this.toLoadBranchCache) {
                     this.toLoadBranchCache.remove(region);
                  }
               }
            }
         }
      }

      if (this.mapProcessor.getMapWorld().getCurrentDimensionId() != null) {
         this.workingDimList.clear();
         this.mapProcessor.getMapWorld().getDimensions(this.workingDimList);

         label311:
         for(i = 0; i < this.workingDimList.size(); ++i) {
            MapDimension dim = (MapDimension)this.workingDimList.get(i);

            while(true) {
               while(true) {
                  if (dim.regionsToCache.isEmpty()) {
                     continue label311;
                  }

                  LeveledRegion<?> region = this.removeToCache(dim, 0);
                  region.preCache();
                  skipCaching = region.skipCaching(this.mapProcessor);
                  if (region.shouldCache() && !skipCaching) {
                     if (!region.isAllCachePrepared()) {
                        throw new RuntimeException("Trying to save cache for a region with cache not prepared: " + region + " " + region.getExtraInfo());
                     }

                     File permFile = region.findCacheFile(this);
                     File tempFile = this.getSecondaryFile(".xwmc.temp", permFile);
                     region.saveCacheTextures(tempFile);
                     this.cacheToConvertFromTemp.add(permFile);
                     region.setCacheFile(permFile);
                     region.setShouldCache(false, "toCache normal");
                     region.setRecacheHasBeenRequested(false, "toCache normal");
                     region.postCache(permFile, this);
                  } else {
                     if (WorldMap.settings.detailed_debug) {
                        System.out.println("toCache cancel: " + region + " " + !region.shouldCache() + " " + !region.isAllCachePrepared() + " " + skipCaching + " " + this.mapProcessor.getGlobalVersion());
                     }

                     if (region.shouldCache()) {
                        region.deleteBuffers();
                     }

                     region.setShouldCache(false, "toCache cancel");
                     region.setRecacheHasBeenRequested(false, "toCache cancel");
                     region.postCache((File)null, this);
                  }
               }
            }
         }
      }

      for(i = 0; i < this.cacheToConvertFromTemp.size(); ++i) {
         File permFile = (File)this.cacheToConvertFromTemp.get(i);
         File tempFile = this.getSecondaryFile(".xwmc.temp", permFile);

         try {
            if (Files.exists(tempFile.toPath(), new LinkOption[0])) {
               Misc.safeMoveAndReplace(tempFile.toPath(), permFile.toPath(), true);
            }

            this.cacheToConvertFromTemp.remove(i);
            --i;
         } catch (FileSystemException var23) {
         }
      }

   }

   private void savePixel(MapBlock pixel, DataOutputStream out) throws IOException {
      out.writeInt(pixel.getParametres());
      if (!pixel.isGrass()) {
         out.writeInt(pixel.getState());
      }

      int biome;
      if (pixel.getNumberOfOverlays() != 0) {
         out.write(pixel.getOverlays().size());

         for(biome = 0; biome < pixel.getOverlays().size(); ++biome) {
            this.saveOverlay((Overlay)pixel.getOverlays().get(biome), out);
         }
      }

      if (pixel.getColourType() == 3) {
         out.writeInt(pixel.getCustomColour());
      }

      biome = pixel.getBiome();
      if (biome != -1) {
         if (biome < 255) {
            out.write(pixel.getBiome());
         } else {
            out.write(255);
            out.writeInt(biome);
         }
      }

   }

   private void loadPixel(Integer next, MapBlock pixel, DataInputStream in, int saveVersion, World world, int globalX, int globalZ, int[] overlayBiomeBuffer) throws IOException {
      int parametres;
      if (next != null) {
         parametres = next;
      } else {
         parametres = in.readInt();
      }

      if ((parametres & 1) != 0) {
         pixel.setState(in.readInt());
      } else {
         pixel.setState(Block.func_176210_f(Blocks.field_150349_c.func_176223_P()));
      }

      if ((parametres & 64) != 0) {
         pixel.setHeight(in.read());
      } else {
         pixel.setHeight(parametres >> 12 & 255);
      }

      int biomeByte;
      if ((parametres & 2) != 0) {
         biomeByte = in.read();
         this.overlayBuilder.startBuilding();

         for(int i = 0; i < biomeByte; ++i) {
            this.loadOverlay(pixel, in, saveVersion, world, overlayBiomeBuffer);
         }

         this.overlayBuilder.finishBuilding(pixel);
      }

      pixel.setColourType((byte)(parametres >> 2 & 3));
      if (pixel.getColourType() == 3) {
         pixel.setCustomColour(in.readInt());
      }

      if (pixel.getColourType() != 0 && pixel.getColourType() != 3 || (parametres & 1048576) != 0) {
         biomeByte = in.read();
         if (saveVersion >= 3 && biomeByte >= 255) {
            pixel.setBiome(in.readInt());
         } else {
            pixel.setBiome(biomeByte);
         }
      }

      if (pixel.getColourType() == 3 && pixel.getCustomColour() == -1) {
         pixel.setColourType((byte)0);
      }

      pixel.setCaveBlock((parametres & 128) != 0);
      pixel.setLight((byte)(parametres >> 8 & 15));
      pixel.setGlowing(this.mapProcessor.getMapWriter().isGlowing(Misc.getStateById(pixel.getState()).func_177230_c()));
   }

   private void saveOverlay(Overlay o, DataOutputStream out) throws IOException {
      out.writeInt(o.getParametres());
      if (!o.isWater()) {
         out.writeInt(o.getState());
      }

      if (o.getColourType() == 2) {
         out.writeInt(o.getCustomColour());
      }

      if (o.getOpacity() > 1) {
         out.writeInt(o.getOpacity());
      }

   }

   private void loadOverlay(MapBlock pixel, DataInputStream in, int saveVersion, World world, int[] overlayBiomeBuffer) throws IOException {
      int parametres = in.readInt();
      int state;
      if ((parametres & 1) != 0) {
         state = in.readInt();
      } else {
         state = Block.func_176210_f(Blocks.field_150355_j.func_176223_P());
      }

      int opacity = 1;
      if (saveVersion < 1 && (parametres & 2) != 0) {
         in.readInt();
      }

      overlayBiomeBuffer[1] = overlayBiomeBuffer[2] = -1;
      overlayBiomeBuffer[0] = (byte)(parametres >> 8 & 3);
      if (overlayBiomeBuffer[0] == 2 || (parametres & 4) != 0) {
         overlayBiomeBuffer[0] = 2;
         overlayBiomeBuffer[2] = in.readInt();
         if (overlayBiomeBuffer[2] == -1) {
            overlayBiomeBuffer[0] = 0;
         }
      }

      if ((parametres & 8) != 0) {
         opacity = in.readInt();
      }

      byte light = (byte)(parametres >> 4 & 15);
      this.overlayBuilder.build(state, overlayBiomeBuffer, opacity, light, world, this.mapProcessor, (BlockPos)null, 0, (BlockStateColorTypeCache)null, (BiomeInfoSupplier)null);
   }

   public boolean isRegionDetectionComplete() {
      return this.regionDetectionComplete;
   }

   public void setRegionDetectionComplete(boolean regionDetectionComplete) {
      this.regionDetectionComplete = regionDetectionComplete;
   }

   public void requestCache(LeveledRegion<?> region) {
      if (!this.toCacheContains(region)) {
         synchronized(region.getDim().regionsToCache) {
            region.getDim().regionsToCache.add(region);
         }

         if (WorldMap.settings.debug) {
            System.out.println("Requesting cache! " + region);
         }
      }

   }

   public LeveledRegion<?> removeToCache(MapDimension mapDim, int index) {
      synchronized(mapDim.regionsToCache) {
         return (LeveledRegion)mapDim.regionsToCache.remove(index);
      }
   }

   public void removeToCache(LeveledRegion<?> region) {
      synchronized(region.getDim().regionsToCache) {
         region.getDim().regionsToCache.remove(region);
      }
   }

   public boolean toCacheContains(LeveledRegion<?> region) {
      synchronized(region.getDim().regionsToCache) {
         return region.getDim().regionsToCache.contains(region);
      }
   }

   public ArrayList<MapRegion> getToSave() {
      return this.toSave;
   }

   public LeveledRegion<?> getNextToLoadByViewing() {
      return this.nextToLoadByViewing;
   }

   /** @deprecated */
   @Deprecated
   public void setNextToLoadByViewing(MapRegion nextToLoadByViewing) {
      this.setNextToLoadByViewing((LeveledRegion)nextToLoadByViewing);
   }

   public void setNextToLoadByViewing(LeveledRegion<?> nextToLoadByViewing) {
      this.nextToLoadByViewing = nextToLoadByViewing;
   }

   public void safeDelete(Path filePath, String extension) throws IOException {
      if (!filePath.getFileName().toString().endsWith(extension)) {
         throw new RuntimeException("Incorrect file extension: " + filePath);
      } else {
         Files.deleteIfExists(filePath);
      }
   }

   public void safeMoveAndReplace(Path fromPath, Path toPath, String fromExtension, String toExtension) throws IOException {
      if (toPath.getFileName().toString().endsWith(toExtension) && fromPath.getFileName().toString().endsWith(fromExtension)) {
         Misc.safeMoveAndReplace(fromPath, toPath, true);
      } else {
         throw new RuntimeException("Incorrect file extension: " + fromPath + " " + toPath);
      }
   }

   public int getSizeOfToLoadBranchCache() {
      return this.toLoadBranchCache.size();
   }

   public ArrayList<Path> getCacheFolders() {
      return this.cacheFolders;
   }
}
