package xaero.map.mcworld;

import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.BlockPos;

public class WorldMapClientWorldData {
   public Integer serverLevelId;
   public Integer usedServerLevelId;
   public BlockPos latestSpawn;
   public BlockPos usedSpawn;
   public float shadowR = 1.0F;
   public float shadowG = 1.0F;
   public float shadowB = 1.0F;

   public WorldMapClientWorldData(WorldClient world) {
      if (world.field_73011_w.func_177502_q() == 0) {
         this.shadowR = 0.518F;
         this.shadowG = 0.678F;
         this.shadowB = 1.0F;
      } else if (world.field_73011_w.func_177502_q() == -1) {
         this.shadowR = 1.0F;
         this.shadowG = 0.0F;
         this.shadowB = 0.0F;
      }

   }
}
