package xaero.map.mcworld;

public interface IWorldMapClientWorld {
   WorldMapClientWorldData getXaero_worldmapData();

   void setXaero_worldmapData(WorldMapClientWorldData var1);
}
