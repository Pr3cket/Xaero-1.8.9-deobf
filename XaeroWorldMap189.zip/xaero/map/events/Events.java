package xaero.map.events;

import com.google.common.util.concurrent.ListenableFutureTask;
import java.io.IOException;
import java.util.Queue;
import java.util.concurrent.FutureTask;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.world.WorldServer;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent.ActionPerformedEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.TextureStitchEvent.Post;
import net.minecraftforge.event.entity.player.PlayerSetSpawnEvent;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;
import org.lwjgl.input.Mouse;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.WorldMapSession;
import xaero.map.misc.Misc;
import xaero.map.mods.SupportMods;
import xaero.patreon.GuiUpdateAll3;
import xaero.patreon.Patreon7;

public class Events {
   private boolean listenToTextureStitch;

   @SubscribeEvent
   public void guiButtonClick(ActionPerformedEvent event) {
   }

   @SubscribeEvent
   public void guiOpen(GuiOpenEvent event) {
      if (event.gui == null) {
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         if (worldmapSession != null) {
            MapProcessor mapProcessor = worldmapSession.getMapProcessor();
            mapProcessor.onGuiClosed();
         }
      }

   }

   @SubscribeEvent
   public void modelBake(Post event) throws IOException {
      boolean shouldListen = this.listenToTextureStitch;
      this.listenToTextureStitch = true;
      WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
      if (worldmapSession != null) {
         MapProcessor mapProcessor = worldmapSession.getMapProcessor();
         mapProcessor.getMapWriter().getColorTypeCache().updateGrassColor();
         if (shouldListen) {
            mapProcessor.getMapWriter().requestCachedColoursClear();
         }
      }

      if (shouldListen) {
         if (SupportMods.minimap()) {
            WorldMap.waypointSymbolCreator.resetChars();
         }

         if (WorldMap.settings != null) {
            WorldMap.settings.updateRegionCacheHashCode();
         }
      }

   }

   @SubscribeEvent
   public void renderTick(RenderTickEvent event) throws Exception {
      Minecraft mc = Minecraft.func_71410_x();
      if (event.phase == Phase.END) {
         WorldMap.glObjectDeleter.work();
      }

      if (mc.field_71439_g != null) {
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         if (worldmapSession != null) {
            MapProcessor mapProcessor = worldmapSession.getMapProcessor();
            ScaledResolution scaledresolution;
            if (event.phase == Phase.END) {
               scaledresolution = new ScaledResolution(mc);
               mapProcessor.onRenderProcess(mc, scaledresolution);
               mc.field_71454_w = false;
               mapProcessor.resetRenderStartTime();
               Queue<FutureTask<?>> minecraftScheduledTasks = mapProcessor.getMinecraftScheduledTasks();
               ListenableFutureTask<?> listenablefuturetask = ListenableFutureTask.create(mapProcessor.getRenderStartTimeUpdater());
               synchronized(minecraftScheduledTasks) {
                  FutureTask<?>[] currentTasks = (FutureTask[])minecraftScheduledTasks.toArray(new FutureTask[0]);
                  minecraftScheduledTasks.clear();
                  minecraftScheduledTasks.add(listenablefuturetask);
                  FutureTask[] var10 = currentTasks;
                  int var11 = currentTasks.length;

                  for(int var12 = 0; var12 < var11; ++var12) {
                     FutureTask<?> t = var10[var12];
                     minecraftScheduledTasks.add(t);
                  }
               }
            } else if (event.phase == Phase.START) {
               if (!SupportMods.vivecraft && Misc.screenShouldSkipWorldRender(mc.field_71462_r, true)) {
                  Misc.setShaderProgram(0);
                  scaledresolution = new ScaledResolution(mc);
                  int i1 = scaledresolution.func_78326_a();
                  int j1 = scaledresolution.func_78328_b();
                  int k1 = Mouse.getX() * i1 / mc.field_71443_c;
                  int l1 = j1 - Mouse.getY() * j1 / mc.field_71440_d - 1;
                  GlStateManager.func_179126_j();
                  GlStateManager.func_179083_b(0, 0, mc.field_71443_c, mc.field_71440_d);
                  GlStateManager.func_179128_n(5889);
                  GlStateManager.func_179096_D();
                  GlStateManager.func_179128_n(5888);
                  GlStateManager.func_179096_D();
                  mc.field_71460_t.func_78478_c();
                  GlStateManager.func_179086_m(256);
                  ForgeHooksClient.drawScreen(mc.field_71462_r, k1, l1, 0.0F);
                  mc.field_71454_w = true;
               }

               if (mapProcessor != null) {
                  mapProcessor.setMainValues();
               }
            }
         }
      }

   }

   @SubscribeEvent
   public void renderTick(net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent.Post event) {
      if (!Patreon7.needsNotification() || !(event.gui instanceof GuiMainMenu) || SupportMods.minimap() && SupportMods.xaeroMinimap.compatibilityVersion >= 1) {
         if (WorldMap.isOutdated) {
            WorldMap.isOutdated = false;
         }
      } else {
         Minecraft.func_71410_x().func_147108_a(new GuiUpdateAll3());
      }

   }

   @SubscribeEvent
   public void spawnSet(PlayerSetSpawnEvent event) {
      if (event.entityPlayer.field_70170_p instanceof WorldClient) {
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         if (worldmapSession != null) {
            MapProcessor mapProcessor = worldmapSession.getMapProcessor();
            mapProcessor.updateWorldSpawn(event.newSpawn, (WorldClient)event.entityPlayer.field_70170_p);
         }
      }

   }

   @SubscribeEvent
   public void worldUnload(Unload event) {
      if (Minecraft.func_71410_x().field_71439_g != null) {
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         if (worldmapSession != null) {
            MapProcessor mapProcessor = worldmapSession.getMapProcessor();
            if (event.world == mapProcessor.mainWorld) {
               mapProcessor.onWorldUnload();
            }
         }
      }

      if (event.world instanceof WorldServer) {
         WorldServer sw = (WorldServer)event.world;
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         if (worldmapSession != null) {
            MapProcessor mapProcessor = worldmapSession.getMapProcessor();
            mapProcessor.getWorldDataHandler().onServerWorldUnload(sw);
         }
      }

   }

   @SubscribeEvent
   protected void handleRenderGameOverlayEventPost(net.minecraftforge.client.event.RenderGameOverlayEvent.Post event) {
      if (event.type == ElementType.CROSSHAIRS) {
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         MapProcessor mapProcessor = worldmapSession == null ? null : worldmapSession.getMapProcessor();
         String crosshairMessage = mapProcessor == null ? null : mapProcessor.getCrosshairMessage();
         if (crosshairMessage != null) {
            int messageWidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(crosshairMessage);
            GlStateManager.func_179084_k();
            Minecraft.func_71410_x().field_71466_p.func_175063_a(crosshairMessage, (float)(event.resolution.func_78326_a() / 2 - messageWidth / 2), (float)(event.resolution.func_78328_b() / 2 + 60), -1);
            GlStateManager.func_179147_l();
         }
      }

   }
}
