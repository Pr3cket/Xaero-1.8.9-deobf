package xaero.map.events;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.PlayerTickEvent;
import net.minecraftforge.fml.relauncher.Side;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.WorldMapSession;

public class FMLEvents {
   @SubscribeEvent
   public void playerTick(PlayerTickEvent event) {
      if (event.side == Side.CLIENT && event.player == Minecraft.func_71410_x().field_71439_g && event.phase == Phase.START) {
         WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
         if (worldmapSession != null) {
            worldmapSession.getControlsHandler().handleKeyEvents();
         }
      }

   }

   @SubscribeEvent
   public void clientTick(ClientTickEvent event) throws Exception {
      if (event.phase == Phase.START) {
         WorldMap.worldMapClient.onTick();
         if (Minecraft.func_71410_x().field_71439_g != null) {
            WorldMap.crashHandler.checkForCrashes();
            WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
            if (worldmapSession != null) {
               MapProcessor mapProcessor = worldmapSession.getMapProcessor();
               mapProcessor.onClientTickStart();
            }
         }
      }

   }
}
