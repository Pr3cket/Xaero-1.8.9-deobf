package xaero.map.misc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.Cipher;
import xaero.map.WorldMap;
import xaero.map.settings.ModSettings;
import xaero.patreon.Patreon7;
import xaero.patreon.decrypt.DecryptInputStream;

public class Internet {
   public static Cipher cipher = null;

   public static void checkModVersion() {
      String s = "http://data.chocolateminecraft.com/Versions_" + Patreon7.KEY_VERSION + "/WorldMap.txt";
      s = s.replaceAll(" ", "%20");

      try {
         if (cipher == null) {
            throw new Exception("Cipher instance is null!");
         }

         URL url = new URL(s);
         URLConnection conn = url.openConnection();
         conn.setReadTimeout(900);
         conn.setConnectTimeout(900);
         if (conn.getContentLengthLong() > 524288L) {
            throw new IOException("Input too long to trust!");
         }

         BufferedReader reader = new BufferedReader(new InputStreamReader(new DecryptInputStream(conn.getInputStream(), cipher), "UTF8"));
         String line = reader.readLine();
         if (line != null) {
            WorldMap.newestUpdateID = Integer.parseInt(line);
            if (!ModSettings.updateNotification || WorldMap.newestUpdateID == ModSettings.ignoreUpdate) {
               WorldMap.isOutdated = false;
               reader.close();
               return;
            }
         }

         boolean versionFound = false;
         String[] current = WorldMap.versionID.split("_");

         label77:
         while(true) {
            String[] args;
            do {
               do {
                  do {
                     if ((line = reader.readLine()) == null) {
                        break label77;
                     }

                     if (line.equals(WorldMap.versionID)) {
                        WorldMap.isOutdated = false;
                        break label77;
                     }
                  } while(!Patreon7.getHasAutoUpdates());

                  if (versionFound) {
                     if (line.startsWith("meta;")) {
                        args = line.substring(5).split(";");
                        WorldMap.latestVersionMD5 = args[0];
                     }

                     versionFound = false;
                  }
               } while(!line.startsWith(current[0] + "_"));

               args = line.split("_");
            } while(args.length != current.length);

            boolean sameType = true;
            if (current.length > 2) {
               for(int i = 2; i < current.length && sameType; ++i) {
                  if (!args[i].equals(current[i])) {
                     sameType = false;
                  }
               }
            }

            if (sameType) {
               WorldMap.latestVersion = args[1];
               versionFound = true;
            }
         }

         reader.close();
      } catch (Throwable var10) {
         var10.printStackTrace();
         WorldMap.isOutdated = false;
      }

   }

   static {
      try {
         cipher = Cipher.getInstance("RSA");
         KeyFactory factory = KeyFactory.getInstance("RSA");
         byte[] byteKey = Base64.getDecoder().decode(Patreon7.publicKeyString.getBytes());
         X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
         PublicKey publicKey = factory.generatePublic(X509publicKey);
         cipher.init(2, publicKey);
      } catch (Exception var4) {
         cipher = null;
         var4.printStackTrace();
      }

   }
}
