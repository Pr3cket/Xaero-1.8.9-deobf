package xaero.map.misc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.EXTSeparateShaderObjects;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GLContext;
import xaero.map.gui.IScreenBase;
import xaero.map.mods.SupportMods;

public class Misc {
   private static final long[] ZERO_LONG_586 = new long[586];
   private static long cpuTimerPreTime;
   private static long glTimerPreTime;
   private static int shadersType = -500;
   private static boolean EXTgeometryShader;

   public static int myFloor(double d) {
      int asInt = (int)d;
      if ((double)asInt != d && d < 0.0D) {
         --asInt;
      }

      return asInt;
   }

   public static double round(double a, int komaarvu) {
      double x = Math.pow(10.0D, (double)komaarvu);
      return (double)Math.round(a * x) / x;
   }

   public static IBlockState getStateById(int id) {
      try {
         return Block.func_176220_d(id);
      } catch (Exception var2) {
         return getDefaultBlockStateForStateId(id);
      }
   }

   private static IBlockState getDefaultBlockStateForStateId(int id) {
      try {
         Block block = Block.func_176220_d(id).func_177230_c();
         return block.func_176223_P();
      } catch (Exception var2) {
         return Blocks.field_150350_a.func_176223_P();
      }
   }

   public static void glTimerPre() {
      GL11.glFinish();
      glTimerPreTime = System.nanoTime();
   }

   public static int glTimerResult() {
      GL11.glFinish();
      return (int)(System.nanoTime() - glTimerPreTime);
   }

   public static void timerPre() {
      cpuTimerPreTime = System.nanoTime();
   }

   public static int timerResult() {
      return (int)(System.nanoTime() - cpuTimerPreTime);
   }

   public static double getMouseX(Minecraft mc) {
      return (double)Mouse.getX();
   }

   public static double getMouseY(Minecraft mc) {
      return (double)(mc.field_71440_d - Mouse.getY() - 1);
   }

   public static void clearHeightsData586(long[] data) {
      System.arraycopy(ZERO_LONG_586, 0, data, 0, 586);
   }

   public static <T extends Comparable<? super T>> void addToListOfSmallest(int maxSize, List<T> list, T element) {
      int currentSize = list.size();
      if (currentSize != maxSize || ((Comparable)list.get(currentSize - 1)).compareTo(element) > 0) {
         int iterLimit = currentSize == maxSize ? maxSize : currentSize + 1;

         for(int i = 0; i < iterLimit; ++i) {
            if (i == currentSize || element.compareTo(list.get(i)) < 0) {
               list.add(i, element);
               if (currentSize == maxSize) {
                  list.remove(currentSize);
               }
               break;
            }
         }

      }
   }

   public static void minecraftOrtho(ScaledResolution scaledresolution) {
      GlStateManager.func_179096_D();
      GlStateManager.func_179130_a(0.0D, scaledresolution.func_78327_c(), scaledresolution.func_78324_d(), 0.0D, 1000.0D, 3000.0D);
   }

   public static void setShaderProgram(int program) {
      if (shadersType == -500) {
         shadersType = GLContext.getCapabilities().OpenGL20 ? 0 : (GLContext.getCapabilities().GL_ARB_shader_objects ? 1 : (GLContext.getCapabilities().GL_EXT_separate_shader_objects ? 2 : -1));
         EXTgeometryShader = GLContext.getCapabilities().GL_EXT_geometry_shader4 || GLContext.getCapabilities().GL_ARB_geometry_shader4;
      }

      switch(shadersType) {
      case 0:
         GL20.glUseProgram(program);
         break;
      case 1:
         ARBShaderObjects.glUseProgramObjectARB(program);
         break;
      case 2:
         EXTSeparateShaderObjects.glUseShaderProgramEXT(35633, program);
         if (EXTgeometryShader) {
            EXTSeparateShaderObjects.glUseShaderProgramEXT(36313, program);
         }

         EXTSeparateShaderObjects.glUseShaderProgramEXT(35632, program);
         EXTSeparateShaderObjects.glActiveProgramEXT(program);
      }

   }

   public static String getKeyName(KeyBinding kb) {
      return kb.func_151463_i() == 0 ? "(unset)" : GameSettings.func_74298_c(kb.func_151463_i()).toUpperCase();
   }

   public static boolean inputMatchesKeyBinding(boolean mouse, int code, KeyBinding kb) {
      if (code == 0) {
         return false;
      } else {
         if (mouse) {
            code -= 100;
         }

         return kb.func_151463_i() == code;
      }
   }

   public static Path quickFileBackupMove(Path file) throws IOException {
      Path backupPath = null;

      for(int backupNumber = 0; Files.exists(backupPath = file.resolveSibling(file.getFileName().toString() + ".backup" + backupNumber), new LinkOption[0]); ++backupNumber) {
      }

      Files.move(file, backupPath);
      return backupPath;
   }

   public static void safeMoveAndReplace(Path from, Path to, boolean backupFrom) throws IOException {
      Path backupPath = null;
      Path fromBackupPath = null;
      if (backupFrom) {
         while(true) {
            try {
               fromBackupPath = quickFileBackupMove(from);
               break;
            } catch (IOException var8) {
               try {
                  Thread.sleep(10L);
               } catch (InterruptedException var7) {
               }
            }
         }
      } else {
         fromBackupPath = from;
      }

      if (Files.exists(to, new LinkOption[0])) {
         backupPath = quickFileBackupMove(to);
      }

      Files.move(fromBackupPath, to);
      if (backupPath != null) {
         Files.delete(backupPath);
      }

   }

   public static boolean screenShouldSkipWorldRender(GuiScreen screen, boolean checkOtherMod) {
      return screen instanceof IScreenBase && ((IScreenBase)screen).shouldSkipWorldRender() || checkOtherMod && SupportMods.minimap() && SupportMods.xaeroMinimap.screenShouldSkipWorldRender(screen);
   }
}
