package xaero.map.core;

import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.server.S21PacketChunkData;
import net.minecraft.network.play.server.S22PacketMultiBlockChange;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import xaero.map.WorldMap;
import xaero.map.WorldMapSession;

public class XaeroWorldMapCore {
   public static Field chunkCleanField = null;
   public static WorldMapSession currentSession;

   public static void ensureField() {
      if (chunkCleanField == null) {
         try {
            chunkCleanField = Chunk.class.getDeclaredField("xaero_wm_chunkClean");
         } catch (SecurityException | NoSuchFieldException var1) {
            throw new RuntimeException(var1);
         }
      }

   }

   public static void chunkUpdateCallback(int chunkX, int chunkZ) {
      ensureField();
      World world = Minecraft.func_71410_x().field_71441_e;
      if (world != null) {
         try {
            for(int x = chunkX - 1; x < chunkX + 2; ++x) {
               for(int z = chunkZ - 1; z < chunkZ + 2; ++z) {
                  Chunk chunk = world.func_72964_e(x, z);
                  if (chunk != null) {
                     chunkCleanField.set(chunk, false);
                  }
               }
            }
         } catch (IllegalAccessException | IllegalArgumentException var6) {
            throw new RuntimeException(var6);
         }
      }

   }

   public static void onChunkData(S21PacketChunkData packetIn) {
      chunkUpdateCallback(packetIn.func_149273_e(), packetIn.func_149271_f());
   }

   public static void onBlockChange(S23PacketBlockChange packetIn) {
      chunkUpdateCallback(packetIn.func_179827_b().func_177958_n() >> 4, packetIn.func_179827_b().func_177952_p() >> 4);
   }

   public static void onMultiBlockChange(S22PacketMultiBlockChange packetIn) {
      chunkUpdateCallback(packetIn.func_179844_a()[0].func_180090_a().func_177958_n() >> 4, packetIn.func_179844_a()[0].func_180090_a().func_177952_p() >> 4);
   }

   public static void onPlayNetHandler(NetHandlerPlayClient netHandler) {
      try {
         IWorldMapClientPlayNetHandler netHandlerAccess = (IWorldMapClientPlayNetHandler)netHandler;
         if (netHandlerAccess.getXaero_worldmapSession() != null) {
            return;
         }

         if (currentSession != null) {
            System.out.println("Previous world map session still active. Probably using MenuMobs. Forcing it to end...");
            cleanupCurrentSession();
         }

         WorldMapSession worldmapSession = new WorldMapSession();
         currentSession = worldmapSession;
         worldmapSession.init();
         netHandlerAccess.setXaero_worldmapSession(worldmapSession);
      } catch (Throwable var3) {
         if (currentSession != null) {
            cleanupCurrentSession();
         }

         RuntimeException wrappedException = new RuntimeException("Exception initializing Xaero's World Map! ", var3);
         WorldMap.crashHandler.setCrashedBy(wrappedException);
      }

   }

   private static void cleanupCurrentSession() {
      try {
         currentSession.cleanup();
      } catch (Throwable var4) {
         var4.printStackTrace();
      } finally {
         currentSession = null;
      }

   }

   public static void onPlayNetHandlerCleanup(NetHandlerPlayClient netHandler) {
      try {
         WorldMapSession netHandlerSession = ((IWorldMapClientPlayNetHandler)netHandler).getXaero_worldmapSession();
         if (netHandlerSession == null) {
            return;
         }

         try {
            netHandlerSession.cleanup();
         } finally {
            if (netHandlerSession == currentSession) {
               currentSession = null;
            }

            ((IWorldMapClientPlayNetHandler)netHandler).setXaero_worldmapSession((WorldMapSession)null);
         }
      } catch (Throwable var6) {
         RuntimeException wrappedException = new RuntimeException("Exception finalizing Xaero's World Map! ", var6);
         WorldMap.crashHandler.setCrashedBy(wrappedException);
      }

   }
}
