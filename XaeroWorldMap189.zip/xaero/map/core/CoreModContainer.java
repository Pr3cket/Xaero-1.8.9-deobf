package xaero.map.core;

import com.google.common.eventbus.EventBus;
import java.util.Arrays;
import net.minecraftforge.fml.common.DummyModContainer;
import net.minecraftforge.fml.common.LoadController;
import net.minecraftforge.fml.common.ModMetadata;

public class CoreModContainer extends DummyModContainer {
   public CoreModContainer() {
      super(new ModMetadata());
      ModMetadata meta = this.getMetadata();
      meta.modId = "xaeroworldmap_core";
      meta.name = "XaeroWorldMapCore";
      meta.description = "Required by Xaero's World Map.";
      meta.version = "1.8.9-1.0";
      meta.authorList = Arrays.asList("Xaero");
   }

   public boolean registerBus(EventBus bus, LoadController controller) {
      bus.register(this);
      return true;
   }
}
