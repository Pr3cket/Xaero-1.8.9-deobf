package xaero.map.core.transformer;

import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;

public class WorldClientTransformer extends ClassNodeTransformer {
   public byte[] transform(String name, String transformedName, byte[] basicClass) {
      this.className = "net.minecraft.client.multiplayer.WorldClient";
      return super.transform(name, transformedName, basicClass);
   }

   protected void transformNode(ClassNode classNode, boolean isObfuscated) {
      classNode.interfaces.add("xaero/map/mcworld/IWorldMapClientWorld");
      classNode.fields.add(new FieldNode(2, "xaero_worldmapData", "Lxaero/map/mcworld/WorldMapClientWorldData;", (String)null, (Object)null));
      this.addGetter(classNode, "xaero_worldmapData", "Lxaero/map/mcworld/WorldMapClientWorldData;");
      this.addSetter(classNode, "xaero_worldmapData", "Lxaero/map/mcworld/WorldMapClientWorldData;");
   }
}
