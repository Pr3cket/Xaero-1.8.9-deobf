package xaero.map.core.transformer;

import java.util.Iterator;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

public class EntityPlayerTransformer extends ClassNodeTransformer {
   public byte[] transform(String name, String transformedName, byte[] basicClass) {
      this.className = "net.minecraft.entity.player.EntityPlayer";
      return super.transform(name, transformedName, basicClass);
   }

   protected void transformNode(ClassNode classNode, boolean isObfuscated) {
      String methodName = isObfuscated ? "a" : "isWearing";
      String methodDesc = isObfuscated ? "(Lwo;)Z" : "(Lnet/minecraft/entity/player/EnumPlayerModelParts;)Z";
      Iterator var5 = classNode.methods.iterator();

      while(var5.hasNext()) {
         MethodNode methodNode = (MethodNode)var5.next();
         if (methodNode.name.equals(methodName) && methodNode.desc.equals(methodDesc)) {
            break;
         }
      }

      System.out.println();
   }
}
