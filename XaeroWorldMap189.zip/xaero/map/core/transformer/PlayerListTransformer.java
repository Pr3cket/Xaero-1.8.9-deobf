package xaero.map.core.transformer;

import java.util.Iterator;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class PlayerListTransformer extends ClassNodeTransformer {
   public byte[] transform(String name, String transformedName, byte[] basicClass) {
      this.className = "net.minecraft.server.management.ServerConfigurationManager";
      return super.transform(name, transformedName, basicClass);
   }

   protected void transformNode(ClassNode classNode, boolean isObfuscated) {
      String methodNameWorldInfo = isObfuscated ? "b" : "updateTimeAndWeatherForPlayer";
      String methodDescWorldInfo = isObfuscated ? "(Llf;Lle;)V" : "(Lnet/minecraft/entity/player/EntityPlayerMP;Lnet/minecraft/world/WorldServer;)V";
      Iterator var5 = classNode.methods.iterator();

      while(var5.hasNext()) {
         MethodNode methodNode = (MethodNode)var5.next();
         if (methodNode.name.equals(methodNameWorldInfo) && methodNode.desc.equals(methodDescWorldInfo)) {
            this.insertWorldInfoCall(methodNode);
            break;
         }
      }

   }

   private void insertWorldInfoCall(MethodNode methodNode) {
      InsnList patchList = new InsnList();
      patchList.add(new VarInsnNode(25, 1));
      patchList.add(new MethodInsnNode(184, "xaero/map/server/core/XaeroWorldMapServerCore", "onServerWorldInfo", "(Lnet/minecraft/entity/player/EntityPlayer;)V", false));
      AbstractInsnNode firstInsn = methodNode.instructions.get(0);
      if (firstInsn instanceof LabelNode) {
         methodNode.instructions.insert(firstInsn, patchList);
      } else {
         methodNode.instructions.insertBefore(firstInsn, patchList);
      }

   }
}
