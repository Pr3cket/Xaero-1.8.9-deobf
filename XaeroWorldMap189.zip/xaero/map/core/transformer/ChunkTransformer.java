package xaero.map.core.transformer;

import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;

public class ChunkTransformer extends ClassNodeTransformer {
   public byte[] transform(String name, String transformedName, byte[] basicClass) {
      this.className = "net.minecraft.world.chunk.Chunk";
      return super.transform(name, transformedName, basicClass);
   }

   protected void transformNode(ClassNode classNode, boolean isObfuscated) {
      classNode.fields.add(new FieldNode(1, "xaero_wm_chunkClean", "Z", (String)null, 0));
   }
}
