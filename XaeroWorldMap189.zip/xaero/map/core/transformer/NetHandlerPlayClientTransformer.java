package xaero.map.core.transformer;

import java.util.Iterator;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class NetHandlerPlayClientTransformer extends ClassNodeTransformer {
   public byte[] transform(String name, String transformedName, byte[] basicClass) {
      this.className = "net.minecraft.client.network.NetHandlerPlayClient";
      return super.transform(name, transformedName, basicClass);
   }

   protected void transformNode(ClassNode classNode, boolean isObfuscated) {
      String methodNameHandleMultiBlockChange = isObfuscated ? "a" : "handleMultiBlockChange";
      String methodNameHandleChunkData = isObfuscated ? "a" : "handleChunkData";
      String methodNameHandleBlockChange = isObfuscated ? "a" : "handleBlockChange";
      String methodNameHandleJoinGame = isObfuscated ? "a" : "handleJoinGame";
      String methodDescHandleMultiBlockChange = isObfuscated ? "(Lfz;)V" : "(Lnet/minecraft/network/play/server/S22PacketMultiBlockChange;)V";
      String methodDescHandleChunkData = isObfuscated ? "(Lgo;)V" : "(Lnet/minecraft/network/play/server/S21PacketChunkData;)V";
      String methodDescHandleBlockChange = isObfuscated ? "(Lfv;)V" : "(Lnet/minecraft/network/play/server/S23PacketBlockChange;)V";
      String methodDescHandleJoinGame = isObfuscated ? "(Lgt;)V" : "(Lnet/minecraft/network/play/server/S01PacketJoinGame;)V";
      String methodNameCleanup = isObfuscated ? "b" : "cleanup";
      boolean multiBlockChangeRedirected = false;
      boolean chunkDataRedirected = false;
      boolean blockChangeRedirected = false;
      boolean joinGameTransformed = false;
      boolean cleanupTransformed = false;
      Iterator var17 = classNode.methods.iterator();

      while(var17.hasNext()) {
         MethodNode mn = (MethodNode)var17.next();
         if (mn.name.equals(methodNameHandleMultiBlockChange) && mn.desc.equals(methodDescHandleMultiBlockChange)) {
            this.clientPacketRedirectTransform(mn, new MethodInsnNode(184, "xaero/map/core/XaeroWorldMapCore", "onMultiBlockChange", methodDescHandleMultiBlockChange, false), isObfuscated);
            multiBlockChangeRedirected = true;
         } else if (mn.name.equals(methodNameHandleChunkData) && mn.desc.equals(methodDescHandleChunkData)) {
            this.clientPacketRedirectTransform(mn, new MethodInsnNode(184, "xaero/map/core/XaeroWorldMapCore", "onChunkData", methodDescHandleChunkData, false), isObfuscated);
            chunkDataRedirected = true;
         } else if (mn.name.equals(methodNameHandleBlockChange) && mn.desc.equals(methodDescHandleBlockChange)) {
            this.clientPacketRedirectTransform(mn, new MethodInsnNode(184, "xaero/map/core/XaeroWorldMapCore", "onBlockChange", methodDescHandleBlockChange, false), isObfuscated);
            blockChangeRedirected = true;
         } else if (mn.name.equals(methodNameHandleJoinGame) && mn.desc.equals(methodDescHandleJoinGame)) {
            this.clientPacketRedirectTransformCustom(mn, new MethodInsnNode(184, "xaero/map/core/XaeroWorldMapCore", "onPlayNetHandler", "(Lnet/minecraft/client/network/NetHandlerPlayClient;)V", false), isObfuscated, 0);
            joinGameTransformed = true;
         } else if (mn.name.equals(methodNameCleanup) && mn.desc.equals("()V")) {
            InsnList patchList = new InsnList();
            patchList.add(new VarInsnNode(25, 0));
            patchList.add(new MethodInsnNode(184, "xaero/map/core/XaeroWorldMapCore", "onPlayNetHandlerCleanup", "(Lnet/minecraft/client/network/NetHandlerPlayClient;)V", false));
            AbstractInsnNode firstInsn = mn.instructions.get(0);
            if (firstInsn instanceof LabelNode) {
               mn.instructions.insert(firstInsn, patchList);
            } else {
               mn.instructions.insertBefore(firstInsn, patchList);
            }

            cleanupTransformed = true;
         }

         if (multiBlockChangeRedirected && chunkDataRedirected && blockChangeRedirected && joinGameTransformed && cleanupTransformed) {
            break;
         }
      }

      classNode.interfaces.add("xaero/map/core/IWorldMapClientPlayNetHandler");
      classNode.fields.add(new FieldNode(2, "xaero_worldmapSession", "Lxaero/map/WorldMapSession;", (String)null, (Object)null));
      this.addGetter(classNode, "xaero_worldmapSession", "Lxaero/map/WorldMapSession;");
      this.addSetter(classNode, "xaero_worldmapSession", "Lxaero/map/WorldMapSession;");
   }

   private void clientPacketRedirectTransform(MethodNode methodNode, MethodInsnNode methodInsnNode, boolean isObfuscated) {
      this.clientPacketRedirectTransformCustom(methodNode, methodInsnNode, isObfuscated, 1);
   }

   private void clientPacketRedirectTransformCustom(MethodNode methodNode, MethodInsnNode methodInsnNode, boolean isObfuscated, int localVariable) {
      InsnList instructions = methodNode.instructions;
      InsnList patchList = new InsnList();
      patchList.add(new VarInsnNode(25, localVariable));
      patchList.add(methodInsnNode);
      int i = 0;

      while(i < instructions.size()) {
         AbstractInsnNode insn;
         label26: {
            insn = instructions.get(i);
            if (insn.getOpcode() == 184) {
               MethodInsnNode methodInsn = (MethodInsnNode)insn;
               if (isObfuscated) {
                  if (methodInsn.owner.equals("fh") && methodInsn.name.equals("a")) {
                     break label26;
                  }
               } else if (methodInsn.owner.equals("net/minecraft/network/PacketThreadUtil") && methodInsn.name.equals("checkThreadAndEnqueue")) {
                  break label26;
               }
            }

            ++i;
            continue;
         }

         instructions.insert(insn, patchList);
         break;
      }

   }
}
