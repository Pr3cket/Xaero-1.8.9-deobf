package xaero.map.core.transformer;

import java.util.Iterator;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

public class AbstractClientPlayerTransformer extends ClassNodeTransformer {
   public byte[] transform(String name, String transformedName, byte[] basicClass) {
      this.className = "net.minecraft.client.entity.AbstractClientPlayer";
      return super.transform(name, transformedName, basicClass);
   }

   protected void transformNode(ClassNode classNode, boolean isObfuscated) {
      String methodName = isObfuscated ? "k" : "getLocationCape";
      String methodDesc = isObfuscated ? "()Ljy;" : "()Lnet/minecraft/util/ResourceLocation;";
      Iterator var5 = classNode.methods.iterator();

      while(var5.hasNext()) {
         MethodNode methodNode = (MethodNode)var5.next();
         if (methodNode.name.equals(methodName) && methodNode.desc.equals(methodDesc)) {
            break;
         }
      }

      System.out.println();
   }
}
