package xaero.map.core;

import xaero.map.WorldMapSession;

public interface IWorldMapClientPlayNetHandler {
   WorldMapSession getXaero_worldmapSession();

   void setXaero_worldmapSession(WorldMapSession var1);
}
