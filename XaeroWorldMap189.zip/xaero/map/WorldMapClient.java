package xaero.map;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import xaero.map.region.texture.BranchTextureRenderer;

public class WorldMapClient {
   private boolean onTickDone;

   public void preInit(FMLPreInitializationEvent event, String modId) {
   }

   public void onTick() {
      if (!this.onTickDone) {
         this.onTickDone = true;
         WorldMap.branchTextureRenderer = new BranchTextureRenderer(Minecraft.func_71410_x().func_147110_a());
      }
   }
}
