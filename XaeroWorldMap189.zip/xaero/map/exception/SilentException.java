package xaero.map.exception;

public class SilentException extends Exception {
   private static final long serialVersionUID = 1L;

   public SilentException(String string) {
      super(string);
   }
}
