package xaero.map.message;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xaero.map.WorldMapSession;
import xaero.map.server.level.LevelMapProperties;

public class LevelMapPropertiesConsumer implements IMessageHandler<LevelMapProperties, IMessage> {
   public IMessage onMessage(final LevelMapProperties t, MessageContext ctx) {
      Minecraft.func_71410_x().func_152344_a(new Runnable() {
         public void run() {
            WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
            worldmapSession.getMapProcessor().onServerLevelId(t.getId());
         }
      });
      return null;
   }
}
