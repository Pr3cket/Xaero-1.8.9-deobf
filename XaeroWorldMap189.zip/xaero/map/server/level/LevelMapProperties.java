package xaero.map.server.level;

import io.netty.buffer.ByteBuf;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public class LevelMapProperties implements IMessage {
   private int id = (new Random()).nextInt();

   public void write(PrintWriter writer) {
      writer.print("id:" + this.id);
   }

   public void read(BufferedReader reader) throws IOException {
      String line;
      while((line = reader.readLine()) != null) {
         String[] args = line.split(":");
         if (args[0].equals("id")) {
            try {
               this.id = Integer.parseInt(args[1]);
            } catch (NumberFormatException var5) {
            }
         }
      }

   }

   public int getId() {
      return this.id;
   }

   public void fromBytes(ByteBuf buf) {
      this.id = buf.readInt();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeInt(this.id);
   }
}
