package xaero.map.server.events;

import java.nio.file.Path;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.common.DimensionManager;
import xaero.map.WorldMap;
import xaero.map.server.WorldMapServer;
import xaero.map.server.level.LevelMapProperties;

public class ServerEvents {
   private WorldMapServer worldmapServer;

   public ServerEvents(WorldMapServer worldmapServer) {
      this.worldmapServer = worldmapServer;
   }

   public void onPlayerWorldJoin(EntityPlayer player) {
      Path propertiesPath = DimensionManager.getCurrentSaveRootDirectory().toPath().resolve("xaeromap.txt");

      try {
         LevelMapProperties properties = this.worldmapServer.getLevelProperties(propertiesPath);
         WorldMap.network.sendTo(properties, (EntityPlayerMP)player);
      } catch (Throwable var5) {
         var5.printStackTrace();
         ((EntityPlayerMP)player).field_71135_a.func_147360_c("Error loading server world map properties. Please retry.");
      }

   }
}
