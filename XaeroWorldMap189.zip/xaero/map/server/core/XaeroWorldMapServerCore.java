package xaero.map.server.core;

import net.minecraft.entity.player.EntityPlayer;
import xaero.map.server.WorldMapServer;

public class XaeroWorldMapServerCore {
   public static WorldMapServer worldmapServer;

   public static void onServerWorldInfo(EntityPlayer player) {
      if (worldmapServer != null) {
         worldmapServer.getServerEvents().onPlayerWorldJoin(player);
      }
   }
}
