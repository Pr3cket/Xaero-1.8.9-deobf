package xaero.map.graphics;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GLContext;

public class PixelBuffers {
   private static int buffersType;

   public static int glGenBuffers() {
      switch(buffersType) {
      case 0:
         return GL15.glGenBuffers();
      case 1:
         return ARBVertexBufferObject.glGenBuffersARB();
      default:
         return 0;
      }
   }

   public static void glBindBuffer(int target, int buffer) {
      switch(buffersType) {
      case 0:
         GL15.glBindBuffer(target, buffer);
         break;
      case 1:
         ARBVertexBufferObject.glBindBufferARB(target, buffer);
      }

   }

   public static void glBufferData(int target, long size, int usage) {
      switch(buffersType) {
      case 0:
         GL15.glBufferData(target, size, usage);
         break;
      case 1:
         ARBVertexBufferObject.glBufferDataARB(target, size, usage);
      }

   }

   public static ByteBuffer glMapBuffer(int target, int access, long length, ByteBuffer old_buffer) {
      switch(buffersType) {
      case 0:
         return GL15.glMapBuffer(target, access, length, old_buffer);
      case 1:
         return ARBVertexBufferObject.glMapBufferARB(target, access, length, old_buffer);
      default:
         return null;
      }
   }

   public static boolean glUnmapBuffer(int target) {
      switch(buffersType) {
      case 0:
         return GL15.glUnmapBuffer(target);
      case 1:
         return ARBVertexBufferObject.glUnmapBufferARB(target);
      default:
         return false;
      }
   }

   public static void glDeleteBuffers(int buffer) {
      switch(buffersType) {
      case 0:
         GL15.glDeleteBuffers(buffer);
         break;
      case 1:
         ARBVertexBufferObject.glDeleteBuffersARB(buffer);
      }

   }

   public static void glDeleteBuffers(IntBuffer buffers) {
      switch(buffersType) {
      case 0:
         GL15.glDeleteBuffers(buffers);
         break;
      case 1:
         ARBVertexBufferObject.glDeleteBuffersARB(buffers);
      }

   }

   static {
      if (GLContext.getCapabilities().OpenGL15) {
         buffersType = 0;
      } else {
         if (!GLContext.getCapabilities().GL_ARB_vertex_buffer_object) {
            throw new RuntimeException("Xaero's World Map requires Buffer Object support!");
         }

         buffersType = 1;
      }

      if (!GLContext.getCapabilities().OpenGL21 && !GLContext.getCapabilities().GL_EXT_pixel_buffer_object && !GLContext.getCapabilities().GL_ARB_pixel_buffer_object) {
         throw new RuntimeException("Xaero's World Map requires Pixel Buffer Object support!");
      }
   }
}
