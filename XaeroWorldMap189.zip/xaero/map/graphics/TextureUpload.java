package xaero.map.graphics;

import java.nio.ByteBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.Util;
import xaero.map.exception.OpenGLException;
import xaero.map.pool.PoolUnit;
import xaero.map.region.texture.BranchTextureRenderer;

public abstract class TextureUpload implements PoolUnit {
   protected int glTexture;
   private int glUnpackPbo;
   private int target;
   private int level;
   private int internalFormat;
   private int width;
   private int height;
   private int border;
   private long pixels_buffer_offset;
   private int uploadType;

   public void create(Object... args) {
      this.glTexture = (Integer)args[0];
      this.glUnpackPbo = (Integer)args[1];
      this.target = (Integer)args[2];
      this.level = (Integer)args[3];
      this.internalFormat = (Integer)args[4];
      this.width = (Integer)args[5];
      this.height = (Integer)args[6];
      this.border = (Integer)args[7];
      this.pixels_buffer_offset = (Long)args[8];
   }

   public void run() {
      GlStateManager.func_179144_i(this.glTexture);
      PixelBuffers.glBindBuffer(35052, this.glUnpackPbo);
      Util.checkGLError();
      this.upload();
      Util.checkGLError();
      PixelBuffers.glBindBuffer(35052, 0);
      GlStateManager.func_179144_i(0);
      Util.checkGLError();
   }

   abstract void upload();

   public int getUploadType() {
      return this.uploadType;
   }

   public static class BranchDownload extends TextureUpload {
      private int glPackPbo;
      private int pboOffset;

      public BranchDownload(int uploadType) {
         super.uploadType = uploadType;
      }

      public BranchDownload(Object... args) {
         this(5);
         this.create(args);
      }

      void upload() throws OpenGLException {
         PixelBuffers.glBindBuffer(35051, this.glPackPbo);
         int target = super.target;
         GL11.glGetTexImage(target, 0, 32993, 32821, (long)this.pboOffset);
         PixelBuffers.glBindBuffer(35051, 0);
         OpenGLException.checkGLError();
      }

      public void create(Object... args) {
         super.create(args);
         this.glPackPbo = (Integer)args[9];
         this.pboOffset = (Integer)args[10];
      }
   }

   public static class BranchUpdate extends TextureUpload {
      private int format;
      private int type;
      private boolean allocate;
      private Integer srcTextureTopLeft;
      private Integer srcTextureTopRight;
      private Integer srcTextureBottomLeft;
      private Integer srcTextureBottomRight;
      private BranchTextureRenderer renderer;
      private int glPackPbo;
      private int pboOffset;
      private ScaledResolution scaledRes;

      public BranchUpdate(int uploadType) {
         super.uploadType = uploadType;
      }

      public BranchUpdate(Object... args) {
         this((Boolean)args[11] ? 4 : 3);
         this.create(args);
      }

      void upload() throws OpenGLException {
         if (this.allocate) {
            GL11.glTexImage2D(super.target, super.level, super.internalFormat, super.width, super.height, 0, this.format, this.type, (ByteBuffer)null);
            OpenGLException.checkGLError();
         }

         this.renderer.render(this.glTexture, this.srcTextureTopLeft, this.srcTextureTopRight, this.srcTextureBottomLeft, this.srcTextureBottomRight, Minecraft.func_71410_x().func_147110_a(), this.allocate, this.scaledRes);
         GlStateManager.func_179144_i(this.glTexture);
         PixelBuffers.glBindBuffer(35051, this.glPackPbo);
         int target = super.target;
         GL11.glGetTexImage(target, 0, 32993, 32821, (long)this.pboOffset);
         PixelBuffers.glBindBuffer(35051, 0);
         OpenGLException.checkGLError();
      }

      public void create(Object... args) {
         super.create(args);
         this.format = (Integer)args[9];
         this.type = (Integer)args[10];
         this.allocate = (Boolean)args[11];
         this.srcTextureTopLeft = (Integer)args[12];
         this.srcTextureTopRight = (Integer)args[13];
         this.srcTextureBottomLeft = (Integer)args[14];
         this.srcTextureBottomRight = (Integer)args[15];
         this.renderer = (BranchTextureRenderer)args[16];
         this.glPackPbo = (Integer)args[17];
         this.pboOffset = (Integer)args[18];
         this.scaledRes = (ScaledResolution)args[19];
      }
   }

   public static class Compressed extends TextureUpload {
      private int dataSize;

      public Compressed(Object... args) {
         this.create(args);
         super.uploadType = 2;
      }

      void upload() {
         GL13.glCompressedTexImage2D(super.target, super.level, super.internalFormat, super.width, super.height, super.border, this.dataSize, super.pixels_buffer_offset);
      }

      public void create(Object... args) {
         super.create(args);
         this.dataSize = (Integer)args[9];
      }
   }

   public static class NormalWithDownload extends TextureUpload.Normal {
      private int glPackPbo;

      public NormalWithDownload(Object... args) {
         super(1);
         this.create(args);
      }

      void upload() {
         super.upload();
         PixelBuffers.glBindBuffer(35051, this.glPackPbo);
         int target = super.target;
         int isCompressed = GL11.glGetTexLevelParameteri(target, 0, 34465);
         if (isCompressed == 1) {
            GL13.glGetCompressedTexImage(target, 0, 0L);
         } else {
            GL11.glGetTexImage(target, 0, 32993, 32821, 0L);
         }

         PixelBuffers.glBindBuffer(35051, 0);
      }

      public void create(Object... args) {
         super.create(args);
         this.glPackPbo = (Integer)args[11];
      }
   }

   public static class Normal extends TextureUpload {
      private int format;
      private int type;

      public Normal(int uploadType) {
         super.uploadType = uploadType;
      }

      public Normal(Object... args) {
         this(0);
         this.create(args);
      }

      void upload() {
         GL11.glHint(34031, 4354);
         GL11.glTexImage2D(super.target, super.level, super.internalFormat, super.width, super.height, super.border, this.format, this.type, super.pixels_buffer_offset);
      }

      public void create(Object... args) {
         super.create(args);
         this.format = (Integer)args[9];
         this.type = (Integer)args[10];
      }
   }
}
