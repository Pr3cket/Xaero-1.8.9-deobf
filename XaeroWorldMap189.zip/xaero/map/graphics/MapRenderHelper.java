package xaero.map.graphics;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

public class MapRenderHelper {
   public static void renderTexturedModalRect(float x, float y, float width, float height, int textureX, int textureY, float textureW, float textureH, float fullTextureWidth, float fullTextureHeight) {
      Tessellator tessellator = Tessellator.func_178181_a();
      WorldRenderer worldrenderer = tessellator.func_178180_c();
      worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      float normalizedTextureX = (float)textureX / fullTextureWidth;
      float normalizedTextureY = (float)textureY / fullTextureHeight;
      float normalizedTextureX2 = ((float)textureX + textureW) / fullTextureWidth;
      float normalizedTextureY2 = ((float)textureY + textureH) / fullTextureHeight;
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + height), 0.0D).func_181673_a((double)normalizedTextureX, (double)normalizedTextureY2).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + height), 0.0D).func_181673_a((double)normalizedTextureX2, (double)normalizedTextureY2).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + 0.0F), 0.0D).func_181673_a((double)normalizedTextureX2, (double)normalizedTextureY).func_181675_d();
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + 0.0F), 0.0D).func_181673_a((double)normalizedTextureX, (double)normalizedTextureY).func_181675_d();
      tessellator.func_78381_a();
   }
}
