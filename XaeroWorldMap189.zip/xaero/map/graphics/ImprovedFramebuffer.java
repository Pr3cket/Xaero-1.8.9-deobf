package xaero.map.graphics;

import java.nio.IntBuffer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.ARBFramebufferObject;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GLContext;

public class ImprovedFramebuffer extends Framebuffer {
   private int type;
   private static final int GL_FB_INCOMPLETE_ATTACHMENT = 36054;
   private static final int GL_FB_INCOMPLETE_MISS_ATTACH = 36055;
   private static final int GL_FB_INCOMPLETE_DRAW_BUFFER = 36059;
   private static final int GL_FB_INCOMPLETE_READ_BUFFER = 36060;

   public ImprovedFramebuffer(int width, int height, boolean useDepthIn) {
      super(width, height, useDepthIn);
   }

   public void func_147613_a(int width, int height) {
      GlStateManager.func_179126_j();
      if (this.field_147616_f >= 0) {
         this.func_147608_a();
      }

      this.func_147605_b(width, height);
      this.func_147611_b();
      bindFramebuffer(this.type, 36160, 0);
   }

   public void func_147605_b(int width, int height) {
      this.field_147621_c = width;
      this.field_147618_d = height;
      this.field_147622_a = width;
      this.field_147620_b = height;
      this.field_147616_f = this.genFrameBuffers();
      if (this.field_147616_f == -1) {
         this.func_147614_f();
      } else {
         this.field_147617_g = TextureUtil.func_110996_a();
         if (this.field_147617_g == -1) {
            this.func_147614_f();
         } else {
            if (this.field_147619_e) {
               this.field_147624_h = this.genRenderbuffers();
               if (this.field_147624_h == -1) {
                  this.func_147614_f();
                  return;
               }
            }

            this.func_147607_a(9728);
            GlStateManager.func_179144_i(this.field_147617_g);
            GL11.glTexImage2D(3553, 0, 32856, this.field_147622_a, this.field_147620_b, 0, 6408, 5121, (IntBuffer)null);
            bindFramebuffer(this.type, 36160, this.field_147616_f);
            framebufferTexture2D(this.type, 36160, 36064, 3553, this.field_147617_g, 0);
            if (this.field_147619_e) {
               bindRenderbuffer(this.type, 36161, this.field_147624_h);
               if (!this.isStencilEnabled()) {
                  renderbufferStorage(this.type, 36161, 33190, this.field_147622_a, this.field_147620_b);
                  framebufferRenderbuffer(this.type, 36160, 36096, 36161, this.field_147624_h);
               } else {
                  renderbufferStorage(this.type, 36161, 35056, this.field_147622_a, this.field_147620_b);
                  framebufferRenderbuffer(this.type, 36160, 36096, 36161, this.field_147624_h);
                  framebufferRenderbuffer(this.type, 36160, 36128, 36161, this.field_147624_h);
               }
            }

            this.func_147614_f();
            this.func_147606_d();
         }
      }
   }

   private int genFrameBuffers() {
      int fbo = -1;
      this.type = -1;
      if (GLContext.getCapabilities().OpenGL30) {
         fbo = GL30.glGenFramebuffers();
         this.type = 0;
      } else if (GLContext.getCapabilities().GL_ARB_framebuffer_object) {
         fbo = ARBFramebufferObject.glGenFramebuffers();
         this.type = 1;
      } else if (GLContext.getCapabilities().GL_EXT_framebuffer_object) {
         fbo = EXTFramebufferObject.glGenFramebuffersEXT();
         this.type = 2;
      }

      return fbo;
   }

   public int genRenderbuffers() {
      int rbo = -1;
      switch(this.type) {
      case 0:
         rbo = GL30.glGenRenderbuffers();
         break;
      case 1:
         rbo = ARBFramebufferObject.glGenRenderbuffers();
         break;
      case 2:
         rbo = EXTFramebufferObject.glGenRenderbuffersEXT();
      }

      return rbo;
   }

   public void func_147608_a() {
      this.func_147606_d();
      this.func_147609_e();
      if (this.field_147624_h > -1) {
         this.deleteRenderbuffers(this.field_147624_h);
         this.field_147624_h = -1;
      }

      if (this.field_147617_g > -1) {
         TextureUtil.func_147942_a(this.field_147617_g);
         this.field_147617_g = -1;
      }

      if (this.field_147616_f > -1) {
         bindFramebuffer(this.type, 36160, 0);
         this.deleteFramebuffers(this.field_147616_f);
         this.field_147616_f = -1;
      }

   }

   private void deleteFramebuffers(int framebufferIn) {
      switch(this.type) {
      case 0:
         GL30.glDeleteFramebuffers(framebufferIn);
         break;
      case 1:
         ARBFramebufferObject.glDeleteFramebuffers(framebufferIn);
         break;
      case 2:
         EXTFramebufferObject.glDeleteFramebuffersEXT(framebufferIn);
      }

   }

   private void deleteRenderbuffers(int renderbuffer) {
      switch(this.type) {
      case 0:
         GL30.glDeleteRenderbuffers(renderbuffer);
         break;
      case 1:
         ARBFramebufferObject.glDeleteRenderbuffers(renderbuffer);
         break;
      case 2:
         EXTFramebufferObject.glDeleteRenderbuffersEXT(renderbuffer);
      }

   }

   public void func_147611_b() {
      int i = this.checkFramebufferStatus(36160);
      if (i != 36053) {
         if (i == 36054) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT");
         } else if (i == 36055) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT");
         } else if (i == 36059) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER");
         } else if (i == 36060) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER");
         } else {
            throw new RuntimeException("glCheckFramebufferStatus returned unknown status:" + i);
         }
      }
   }

   private int checkFramebufferStatus(int target) {
      switch(this.type) {
      case 0:
         return GL30.glCheckFramebufferStatus(target);
      case 1:
         return ARBFramebufferObject.glCheckFramebufferStatus(target);
      case 2:
         return EXTFramebufferObject.glCheckFramebufferStatusEXT(target);
      default:
         return -1;
      }
   }

   public static void bindFramebuffer(int type, int target, int framebufferIn) {
      if (framebufferIn == -1) {
         framebufferIn = 0;
      }

      switch(type) {
      case 0:
         GL30.glBindFramebuffer(target, framebufferIn);
         break;
      case 1:
         ARBFramebufferObject.glBindFramebuffer(target, framebufferIn);
         break;
      case 2:
         EXTFramebufferObject.glBindFramebufferEXT(target, framebufferIn);
      }

   }

   public static void framebufferTexture2D(int type, int target, int attachment, int textarget, int texture, int level) {
      switch(type) {
      case 0:
         GL30.glFramebufferTexture2D(target, attachment, textarget, texture, level);
         break;
      case 1:
         ARBFramebufferObject.glFramebufferTexture2D(target, attachment, textarget, texture, level);
         break;
      case 2:
         EXTFramebufferObject.glFramebufferTexture2DEXT(target, attachment, textarget, texture, level);
      }

   }

   public static void bindRenderbuffer(int type, int target, int renderbuffer) {
      switch(type) {
      case 0:
         GL30.glBindRenderbuffer(target, renderbuffer);
         break;
      case 1:
         ARBFramebufferObject.glBindRenderbuffer(target, renderbuffer);
         break;
      case 2:
         EXTFramebufferObject.glBindRenderbufferEXT(target, renderbuffer);
      }

   }

   public static void renderbufferStorage(int type, int target, int internalFormat, int width, int height) {
      switch(type) {
      case 0:
         GL30.glRenderbufferStorage(target, internalFormat, width, height);
         break;
      case 1:
         ARBFramebufferObject.glRenderbufferStorage(target, internalFormat, width, height);
         break;
      case 2:
         EXTFramebufferObject.glRenderbufferStorageEXT(target, internalFormat, width, height);
      }

   }

   public static void framebufferRenderbuffer(int type, int target, int attachment, int renderBufferTarget, int renderBuffer) {
      switch(type) {
      case 0:
         GL30.glFramebufferRenderbuffer(target, attachment, renderBufferTarget, renderBuffer);
         break;
      case 1:
         ARBFramebufferObject.glFramebufferRenderbuffer(target, attachment, renderBufferTarget, renderBuffer);
         break;
      case 2:
         EXTFramebufferObject.glFramebufferRenderbufferEXT(target, attachment, renderBufferTarget, renderBuffer);
      }

   }

   public void func_147610_a(boolean p_147610_1_) {
      bindFramebuffer(this.type, 36160, this.field_147616_f);
      if (p_147610_1_) {
         GlStateManager.func_179083_b(0, 0, this.field_147621_c, this.field_147618_d);
      }

   }

   public void func_147609_e() {
      bindFramebuffer(this.type, 36160, 0);
   }

   public void func_147612_c() {
      GlStateManager.func_179144_i(this.field_147617_g);
   }

   public void func_147606_d() {
      GlStateManager.func_179144_i(0);
   }

   public void func_147607_a(int framebufferFilterIn) {
      this.field_147623_j = framebufferFilterIn;
      GlStateManager.func_179144_i(this.field_147617_g);
      GL11.glTexParameterf(3553, 10241, (float)framebufferFilterIn);
      GL11.glTexParameterf(3553, 10240, (float)framebufferFilterIn);
      GL11.glTexParameterf(3553, 10242, 10496.0F);
      GL11.glTexParameterf(3553, 10243, 10496.0F);
      GlStateManager.func_179144_i(0);
   }

   public int getFramebufferTexture() {
      return this.field_147617_g;
   }

   public void setFramebufferTexture(int textureId) {
      this.field_147617_g = textureId;
      framebufferTexture2D(this.type, 36160, 36064, 3553, this.field_147617_g, 0);
   }

   public void generateMipmaps() {
      switch(this.type) {
      case 0:
         GL30.glGenerateMipmap(3553);
         break;
      case 1:
         ARBFramebufferObject.glGenerateMipmap(3553);
         break;
      case 2:
         EXTFramebufferObject.glGenerateMipmapEXT(3553);
      }

   }

   public int getType() {
      return this.type;
   }
}
