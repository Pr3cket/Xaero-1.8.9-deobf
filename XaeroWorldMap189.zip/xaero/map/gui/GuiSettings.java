package xaero.map.gui;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.resources.I18n;
import xaero.map.controls.ControlsRegister;
import xaero.map.misc.Misc;
import xaero.map.settings.ModOptions;
import xaero.map.settings.ModSettings;

public class GuiSettings extends ScreenBase {
   protected String screenTitle;
   protected ModSettings guiModSettings;
   protected ModOptions[] options;
   private boolean buttonClicked;
   protected boolean renderedOnce;

   public GuiSettings(GuiScreen par1GuiScreen, GuiScreen escapeScreen, ModSettings par2ModSettings) {
      super(par1GuiScreen, escapeScreen);
      this.guiModSettings = par2ModSettings;
   }

   public void func_73866_w_() {
      this.renderedOnce = false;
      this.field_146292_n.clear();
      this.field_146292_n.add(new GuiButton(200, this.field_146294_l / 2 - 100, this.field_146295_m / 6 + 168, I18n.func_135052_a("gui.xaero_back", new Object[0])));
      int var8 = 0;
      if (this.options != null) {
         int var10 = this.options.length;

         for(int var11 = 0; var11 < var10; ++var11) {
            ModOptions option = this.options[var11];
            if (!option.getEnumFloat()) {
               this.field_146292_n.add(new ModOptionButton(option, option.returnEnumOrdinal(), this.field_146294_l / 2 - 205 + var8 % 2 * 210, this.field_146295_m / 7 + 24 * (var8 >> 1), 200, 20, this.guiModSettings.getKeyBinding(option)));
            } else {
               this.field_146292_n.add(new ModOptionSlider(option, option.returnEnumOrdinal(), this.field_146294_l / 2 - 205 + var8 % 2 * 210, this.field_146295_m / 7 + 24 * (var8 >> 1), 200, 20));
            }

            ++var8;
         }

      }
   }

   protected void func_146284_a(GuiButton par1GuiButton) throws IOException {
      super.func_146284_a(par1GuiButton);
      this.buttonClicked = true;
      if (par1GuiButton.field_146124_l) {
         int var2 = this.field_146297_k.field_71474_y.field_74335_Z;
         if (par1GuiButton.field_146127_k < 100 && par1GuiButton instanceof ModOptionButton) {
            try {
               this.guiModSettings.setOptionValue(((ModOptionButton)par1GuiButton).getModOption(), 1);
            } catch (IOException var6) {
               var6.printStackTrace();
            }

            par1GuiButton.field_146126_j = this.guiModSettings.getKeyBinding(ModOptions.getModOptions(par1GuiButton.field_146127_k));
         }

         if (par1GuiButton.field_146127_k == 200) {
            this.goBack();
         }

         if (this.field_146297_k.field_71474_y.field_74335_Z != var2) {
            ScaledResolution var3 = new ScaledResolution(this.field_146297_k);
            int var4 = var3.func_78326_a();
            int var5 = var3.func_78328_b();
            this.func_146280_a(this.field_146297_k, var4, var5);
         }
      }

   }

   public void func_73863_a(int par1, int par2, float par3) {
      this.func_146276_q_();
      this.func_73732_a(this.field_146289_q, this.screenTitle, this.field_146294_l / 2, 5, 16777215);
      super.func_73863_a(par1, par2, par3);

      for(int k = 0; k < this.field_146292_n.size(); ++k) {
         GuiButton b = (GuiButton)this.field_146292_n.get(k);
         if (b instanceof ICanTooltip) {
            ICanTooltip optionWidget = (ICanTooltip)b;
            if (par1 >= b.field_146128_h && par2 >= b.field_146129_i && par1 < b.field_146128_h + b.field_146120_f && par2 < b.field_146129_i + b.field_146121_g && optionWidget.getTooltip() != null) {
               optionWidget.getTooltip().drawBox(par1, par2, this.field_146294_l, this.field_146295_m);
            }
         }
      }

      this.renderedOnce = true;
   }

   public void func_73869_a(char par1, int par2) throws IOException {
      super.func_73869_a(par1, par2);
      if (Misc.inputMatchesKeyBinding(false, par2, ControlsRegister.keyOpenSettings)) {
         this.onClose();
      }

   }

   public void func_73864_a(int p_231044_1_, int p_231044_3_, int p_231044_5_) throws IOException {
      this.buttonClicked = false;
      super.func_73864_a(p_231044_1_, p_231044_3_, p_231044_5_);
      if (!this.buttonClicked && Misc.inputMatchesKeyBinding(true, p_231044_5_, ControlsRegister.keyOpenSettings)) {
         this.onClose();
      }

   }

   protected void onExit(GuiScreen screen) {
      try {
         this.guiModSettings.saveSettings();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      super.onExit(screen);
   }
}
