package xaero.map.gui;

import xaero.map.settings.ModOptions;

public class ModOptionSlider extends MyOptionSlider implements ModOptionWidget {
   private final ModOptions modOption;

   public ModOptionSlider(ModOptions modOption, int p_i45017_1_, int p_i45017_2_, int p_i45017_3_, int w, int h) {
      super(p_i45017_1_, p_i45017_2_, p_i45017_3_, w, h, modOption);
      this.modOption = modOption;
   }

   public ModOptions getModOption() {
      return this.modOption;
   }

   public CursorBox getTooltip() {
      ModOptions modOptions = this.getModOption();
      return modOptions == null ? null : modOptions.getTooltip();
   }
}
