package xaero.map.gui;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiButton;
import xaero.map.WorldMap;

public class GuiMapSwitchingButton extends GuiTexturedButton {
   public GuiMapSwitchingButton(boolean menuActive, int x, int y) {
      super(x, y, 20, 20, menuActive ? 97 : 81, 0, 16, 16, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton t) {
         }
      }, new CursorBox("gui.xaero_box_map_switching"));
   }
}
