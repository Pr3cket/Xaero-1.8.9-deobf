package xaero.map.gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.vertex.VertexFormat;
import net.minecraft.client.renderer.vertex.VertexFormatElement;
import net.minecraft.client.renderer.vertex.VertexFormatElement.EnumType;
import net.minecraft.client.renderer.vertex.VertexFormatElement.EnumUsage;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.entity.Entity;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.animation.Animation;
import xaero.map.animation.SinAnimation;
import xaero.map.animation.SlowingAnimation;
import xaero.map.controls.ControlsHandler;
import xaero.map.controls.ControlsRegister;
import xaero.map.effects.Effects;
import xaero.map.graphics.ImprovedFramebuffer;
import xaero.map.misc.Misc;
import xaero.map.mods.SupportMods;
import xaero.map.mods.gui.Waypoint;
import xaero.map.mods.gui.WaypointMenuElement;
import xaero.map.mods.gui.WaypointMenuRenderer;
import xaero.map.region.BranchLeveledRegion;
import xaero.map.region.LeveledRegion;
import xaero.map.region.LeveledRegionManager;
import xaero.map.region.MapBlock;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTile;
import xaero.map.region.MapTileChunk;
import xaero.map.region.Overlay;
import xaero.map.region.texture.RegionTexture;

public class GuiMap extends ScreenBase implements IRightClickableElement {
   public static final VertexFormat POSITION_TEX_TEX_TEX = new VertexFormat();
   public static final VertexFormatElement TEX_2F_1;
   public static final VertexFormatElement TEX_2F_2;
   public static final VertexFormatElement TEX_2F_3;
   private static final double ZOOM_STEP = 1.2D;
   private static final int white = -1;
   private static final int whiteTrans = 687865855;
   private static final int redTrans = 687800320;
   private static final int yellowTrans = 687865600;
   private static final int purpleTrans = 687800575;
   private static final int greenTrans = 671153920;
   private static final int black = -16777216;
   private static int lastAmountOfRegionsViewed;
   private long loadingAnimationStart;
   private Entity player;
   private int screenScale = 0;
   private int mouseDownPosX = -1;
   private int mouseDownPosY = -1;
   private double mouseDownCameraX = -1.0D;
   private double mouseDownCameraZ = -1.0D;
   private int mouseCheckPosX = -1;
   private int mouseCheckPosY = -1;
   private long mouseCheckTimeNano = -1L;
   private int prevMouseCheckPosX = -1;
   private int prevMouseCheckPosY = -1;
   private long prevMouseCheckTimeNano = -1L;
   private double cameraX = 0.0D;
   private double cameraZ = 0.0D;
   private boolean shouldResetCameraPos;
   private int[] cameraDestination = null;
   private SlowingAnimation cameraDestinationAnimX = null;
   private SlowingAnimation cameraDestinationAnimZ = null;
   private double scale;
   private double userScale;
   private static double destScale;
   private boolean pauseZoomKeys;
   private int lastZoomMethod;
   private Waypoint viewed = null;
   private boolean viewedInList;
   private Waypoint viewedOnMousePress = null;
   private boolean overWaypointsMenu;
   private Animation zoomAnim;
   public boolean waypointMenu = false;
   public int waypointMenuOffset = 0;
   private Pattern waypointMenuSearchPattern = null;
   private Pattern waypointMenuSearchStartPattern = null;
   private static ImprovedFramebuffer primaryScaleFBO;
   private float[] colourBuffer = new float[4];
   private ArrayList<MapRegion> regionBuffer = new ArrayList();
   private ArrayList<BranchLeveledRegion> branchRegionBuffer = new ArrayList();
   private boolean prevWaitingForBranchCache = true;
   private Integer lastViewedDimensionId;
   private String lastViewedMultiworldId;
   private int mouseBlockPosX;
   private int mouseBlockPosY;
   private int mouseBlockPosZ;
   private long lastStartTime;
   private List<GuiDropDown> dropdowns;
   private List<GuiDropDown> dropdownsToRemove;
   private GuiMapSwitching dimensionSettings;
   private MapMouseButtonPress leftMouseButton;
   private MapMouseButtonPress rightMouseButton;
   private boolean buttonClicked;
   private MapProcessor mapProcessor;
   private ScaledResolution scaledresolution;
   private boolean[] waitingForBranchCache = new boolean[1];
   private GuiButton settingsButton;
   private GuiButton exportButton;
   private GuiButton waypointsButton;
   private GuiButton zoomInButton;
   private GuiButton zoomOutButton;
   private GuiButton keybindingsButton;
   private GuiButton buttonPressed;
   private GuiTextField waypointFilterField;
   private GuiRightClickMenu rightClickMenu;
   private int rightClickX;
   private int rightClickY;
   private int rightClickZ;
   private GuiTextField focusedField;

   public GuiMap(GuiScreen parent, GuiScreen escape, MapProcessor mapProcessor, Entity player) {
      super(parent, escape);
      this.player = player;
      this.shouldResetCameraPos = true;
      this.leftMouseButton = new MapMouseButtonPress();
      this.rightMouseButton = new MapMouseButtonPress();
      this.dimensionSettings = new GuiMapSwitching(mapProcessor);
      this.dropdowns = new ArrayList();
      this.userScale = destScale * (double)(WorldMap.settings.openMapAnimation ? 1.5F : 1.0F);
      this.zoomAnim = new SlowingAnimation(this.userScale, destScale, 0.88D, destScale * 0.001D);
      this.mapProcessor = mapProcessor;
      if (SupportMods.minimap()) {
         SupportMods.xaeroMinimap.onMapConstruct();
      }

      this.dropdownsToRemove = new ArrayList();
   }

   private double getScaleMultiplier(int screenShortSide) {
      return screenShortSide <= 1080 ? 1.0D : (double)screenShortSide / 1080.0D;
   }

   public void addGuiButton(GuiButton b) {
      this.field_146292_n.add(b);
   }

   public void func_73866_w_() {
      super.func_73866_w_();
      boolean waypointsEnabled = SupportMods.minimap() && WorldMap.settings.waypoints;
      this.waypointMenu = this.waypointMenu && waypointsEnabled;
      this.dropdowns.clear();
      this.dimensionSettings.init(this, this.dropdowns, this.field_146297_k, this.field_146294_l, this.field_146295_m);
      this.loadingAnimationStart = System.currentTimeMillis();
      this.scaledresolution = new ScaledResolution(Minecraft.func_71410_x());
      this.screenScale = this.scaledresolution.func_78325_e();
      this.pauseZoomKeys = false;
      this.field_146292_n.add(this.settingsButton = new GuiTexturedButton(0, 0, 30, 30, 113, 0, 20, 20, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton b) {
            GuiMap.this.onSettingsButton(b);
         }
      }, new CursorBox(I18n.func_135052_a("gui.xaero_box_open_settings", new Object[]{Misc.getKeyName(ControlsRegister.keyOpenSettings)}))));
      String waypointsTooltip;
      if (waypointsEnabled) {
         waypointsTooltip = this.waypointMenu ? "gui.xaero_box_close_waypoints" : "gui.xaero_box_open_waypoints";
      } else {
         waypointsTooltip = !SupportMods.minimap() ? "gui.xaero_box_waypoints_minimap_required" : "gui.xaero_box_waypoints_disabled";
      }

      this.field_146292_n.add(this.waypointsButton = new GuiTexturedButton(this.field_146294_l - 20, this.field_146295_m - 20, 20, 20, 213, 0, 16, 16, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton b) {
            GuiMap.this.onWaypointsButton(b);
         }
      }, new CursorBox(waypointsTooltip)));
      this.waypointsButton.field_146124_l = waypointsEnabled;
      this.field_146292_n.add(this.exportButton = new GuiTexturedButton(this.field_146294_l - 20, this.field_146295_m - 40, 20, 20, 133, 0, 16, 16, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton b) {
            GuiMap.this.onExportButton(b);
         }
      }, new CursorBox("gui.xaero_box_export")));
      this.field_146292_n.add(this.keybindingsButton = new GuiTexturedButton(this.field_146294_l - 20, this.field_146295_m - 60, 20, 20, 197, 0, 16, 16, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton b) {
            GuiMap.this.onKeybindingsButton(b);
         }
      }, new CursorBox(I18n.func_135052_a("gui.xaero_box_controls", new Object[]{SupportMods.minimap() ? SupportMods.xaeroMinimap.getControlsTooltip() : "", Misc.getKeyName(ControlsRegister.keyOpenSettings), Misc.getKeyName(ControlsRegister.keyZoomIn), Misc.getKeyName(ControlsRegister.keyZoomOut)}))));
      this.zoomInButton = new GuiTexturedButton(this.field_146294_l - 20, this.field_146295_m / 2 - 30, 20, 20, 165, 0, 16, 16, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton b) {
            GuiMap.this.onZoomInButton(b);
         }
      }, new CursorBox("gui.xaero_box_zoom_in"));
      this.zoomOutButton = new GuiTexturedButton(this.field_146294_l - 20, this.field_146295_m / 2 + 10, 20, 20, 181, 0, 16, 16, WorldMap.guiTextures, new Consumer<GuiButton>() {
         public void accept(GuiButton b) {
            GuiMap.this.onZoomOutButton(b);
         }
      }, new CursorBox("gui.xaero_box_zoom_out"));
      if (WorldMap.settings.zoomButtons) {
         this.field_146292_n.add(this.zoomInButton);
         this.field_146292_n.add(this.zoomOutButton);
      }

      if (SupportMods.minimap()) {
         SupportMods.xaeroMinimap.requestWaypointsRefresh();
         SupportMods.xaeroMinimap.onMapInit(this, this.dropdowns, this.field_146297_k, this.field_146294_l, this.field_146295_m);
      }

      if (this.waypointMenu) {
         String waypointSearchText = this.waypointFilterField == null ? "" : this.waypointFilterField.func_146179_b();
         this.waypointFilterField = new GuiTextField(-1, this.field_146289_q, this.field_146294_l - 172, this.field_146295_m - 42, 150, 20);
         this.waypointFilterField.func_146180_a(waypointSearchText);
      }

      Keyboard.enableRepeatEvents(true);
   }

   private void onSettingsButton(GuiButton b) {
      this.field_146297_k.func_147108_a(new GuiWorldMapSettings(this, this));
   }

   private void onKeybindingsButton(GuiButton b) {
      this.field_146297_k.func_147108_a(new GuiControls(this, this.field_146297_k.field_71474_y));
   }

   private void onExportButton(GuiButton b) {
      this.field_146297_k.func_147108_a(new ConfirmScreenBase(this, this, true, new GuiYesNoCallback() {
         public void func_73878_a(boolean result, int id) {
            if (result) {
               GuiButton b;
               if (GuiMap.this.mapProcessor.getMapSaveLoad().exportPNG(GuiMap.this) && GuiMap.this.field_146297_k.field_71462_r instanceof ConfirmScreenBase) {
                  for(Iterator var3 = ((ConfirmScreenBase)GuiMap.this.field_146297_k.field_71462_r).getButtonList().iterator(); var3.hasNext(); b.field_146124_l = false) {
                     b = (GuiButton)var3.next();
                  }
               }
            } else {
               GuiMap.this.field_146297_k.func_147108_a(GuiMap.this);
            }

         }
      }, I18n.func_135052_a("gui.xaero_export_confirm_1", new Object[0]), I18n.func_135052_a("gui.xaero_export_confirm_2", new Object[0]), -1));
   }

   private void onWaypointsButton(GuiButton b) {
      this.waypointMenu = !this.waypointMenu;
      if (!this.waypointMenu) {
         this.waypointMenuOffset = 0;
         this.waypointMenuSearchPattern = null;
         this.waypointMenuSearchStartPattern = null;
         SupportMods.xaeroMinimap.updateFilteredList(this.waypointMenuSearchPattern, this.waypointMenuSearchStartPattern);
         this.setSearch("");
         this.unfocusAll();
         this.waypointFilterField = null;
      }

      this.func_146280_a(this.field_146297_k, this.field_146294_l, this.field_146295_m);
   }

   private void onZoomInButton(GuiButton b) {
      this.buttonPressed = b;
   }

   private void onZoomOutButton(GuiButton b) {
      this.buttonPressed = b;
   }

   public void func_73864_a(int par1, int par2, int par3) throws IOException {
      Iterator var4 = this.dropdowns.iterator();

      GuiDropDown d;
      while(var4.hasNext()) {
         d = (GuiDropDown)var4.next();
         if (!d.isClosed() && d.onDropDown(par1, par2, this.field_146295_m)) {
            d.mouseClicked(par1, par2, par3, this.field_146295_m);
            this.unfocusAll();
            return;
         }

         d.setClosed(true);
      }

      var4 = this.dropdowns.iterator();

      while(var4.hasNext()) {
         d = (GuiDropDown)var4.next();
         if (d.onDropDown(par1, par2, this.field_146295_m)) {
            d.mouseClicked(par1, par2, par3, this.field_146295_m);
            this.unfocusAll();
            return;
         }

         d.setClosed(true);
      }

      this.buttonClicked = false;
      super.func_73864_a(par1, par2, par3);
      if (!this.buttonClicked && this.waypointMenu) {
         this.waypointFilterField.func_146192_a(par1, par2, par3);
         this.buttonClicked = this.waypointFilterField.func_146206_l();
      }

      if (!this.buttonClicked) {
         if (par3 == 0) {
            this.leftMouseButton.isDown = this.leftMouseButton.clicked = true;
            this.leftMouseButton.pressedAtX = (int)Misc.getMouseX(this.field_146297_k);
            this.leftMouseButton.pressedAtY = (int)Misc.getMouseY(this.field_146297_k);
         } else if (par3 == 1) {
            this.rightMouseButton.isDown = this.rightMouseButton.clicked = true;
            this.rightMouseButton.pressedAtX = (int)Misc.getMouseX(this.field_146297_k);
            this.rightMouseButton.pressedAtY = (int)Misc.getMouseY(this.field_146297_k);
            this.viewedOnMousePress = this.viewed;
            this.rightClickX = this.mouseBlockPosX;
            this.rightClickY = this.mouseBlockPosY;
            this.rightClickZ = this.mouseBlockPosZ;
         } else {
            this.onInputPress(true, par3);
         }
      }

      if (this.waypointMenu && this.waypointFilterField.func_146206_l()) {
         this.setFocused(this.waypointFilterField);
      } else {
         this.setFocused((GuiTextField)null);
      }

   }

   public void func_146286_b(int par1, int par2, int par3) {
      this.buttonPressed = null;
      Iterator var4 = this.dropdowns.iterator();

      while(var4.hasNext()) {
         GuiDropDown d = (GuiDropDown)var4.next();
         d.mouseReleased(par1, par2, par3, this.field_146295_m);
      }

      int mouseX = (int)Misc.getMouseX(this.field_146297_k);
      int mouseY = (int)Misc.getMouseY(this.field_146297_k);
      if (this.leftMouseButton.isDown && par3 == 0) {
         this.leftMouseButton.isDown = false;
         if (Math.abs(this.leftMouseButton.pressedAtX - mouseX) < 5 && Math.abs(this.leftMouseButton.pressedAtY - mouseY) < 5) {
            this.mapClicked(0, this.leftMouseButton.pressedAtX, this.leftMouseButton.pressedAtY);
         }

         this.leftMouseButton.pressedAtX = -1;
         this.leftMouseButton.pressedAtY = -1;
      }

      if (this.rightMouseButton.isDown && par3 == 1) {
         this.rightMouseButton.isDown = false;
         this.mapClicked(1, this.rightMouseButton.pressedAtX, this.rightMouseButton.pressedAtY);
         this.rightMouseButton.pressedAtX = -1;
         this.rightMouseButton.pressedAtY = -1;
      }

      if (this.waypointMenu) {
         SupportMods.xaeroMinimap.onMapMouseRelease((double)par1, (double)par2, par3);
      }

      super.func_146286_b(par1, par2, par3);
      this.onInputRelease(true, par3);
   }

   public void func_146274_d() throws IOException {
      super.func_146274_d();
      int wheel = Mouse.getEventDWheel() / 120;
      if (wheel != 0) {
         if (wheel != 0) {
            ScaledResolution scaledresolution = new ScaledResolution(Minecraft.func_71410_x());
            int mouseXScaled = (int)(Misc.getMouseX(Minecraft.func_71410_x()) / (double)scaledresolution.func_78325_e());
            int mouseYScaled = (int)(Misc.getMouseY(Minecraft.func_71410_x()) / (double)scaledresolution.func_78325_e());
            Iterator var5 = this.dropdowns.iterator();

            while(var5.hasNext()) {
               GuiDropDown d = (GuiDropDown)var5.next();
               if (!d.isClosed() && d.onDropDown(mouseXScaled, mouseYScaled, this.field_146295_m)) {
                  d.mouseScrolled(wheel, mouseXScaled, mouseYScaled, this.field_146295_m);
                  return;
               }
            }
         }

         int direction = wheel > 0 ? 1 : -1;
         if (this.overWaypointsMenu) {
            this.scrollWaypoints(direction);
         } else {
            this.changeZoom((double)wheel, 0);
         }
      }

   }

   private void scrollWaypoints(int direction) {
      this.waypointMenuOffset += direction;
   }

   private void changeZoom(double factor, int zoomMethod) {
      this.closeDropdowns();
      this.lastZoomMethod = zoomMethod;
      this.cameraDestinationAnimX = null;
      this.cameraDestinationAnimZ = null;
      if (func_146271_m()) {
         double destScaleBefore = destScale;
         if (destScale >= 1.0D) {
            if (factor > 0.0D) {
               destScale = Math.ceil(destScale);
            } else {
               destScale = Math.floor(destScale);
            }

            if (destScaleBefore == destScale) {
               destScale += factor > 0.0D ? 1.0D : -1.0D;
            }

            if (destScale == 0.0D) {
               destScale = 0.5D;
            }
         } else {
            double reversedScale = 1.0D / destScale;
            double log2 = Math.log(reversedScale) / Math.log(2.0D);
            if (factor > 0.0D) {
               log2 = Math.floor(log2);
            } else {
               log2 = Math.ceil(log2);
            }

            destScale = 1.0D / Math.pow(2.0D, log2);
            if (destScaleBefore == destScale) {
               destScale = 1.0D / Math.pow(2.0D, log2 + (double)(factor > 0.0D ? -1 : 1));
            }
         }
      } else {
         destScale *= Math.pow(1.2D, factor);
      }

      if (destScale < 0.0625D) {
         destScale = 0.0625D;
      } else if (destScale > 50.0D) {
         destScale = 50.0D;
      }

   }

   public void func_146281_b() {
      super.func_146281_b();
      this.leftMouseButton.isDown = false;
      this.rightMouseButton.isDown = false;
   }

   public void func_73863_a(int scaledMouseX, int scaledMouseY, float partialTicks) {
      while(GL11.glGetError() != 0) {
      }

      GlStateManager.func_179082_a(0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
      this.dropdowns.removeAll(this.dropdownsToRemove);
      this.dropdownsToRemove.clear();
      Minecraft mc = Minecraft.func_71410_x();
      if (this.shouldResetCameraPos) {
         this.cameraX = (double)((float)this.player.field_70165_t);
         this.cameraZ = (double)((float)this.player.field_70161_v);
         this.shouldResetCameraPos = false;
      }

      long startTime = System.currentTimeMillis();
      this.dimensionSettings.preMapRender(this, this.dropdowns, mc, this.field_146294_l, this.field_146295_m);
      long passed = this.lastStartTime == 0L ? 16L : startTime - this.lastStartTime;
      double passedScrolls = (double)((float)passed / 64.0F);
      int direction = this.buttonPressed != this.zoomInButton && !ControlsHandler.isDown(ControlsRegister.keyZoomIn) ? (this.buttonPressed != this.zoomOutButton && !ControlsHandler.isDown(ControlsRegister.keyZoomOut) ? 0 : -1) : 1;
      if (direction != 0) {
         boolean ctrlKey = func_146271_m();
         if (!ctrlKey || !this.pauseZoomKeys) {
            this.changeZoom((double)direction * passedScrolls, this.buttonPressed != this.zoomInButton && this.buttonPressed != this.zoomOutButton ? 1 : 2);
            if (ctrlKey) {
               this.pauseZoomKeys = true;
            }
         }
      } else {
         this.pauseZoomKeys = false;
      }

      this.lastStartTime = startTime;
      if (this.cameraDestination != null) {
         this.cameraDestinationAnimX = new SlowingAnimation(this.cameraX, (double)this.cameraDestination[0], 0.9D, 0.001D);
         this.cameraDestinationAnimZ = new SlowingAnimation(this.cameraZ, (double)this.cameraDestination[1], 0.9D, 0.001D);
         this.cameraDestination = null;
      }

      if (this.cameraDestinationAnimX != null) {
         this.cameraX = this.cameraDestinationAnimX.getCurrent();
         if (this.cameraX == this.cameraDestinationAnimX.getDestination()) {
            this.cameraDestinationAnimX = null;
         }
      }

      if (this.cameraDestinationAnimZ != null) {
         this.cameraZ = this.cameraDestinationAnimZ.getCurrent();
         if (this.cameraZ == this.cameraDestinationAnimZ.getDestination()) {
            this.cameraDestinationAnimZ = null;
         }
      }

      this.lastViewedDimensionId = null;
      this.lastViewedMultiworldId = null;
      this.mouseBlockPosY = -1;
      boolean searchFieldPlaceHolder;
      boolean invalidRegex;
      synchronized(this.mapProcessor.renderThreadPauseSync) {
         if (this.mapProcessor.isRenderingPaused()) {
            this.renderLoadingScreen();
         } else {
            searchFieldPlaceHolder = this.mapProcessor.getCurrentWorldId() != null && this.mapProcessor.getMapSaveLoad().isRegionDetectionComplete();
            invalidRegex = mc.field_71439_g == null || mc.field_71439_g.func_70644_a(Effects.NO_WORLD_MAP) || mc.field_71439_g.func_70644_a(Effects.NO_WORLD_MAP_BENEFICIAL) || mc.field_71439_g.func_70644_a(Effects.NO_WORLD_MAP_HARMFUL);
            if (searchFieldPlaceHolder && !invalidRegex) {
               if (SupportMods.vivecraft) {
                  GlStateManager.func_179082_a(0.0F, 0.0F, 0.0F, 1.0F);
                  GL11.glClearColor(0.0F, 0.0F, 0.0F, 1.0F);
                  GlStateManager.func_179086_m(16384);
               }

               this.lastViewedDimensionId = this.mapProcessor.getMapWorld().getCurrentDimension().getDimId();
               this.lastViewedMultiworldId = this.mapProcessor.getMapWorld().getCurrentDimension().getCurrentMultiworld();
               if (SupportMods.minimap()) {
                  SupportMods.xaeroMinimap.checkWaypoints(this.mapProcessor.getMapWorld().isMultiplayer(), this.lastViewedDimensionId, this.lastViewedMultiworldId, this.field_146294_l, this.field_146295_m, this, this.waypointMenuSearchPattern, this.waypointMenuSearchStartPattern);
               }

               int mouseXPos = (int)Misc.getMouseX(mc);
               int mouseYPos = (int)Misc.getMouseY(mc);
               double scaleMultiplier = this.getScaleMultiplier(Math.min(mc.field_71443_c, mc.field_71440_d));
               this.scale = this.userScale * scaleMultiplier;
               if (this.mouseCheckPosX == -1 || System.nanoTime() - this.mouseCheckTimeNano > 30000000L) {
                  this.prevMouseCheckPosX = this.mouseCheckPosX;
                  this.prevMouseCheckPosY = this.mouseCheckPosY;
                  this.prevMouseCheckTimeNano = this.mouseCheckTimeNano;
                  this.mouseCheckPosX = mouseXPos;
                  this.mouseCheckPosY = mouseYPos;
                  this.mouseCheckTimeNano = System.nanoTime();
               }

               double oldMousePosZ;
               double preScale;
               double fboScale;
               double secondaryScale;
               double mousePosX;
               double mousePosZ;
               if (!this.leftMouseButton.isDown) {
                  if (this.mouseDownPosX != -1) {
                     this.mouseDownPosX = -1;
                     this.mouseDownPosY = -1;
                     if (this.prevMouseCheckTimeNano != -1L) {
                        double downTime = 0.0D;
                        int draggedX = false;
                        int draggedY = false;
                        downTime = (double)(System.nanoTime() - this.prevMouseCheckTimeNano);
                        int draggedX = mouseXPos - this.prevMouseCheckPosX;
                        int draggedY = mouseYPos - this.prevMouseCheckPosY;
                        oldMousePosZ = 1.6666666666666666E7D;
                        preScale = downTime / oldMousePosZ;
                        fboScale = (double)(-draggedX) / this.scale / preScale;
                        double speed_z = (double)(-draggedY) / this.scale / preScale;
                        secondaryScale = Math.sqrt(fboScale * fboScale + speed_z * speed_z);
                        if (secondaryScale > 0.0D) {
                           mousePosX = fboScale / secondaryScale;
                           mousePosZ = speed_z / secondaryScale;
                           double maxSpeed = 500.0D / this.userScale;
                           secondaryScale = Math.abs(secondaryScale) > maxSpeed ? Math.copySign(maxSpeed, secondaryScale) : secondaryScale;
                           double speed_factor = 0.9D;
                           double ln = Math.log(speed_factor);
                           double move_distance = -secondaryScale / ln;
                           double moveX = mousePosX * move_distance;
                           double moveZ = mousePosZ * move_distance;
                           this.cameraDestinationAnimX = new SlowingAnimation(this.cameraX, this.cameraX + moveX, 0.9D, 0.001D);
                           this.cameraDestinationAnimZ = new SlowingAnimation(this.cameraZ, this.cameraZ + moveZ, 0.9D, 0.001D);
                        }
                     }
                  }
               } else if (this.viewed == null || !this.viewedInList || this.mouseDownPosX != -1) {
                  if (this.mouseDownPosX != -1) {
                     this.cameraX = (double)(this.mouseDownPosX - mouseXPos) / this.scale + this.mouseDownCameraX;
                     this.cameraZ = (double)(this.mouseDownPosY - mouseYPos) / this.scale + this.mouseDownCameraZ;
                  } else {
                     this.mouseDownPosX = mouseXPos;
                     this.mouseDownPosY = mouseYPos;
                     this.mouseDownCameraX = this.cameraX;
                     this.mouseDownCameraZ = this.cameraZ;
                     this.cameraDestinationAnimX = null;
                     this.cameraDestinationAnimZ = null;
                  }
               }

               int mouseFromCentreX = mouseXPos - mc.field_71443_c / 2;
               int mouseFromCentreY = mouseYPos - mc.field_71440_d / 2;
               double oldMousePosX = (double)mouseFromCentreX / this.scale + this.cameraX;
               oldMousePosZ = (double)mouseFromCentreY / this.scale + this.cameraZ;
               preScale = this.scale;
               if (destScale != this.userScale) {
                  if (this.zoomAnim != null) {
                     this.userScale = this.zoomAnim.getCurrent();
                     this.scale = this.userScale * scaleMultiplier;
                  }

                  if (this.zoomAnim == null || Misc.round(this.zoomAnim.getDestination(), 4) != Misc.round(destScale, 4)) {
                     this.zoomAnim = new SinAnimation(this.userScale, destScale, 100L);
                  }
               }

               if (this.scale > preScale && this.lastZoomMethod != 2) {
                  this.cameraX = oldMousePosX - (double)mouseFromCentreX / this.scale;
                  this.cameraZ = oldMousePosZ - (double)mouseFromCentreY / this.scale;
               }

               int textureLevel = 0;
               if (this.scale >= 1.0D) {
                  fboScale = Math.max(1.0D, Math.floor(this.scale));
               } else {
                  fboScale = this.scale;
               }

               if (this.userScale < 1.0D) {
                  double reversedScale = 1.0D / this.userScale;
                  double log2 = Math.floor(Math.log(reversedScale) / Math.log(2.0D));
                  textureLevel = Math.min((int)log2, 3);
               }

               this.mapProcessor.getMapSaveLoad().mainTextureLevel = textureLevel;
               int leveledRegionShift = 9 + textureLevel;
               secondaryScale = this.scale / fboScale;
               GlStateManager.func_179094_E();
               mousePosX = (double)mouseFromCentreX / this.scale + this.cameraX;
               mousePosZ = (double)mouseFromCentreY / this.scale + this.cameraZ;
               GlStateManager.func_179094_E();
               GlStateManager.func_179109_b(0.0F, 0.0F, 500.0F);
               if (WorldMap.settings.displayZoom) {
                  String zoomString = (double)Math.round(destScale * 1000.0D) / 1000.0D + "x";
                  this.func_73732_a(mc.field_71466_p, zoomString, this.field_146294_l / 2, this.field_146295_m - 12, -1);
               }

               this.mouseBlockPosX = (int)Math.floor(mousePosX);
               this.mouseBlockPosZ = (int)Math.floor(mousePosZ);
               int mouseRegX = this.mouseBlockPosX >> leveledRegionShift;
               int mouseRegZ = this.mouseBlockPosZ >> leveledRegionShift;
               LeveledRegion<?> reg = this.mapProcessor.getLeveledRegion(mouseRegX, mouseRegZ, textureLevel);
               int maxRegBlockCoord = (1 << leveledRegionShift) - 1;
               int mouseRegPixelX = (this.mouseBlockPosX & maxRegBlockCoord) >> textureLevel;
               int mouseRegPixelZ = (this.mouseBlockPosZ & maxRegBlockCoord) >> textureLevel;
               this.mouseBlockPosX = (mouseRegX << leveledRegionShift) + (mouseRegPixelX << textureLevel);
               this.mouseBlockPosZ = (mouseRegZ << leveledRegionShift) + (mouseRegPixelZ << textureLevel);
               MapRegion leafRegion = this.mapProcessor.getMapRegion(this.mouseBlockPosX >> 9, this.mouseBlockPosZ >> 9, false);
               MapTileChunk chunk = leafRegion == null ? null : leafRegion.getChunk(this.mouseBlockPosX >> 6 & 7, this.mouseBlockPosZ >> 6 & 7);
               int debugTextureX = this.mouseBlockPosX >> leveledRegionShift - 3 & 7;
               int debugTextureY = this.mouseBlockPosZ >> leveledRegionShift - 3 & 7;
               RegionTexture tex = reg != null && reg.hasTextures() ? reg.getTexture(debugTextureX, debugTextureY) : null;
               int flooredCameraZ;
               if (WorldMap.settings.debug) {
                  if (reg != null) {
                     List<String> debugLines = new ArrayList();
                     if (tex != null) {
                        tex.addDebugLines(debugLines);
                        MapTile mouseTile = chunk == null ? null : chunk.getTile(this.mouseBlockPosX >> 4 & 3, this.mouseBlockPosZ >> 4 & 3);
                        if (mouseTile != null) {
                           MapBlock block = mouseTile.getBlock(this.mouseBlockPosX & 15, this.mouseBlockPosZ & 15);
                           if (block != null) {
                              this.func_73732_a(mc.field_71466_p, block.toString(), this.field_146294_l / 2, 12, -1);
                              if (block.getNumberOfOverlays() != 0) {
                                 for(int i = 0; i < block.getOverlays().size(); ++i) {
                                    this.func_73732_a(mc.field_71466_p, ((Overlay)block.getOverlays().get(i)).toString(), this.field_146294_l / 2, 22 + i * 10, -1);
                                 }
                              }
                           }
                        }
                     }

                     debugLines.add("");
                     debugLines.add(mouseRegX + " " + mouseRegZ + " " + textureLevel);
                     reg.addDebugLines(debugLines, this.mapProcessor, debugTextureX, debugTextureY);

                     for(flooredCameraZ = 0; flooredCameraZ < debugLines.size(); ++flooredCameraZ) {
                        this.func_73731_b(mc.field_71466_p, (String)debugLines.get(flooredCameraZ), 5, 15 + 10 * flooredCameraZ, -1);
                     }
                  }

                  if (this.mapProcessor.getMapWorld().isMultiplayer()) {
                     this.func_73731_b(mc.field_71466_p, "MultiWorld ID: " + this.mapProcessor.getMapWorld().getCurrentMultiworld(), 5, 255, -1);
                  }

                  LeveledRegionManager regions = this.mapProcessor.getMapWorld().getCurrentDimension().getMapRegions();
                  this.func_73731_b(mc.field_71466_p, String.format("regions: %d loaded: %d processed: %d viewed: %d benchmarks %s", regions.size(), regions.loadedCount(), this.mapProcessor.getProcessedCount(), lastAmountOfRegionsViewed, WorldMap.textureUploadBenchmark.getTotalsString()), 5, 265, -1);
                  this.func_73731_b(mc.field_71466_p, String.format("toLoad: %d toSave: %d tile pool: %d overlays: %d toLoadBranchCache: %d ", this.mapProcessor.getMapSaveLoad().getSizeOfToLoad(), this.mapProcessor.getMapSaveLoad().getToSave().size(), this.mapProcessor.getTilePool().size(), this.mapProcessor.getOverlayManager().getNumberOfUniqueOverlays(), this.mapProcessor.getMapSaveLoad().getSizeOfToLoadBranchCache()), 5, 275, -1);
                  long i = Runtime.getRuntime().maxMemory();
                  long j = Runtime.getRuntime().totalMemory();
                  long k = Runtime.getRuntime().freeMemory();
                  long l = j - k;
                  this.func_73731_b(mc.field_71466_p, String.format("FPS: %d", Minecraft.func_175610_ah()), 5, 295, -1);
                  this.func_73731_b(mc.field_71466_p, String.format("Mem: % 2d%% %03d/%03dMB", l * 100L / i, bytesToMb(l), bytesToMb(i)), 5, 305, -1);
                  this.func_73731_b(mc.field_71466_p, String.format("Allocated: % 2d%% %03dMB", j * 100L / i, bytesToMb(j)), 5, 315, -1);
                  this.func_73731_b(mc.field_71466_p, String.format("Available VRAM: %dMB", this.mapProcessor.getMapLimiter().getAvailableVRAM() / 1024), 5, 325, -1);
               }

               if (tex != null) {
                  this.mouseBlockPosY = tex.getHeight(mouseRegPixelX & 63, mouseRegPixelZ & 63);
               }

               if (WorldMap.settings.coordinates) {
                  String coordsString = "X: " + this.mouseBlockPosX;
                  if (this.mouseBlockPosY != -1) {
                     coordsString = coordsString + " Y: " + this.mouseBlockPosY;
                  }

                  coordsString = coordsString + " Z: " + this.mouseBlockPosZ;
                  this.func_73732_a(mc.field_71466_p, coordsString, this.field_146294_l / 2, 2, -1);
               }

               GlStateManager.func_179121_F();
               if (primaryScaleFBO == null || primaryScaleFBO.field_147621_c != mc.field_71443_c || primaryScaleFBO.field_147618_d != mc.field_71440_d) {
                  if (!Minecraft.func_71410_x().field_71474_y.field_151448_g) {
                     Minecraft.func_71410_x().field_71474_y.func_74306_a(Options.FBO_ENABLE, 0);
                     System.out.println("FBO is off. Turning it on.");
                  }

                  primaryScaleFBO = new ImprovedFramebuffer(mc.field_71443_c, mc.field_71440_d, false);
               }

               if (primaryScaleFBO.field_147616_f == -1) {
                  GlStateManager.func_179121_F();
                  return;
               }

               primaryScaleFBO.func_147610_a(false);
               GlStateManager.func_179082_a(0.0F, 0.0F, 0.0F, 1.0F);
               GL11.glClearColor(0.0F, 0.0F, 0.0F, 1.0F);
               GlStateManager.func_179086_m(16384);
               GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
               GlStateManager.func_179152_a(1.0F / (float)this.screenScale, 1.0F / (float)this.screenScale, 1.0F);
               GlStateManager.func_179109_b((float)(mc.field_71443_c / 2), (float)(mc.field_71440_d / 2), 0.0F);
               GlStateManager.func_179094_E();
               GlStateManager.func_179129_p();
               int flooredCameraX = (int)Math.floor(this.cameraX);
               flooredCameraZ = (int)Math.floor(this.cameraZ);
               double primaryOffsetX = 0.0D;
               double primaryOffsetY = 0.0D;
               double secondaryOffsetX;
               double secondaryOffsetY;
               double leftBorder;
               double topBorder;
               double bottomBorder;
               if (fboScale < 1.0D) {
                  leftBorder = 1.0D / fboScale;
                  int xInFullPixels = (int)Math.floor(this.cameraX / leftBorder);
                  int zInFullPixels = (int)Math.floor(this.cameraZ / leftBorder);
                  topBorder = (double)xInFullPixels * leftBorder;
                  bottomBorder = (double)zInFullPixels * leftBorder;
                  flooredCameraX = (int)Math.floor(topBorder);
                  flooredCameraZ = (int)Math.floor(bottomBorder);
                  primaryOffsetX = topBorder - (double)flooredCameraX;
                  primaryOffsetY = bottomBorder - (double)flooredCameraZ;
                  secondaryOffsetX = (this.cameraX - topBorder) * fboScale;
                  secondaryOffsetY = (this.cameraZ - bottomBorder) * fboScale;
               } else {
                  secondaryOffsetX = (this.cameraX - (double)flooredCameraX) * fboScale;
                  secondaryOffsetY = (this.cameraZ - (double)flooredCameraZ) * fboScale;
                  int offset;
                  if (secondaryOffsetX >= 1.0D) {
                     offset = (int)secondaryOffsetX;
                     GlStateManager.func_179109_b((float)(-offset), 0.0F, 0.0F);
                     secondaryOffsetX -= (double)offset;
                  }

                  if (secondaryOffsetY >= 1.0D) {
                     offset = (int)secondaryOffsetY;
                     GlStateManager.func_179109_b(0.0F, (float)offset, 0.0F);
                     secondaryOffsetY -= (double)offset;
                  }
               }

               GlStateManager.func_179139_a(fboScale, -fboScale, 1.0D);
               GlStateManager.func_179137_b(-primaryOffsetX, -primaryOffsetY, 0.0D);
               GlStateManager.func_179098_w();
               leftBorder = this.cameraX - (double)(mc.field_71443_c / 2) / this.scale;
               double rightBorder = leftBorder + (double)mc.field_71443_c / this.scale;
               topBorder = this.cameraZ - (double)(mc.field_71440_d / 2) / this.scale;
               bottomBorder = topBorder + (double)mc.field_71440_d / this.scale;
               int minRegX = (int)leftBorder >> leveledRegionShift;
               int maxRegX = (int)rightBorder >> leveledRegionShift;
               int minRegZ = (int)topBorder >> leveledRegionShift;
               int maxRegZ = (int)bottomBorder >> leveledRegionShift;
               int minLeafRegX = (int)leftBorder >> 9;
               int maxLeafRegX = (int)rightBorder >> 9;
               int minLeafRegZ = (int)topBorder >> 9;
               int maxLeafRegZ = (int)bottomBorder >> 9;
               lastAmountOfRegionsViewed = (maxRegX - minRegX + 1) * (maxRegZ - minRegZ + 1);
               if (this.mapProcessor.getMapLimiter().getMostRegionsAtATime() < lastAmountOfRegionsViewed) {
                  this.mapProcessor.getMapLimiter().setMostRegionsAtATime(lastAmountOfRegionsViewed);
               }

               GlStateManager.func_179084_k();
               GlStateManager.func_179118_c();
               this.regionBuffer.clear();
               this.branchRegionBuffer.clear();
               float brightness = this.mapProcessor.getBrightness();
               int globalRegionCacheHashCode = WorldMap.settings.getRegionCacheHashCode();
               boolean reloadEverything = WorldMap.settings.reloadEverything;
               int globalReloadVersion = WorldMap.settings.reloadVersion;
               this.waitingForBranchCache[0] = false;
               setupTextureMatricesAndTextures(brightness);
               LeveledRegion.setComparison(this.mouseBlockPosX >> leveledRegionShift, this.mouseBlockPosZ >> leveledRegionShift, textureLevel, this.mouseBlockPosX >> 9, this.mouseBlockPosZ >> 9);
               int leveledRegX = minRegX;

               while(true) {
                  int leveledSideInRegions;
                  int counter;
                  int leafRegionMinX;
                  int leafRegionMinZ;
                  int textureSize;
                  int i;
                  if (leveledRegX > maxRegX) {
                     restoreTextureStates();
                     LeveledRegion<?> nextToLoad = this.mapProcessor.getMapSaveLoad().getNextToLoadByViewing();
                     boolean shouldRequest = false;
                     if (nextToLoad != null) {
                        synchronized(nextToLoad) {
                           if (!nextToLoad.reloadHasBeenRequested() && !nextToLoad.hasRemovableSourceData()) {
                              shouldRequest = true;
                           }
                        }
                     } else {
                        shouldRequest = true;
                     }

                     shouldRequest = shouldRequest && this.mapProcessor.getAffectingLoadingFrequencyCount() < 16;
                     if (shouldRequest && !WorldMap.settings.pauseRequests) {
                        int toRequest = 2;
                        counter = 0;

                        for(leafRegionMinX = 0; leafRegionMinX < this.branchRegionBuffer.size() && counter < toRequest; ++leafRegionMinX) {
                           BranchLeveledRegion region = (BranchLeveledRegion)this.branchRegionBuffer.get(leafRegionMinX);
                           if (!region.reloadHasBeenRequested() && !region.recacheHasBeenRequested() && !region.isLoaded()) {
                              region.setReloadHasBeenRequested(true, "Gui");
                              this.mapProcessor.getMapSaveLoad().requestBranchCache(region, "Gui");
                              if (counter == 0) {
                                 this.mapProcessor.getMapSaveLoad().setNextToLoadByViewing((LeveledRegion)region);
                              }

                              ++counter;
                           }
                        }

                        toRequest = 1;
                        counter = 0;
                        if (!this.prevWaitingForBranchCache) {
                           for(leafRegionMinX = 0; leafRegionMinX < this.regionBuffer.size() && counter < toRequest; ++leafRegionMinX) {
                              MapRegion region = (MapRegion)this.regionBuffer.get(leafRegionMinX);
                              if (region != nextToLoad || this.regionBuffer.size() <= 1) {
                                 synchronized(region) {
                                    if (!region.reloadHasBeenRequested() && !region.recacheHasBeenRequested() && (region.getLoadState() == 0 || region.getLoadState() == 4)) {
                                       this.mapProcessor.getMapSaveLoad().requestLoad(region, "Gui");
                                       if (counter == 0) {
                                          this.mapProcessor.getMapSaveLoad().setNextToLoadByViewing(region);
                                       }

                                       ++counter;
                                       if (region.getLoadState() == 4) {
                                          break;
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }

                     this.prevWaitingForBranchCache = this.waitingForBranchCache[0];
                     func_73734_a((this.mouseBlockPosX >> 4) * 16 - flooredCameraX, (this.mouseBlockPosZ >> 4) * 16 - flooredCameraZ, ((this.mouseBlockPosX >> 4) + 1) * 16 - flooredCameraX, ((this.mouseBlockPosZ >> 4) + 1) * 16 - flooredCameraZ, 687865855);
                     GlStateManager.func_179147_l();
                     GlStateManager.func_179141_d();
                     GlStateManager.func_179084_k();
                     GlStateManager.func_179118_c();
                     primaryScaleFBO.func_147609_e();
                     Minecraft.func_71410_x().func_147110_a().func_147610_a(false);
                     GlStateManager.func_179089_o();
                     GlStateManager.func_179121_F();
                     GlStateManager.func_179094_E();
                     GlStateManager.func_179139_a(secondaryScale, secondaryScale, 1.0D);
                     primaryScaleFBO.func_147612_c();
                     GL11.glTexParameteri(3553, 10240, 9729);
                     GL11.glTexParameteri(3553, 10241, 9729);
                     leveledSideInRegions = -mc.field_71443_c / 2;
                     counter = mc.field_71440_d / 2 - 5;
                     leafRegionMinX = mc.field_71443_c;
                     int lineH = 6;
                     func_73734_a(leveledSideInRegions, counter, leveledSideInRegions + leafRegionMinX, counter + lineH, -16777216);
                     leveledSideInRegions = mc.field_71443_c / 2 - 5;
                     counter = -mc.field_71440_d / 2;
                     int lineW = 6;
                     leafRegionMinZ = mc.field_71440_d;
                     func_73734_a(leveledSideInRegions, counter, leveledSideInRegions + lineW, counter + leafRegionMinZ, -16777216);
                     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                     GlStateManager.func_179126_j();
                     if (SupportMods.vivecraft) {
                        GlStateManager.func_179147_l();
                        GlStateManager.func_179120_a(1, 0, 0, 1);
                     }

                     renderTexturedModalRect((float)(-mc.field_71443_c / 2) - (float)secondaryOffsetX, (float)(-mc.field_71440_d / 2) - (float)secondaryOffsetY, (float)mc.field_71443_c, (float)mc.field_71440_d);
                     if (SupportMods.vivecraft) {
                        GlStateManager.func_179120_a(770, 771, 1, 0);
                     }

                     GlStateManager.func_179121_F();
                     GlStateManager.func_179139_a(this.scale, this.scale, 1.0D);
                     GlStateManager.func_179147_l();
                     GlStateManager.func_179141_d();
                     double minGuiScale = 4.0D;
                     float guiBasedScale = 1.0F;
                     if ((double)this.screenScale > minGuiScale) {
                        guiBasedScale = (float)((double)this.screenScale / minGuiScale);
                     }

                     if (SupportMods.minimap() && WorldMap.settings.waypoints) {
                        GlStateManager.func_179129_p();
                        Waypoint renderResult = SupportMods.xaeroMinimap.renderWaypoints(this, this.cameraX, this.cameraZ, mc.field_71443_c, mc.field_71440_d, (double)guiBasedScale, this.scale, mousePosX, mousePosZ, this.waypointMenuSearchPattern, this.waypointMenuSearchStartPattern, brightness, this.viewed, mc, this.scaledresolution);
                        this.viewed = renderResult != null ? renderResult : null;
                        this.viewedInList = false;
                        GlStateManager.func_179089_o();
                        GlStateManager.func_179147_l();
                     } else {
                        this.viewed = null;
                     }

                     ArrayList filteredWaypoints;
                     if (WorldMap.settings.footsteps) {
                        filteredWaypoints = this.mapProcessor.getFootprints();
                        synchronized(filteredWaypoints) {
                           for(i = 0; i < filteredWaypoints.size(); ++i) {
                              Double[] coords = (Double[])filteredWaypoints.get(i);
                              this.setColourBuffer(1.0F, 0.1F, 0.1F, 1.0F);
                              this.drawDotOnMap(coords[0] - this.cameraX, coords[1] - this.cameraZ, 0.0F, 1.0D / this.scale);
                           }
                        }
                     }

                     if (WorldMap.settings.renderArrow) {
                        boolean toTheLeft = this.player.field_70165_t < leftBorder;
                        boolean toTheRight = this.player.field_70165_t > rightBorder;
                        boolean down = this.player.field_70161_v > bottomBorder;
                        boolean up = this.player.field_70161_v < topBorder;
                        GlStateManager.func_179147_l();
                        if (!toTheLeft && !toTheRight && !up && !down) {
                           this.setColourBuffer(0.0F, 0.0F, 0.0F, 0.9F);
                           this.drawArrowOnMap(this.player.field_70165_t - this.cameraX, this.player.field_70161_v + (double)(2.0F * guiBasedScale) / this.scale - this.cameraZ, this.player.field_70177_z, (double)guiBasedScale / this.scale);
                           this.setColourBuffer(0.8F, 0.1F, 0.1F, 1.0F);
                           this.drawArrowOnMap(this.player.field_70165_t - this.cameraX, this.player.field_70161_v - this.cameraZ, this.player.field_70177_z, (double)guiBasedScale / this.scale);
                        } else {
                           double arrowX = this.player.field_70165_t;
                           double arrowZ = this.player.field_70161_v;
                           float a = 0.0F;
                           if (toTheLeft) {
                              a = up ? 1.5F : (down ? 0.5F : 1.0F);
                              arrowX = leftBorder;
                           } else if (toTheRight) {
                              a = up ? 2.5F : (down ? 3.5F : 3.0F);
                              arrowX = rightBorder;
                           }

                           if (down) {
                              arrowZ = bottomBorder;
                           } else if (up) {
                              if (a == 0.0F) {
                                 a = 2.0F;
                              }

                              arrowZ = topBorder;
                           }

                           this.setColourBuffer(0.0F, 0.0F, 0.0F, 0.9F);
                           this.drawFarArrowOnMap(arrowX - this.cameraX, arrowZ + (double)(2.0F * guiBasedScale) / this.scale - this.cameraZ, a, (double)guiBasedScale / this.scale);
                           this.setColourBuffer(0.8F, 0.1F, 0.1F, 1.0F);
                           this.drawFarArrowOnMap(arrowX - this.cameraX, arrowZ - this.cameraZ, a, (double)guiBasedScale / this.scale);
                        }
                     }

                     GlStateManager.func_179121_F();
                     this.overWaypointsMenu = false;
                     if (this.waypointMenu) {
                        filteredWaypoints = SupportMods.xaeroMinimap.getWaypointsFiltered();
                        if (filteredWaypoints != null) {
                           textureSize = WaypointMenuRenderer.getMenuElementCount(WaypointMenuRenderer.menuStartPos(this.field_146295_m));
                           if (this.waypointMenuOffset + textureSize > filteredWaypoints.size()) {
                              this.waypointMenuOffset = filteredWaypoints.size() - textureSize;
                           }

                           if (this.waypointMenuOffset < 0) {
                              this.waypointMenuOffset = 0;
                           }

                           WaypointMenuElement hovered = SupportMods.xaeroMinimap.renderWaypointsMenu(this, filteredWaypoints, this.scale, this.field_146294_l, this.field_146295_m, this.waypointMenuOffset, scaledMouseX, scaledMouseY, this.leftMouseButton.isDown, this.leftMouseButton.clicked, mc);
                           if (hovered != null) {
                              this.overWaypointsMenu = true;
                              if (hovered instanceof Waypoint) {
                                 this.viewed = (Waypoint)hovered;
                                 this.viewedInList = true;
                                 if (this.leftMouseButton.clicked) {
                                    this.cameraDestination = new int[]{this.viewed.getX(), this.viewed.getZ()};
                                 }
                              }
                           }
                        }
                     }

                     this.dimensionSettings.renderText(mc, scaledMouseX, scaledMouseY, this.field_146294_l, this.field_146295_m);
                     if (SupportMods.minimap()) {
                        SupportMods.xaeroMinimap.drawSetChange(this.scaledresolution);
                     }

                     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                     break;
                  }

                  for(int leveledRegZ = minRegZ; leveledRegZ <= maxRegZ; ++leveledRegZ) {
                     leveledSideInRegions = 1 << textureLevel;
                     counter = leveledSideInRegions * 512;
                     leafRegionMinX = leveledRegX * leveledSideInRegions;
                     leafRegionMinZ = leveledRegZ * leveledSideInRegions;
                     LeveledRegion<?> leveledRegion = null;

                     int minXBlocks;
                     int minZBlocks;
                     for(int leafX = 0; leafX < leveledSideInRegions; ++leafX) {
                        for(minXBlocks = 0; minXBlocks < leveledSideInRegions; ++minXBlocks) {
                           minZBlocks = leafRegionMinX + leafX;
                           if (minZBlocks >= minLeafRegX && minZBlocks <= maxLeafRegX) {
                              textureSize = leafRegionMinZ + minXBlocks;
                              if (textureSize >= minLeafRegZ && textureSize <= maxLeafRegZ) {
                                 MapRegion region = this.mapProcessor.getMapRegion(minZBlocks, textureSize, false);
                                 if (region == null) {
                                    region = this.mapProcessor.getMapRegion(minZBlocks, textureSize, this.mapProcessor.regionExists(minZBlocks, textureSize));
                                 }

                                 if (region != null) {
                                    if (leveledRegion == null) {
                                       leveledRegion = this.mapProcessor.getLeveledRegion(leveledRegX, leveledRegZ, textureLevel);
                                    }

                                    if (!this.prevWaitingForBranchCache) {
                                       synchronized(region) {
                                          if (textureLevel != 0 && region.getLoadState() == 0 && region.loadingNeededForBranchLevel != 0 && region.loadingNeededForBranchLevel != textureLevel) {
                                             region.loadingNeededForBranchLevel = 0;
                                             region.getParent().setShouldCheckForUpdatesRecursive(true);
                                          }

                                          if (!region.recacheHasBeenRequested() && !region.reloadHasBeenRequested() && (region.getLoadState() == 4 || region.getLoadState() == 2 && region.isBeingWritten() || region.getLoadState() == 0) && (reloadEverything && region.getReloadVersion() != globalReloadVersion || region.getCacheHashCode() != globalRegionCacheHashCode || region.getVersion() != this.mapProcessor.getGlobalVersion() || region.getLoadState() != 2 && region.shouldCache() || region.getLoadState() == 0 && (textureLevel == 0 || region.loadingNeededForBranchLevel == textureLevel))) {
                                             if (region.getLoadState() == 2) {
                                                region.requestRefresh(this.mapProcessor);
                                             } else {
                                                region.calculateSortingDistance();
                                                Misc.addToListOfSmallest(10, this.regionBuffer, region);
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }

                     if (leveledRegion != null) {
                        LeveledRegion<?> rootLeveledRegion = leveledRegion.getRootRegion();
                        if (rootLeveledRegion == leveledRegion) {
                           rootLeveledRegion = null;
                        }

                        if (rootLeveledRegion != null && !rootLeveledRegion.isLoaded()) {
                           if (!rootLeveledRegion.recacheHasBeenRequested() && !rootLeveledRegion.reloadHasBeenRequested()) {
                              rootLeveledRegion.calculateSortingDistance();
                              Misc.addToListOfSmallest(10, this.branchRegionBuffer, (BranchLeveledRegion)rootLeveledRegion);
                           }

                           this.waitingForBranchCache[0] = true;
                           rootLeveledRegion = null;
                        }

                        if (!this.mapProcessor.isUploadingPaused() && !WorldMap.settings.pauseRequests) {
                           if (leveledRegion instanceof BranchLeveledRegion) {
                              BranchLeveledRegion branchRegion = (BranchLeveledRegion)leveledRegion;
                              branchRegion.checkForUpdates(this.mapProcessor, this.prevWaitingForBranchCache, this.waitingForBranchCache, this.branchRegionBuffer, textureLevel, leafRegionMinX, leafRegionMinZ, maxLeafRegX, maxLeafRegZ);
                           }

                           this.mapProcessor.getMapWorld().getCurrentDimension().getMapRegions().bumpLoadedRegion(leveledRegion);
                           if (rootLeveledRegion != null) {
                              this.mapProcessor.getMapWorld().getCurrentDimension().getMapRegions().bumpLoadedRegion(rootLeveledRegion);
                           }
                        } else {
                           this.waitingForBranchCache[0] = this.prevWaitingForBranchCache;
                        }

                        minXBlocks = leveledRegX * counter;
                        minZBlocks = leveledRegZ * counter;
                        textureSize = 64 * leveledSideInRegions;
                        i = leveledRegX << 3;
                        int firstTextureZ = leveledRegZ << 3;
                        int levelDiff = 3 - textureLevel;
                        int rootSize = 1 << levelDiff;
                        int maxInsideCoord = rootSize - 1;
                        int firstRootTextureX = i >> levelDiff & 7;
                        int firstRootTextureZ = firstTextureZ >> levelDiff & 7;
                        int firstInsideTextureX = i & maxInsideCoord;
                        int firstInsideTextureZ = firstTextureZ & maxInsideCoord;
                        boolean hasTextures = leveledRegion.hasTextures();
                        boolean rootHasTextures = rootLeveledRegion != null && rootLeveledRegion.hasTextures();
                        int o;
                        int textureX;
                        int p;
                        int textureZ;
                        int insideX;
                        int insideZ;
                        if (hasTextures || rootHasTextures) {
                           for(o = 0; o < 8; ++o) {
                              textureX = minXBlocks + o * textureSize;
                              if (!((double)textureX > rightBorder) && !((double)(textureX + textureSize) < leftBorder)) {
                                 for(p = 0; p < 8; ++p) {
                                    textureZ = minZBlocks + p * textureSize;
                                    if (!((double)textureZ > bottomBorder) && !((double)(textureZ + textureSize) < topBorder)) {
                                       RegionTexture<?> regionTexture = hasTextures ? leveledRegion.getTexture(o, p) : null;
                                       if (regionTexture != null && regionTexture.getGlColorTexture() != -1) {
                                          synchronized(regionTexture) {
                                             if (regionTexture.getGlColorTexture() != -1) {
                                                bindMapTextureWithLighting3((RegionTexture)regionTexture, 9728, 0);
                                                renderTexturedModalRectWithLighting((float)(textureX - flooredCameraX), (float)(textureZ - flooredCameraZ), (float)textureSize, (float)textureSize);
                                             }
                                          }
                                       } else if (rootHasTextures) {
                                          insideX = firstInsideTextureX + o;
                                          insideZ = firstInsideTextureZ + p;
                                          int rootTextureX = firstRootTextureX + (insideX >> levelDiff);
                                          int rootTextureZ = firstRootTextureZ + (insideZ >> levelDiff);
                                          regionTexture = rootLeveledRegion.getTexture(rootTextureX, rootTextureZ);
                                          if (regionTexture != null) {
                                             synchronized(regionTexture) {
                                                if (regionTexture.getGlColorTexture() != -1) {
                                                   int insideTextureX = insideX & maxInsideCoord;
                                                   int insideTextureZ = insideZ & maxInsideCoord;
                                                   float textureX1 = (float)insideTextureX / (float)rootSize;
                                                   float textureX2 = (float)(insideTextureX + 1) / (float)rootSize;
                                                   float textureY1 = (float)insideTextureZ / (float)rootSize;
                                                   float textureY2 = (float)(insideTextureZ + 1) / (float)rootSize;
                                                   bindMapTextureWithLighting3((RegionTexture)regionTexture, 9728, 0);
                                                   renderTexturedModalSubRectWithLighting((float)(textureX - flooredCameraX), (float)(textureZ - flooredCameraZ), textureX1, textureY1, textureX2, textureY2, (float)textureSize, (float)textureSize);
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        if (leveledRegion.loadingAnimation()) {
                           GlStateManager.func_179094_E();
                           GlStateManager.func_179137_b((double)counter * ((double)leveledRegX + 0.5D) - (double)flooredCameraX, (double)counter * ((double)leveledRegZ + 0.5D) - (double)flooredCameraZ, 0.0D);
                           float loadingAnimationPassed = (float)(System.currentTimeMillis() - this.loadingAnimationStart);
                           if (loadingAnimationPassed > 0.0F) {
                              restoreTextureStates();
                              int period = 2000;
                              int numbersOfActors = 3;
                              float loadingAnimation = loadingAnimationPassed % (float)period / (float)period * 360.0F;
                              float step = 360.0F / (float)numbersOfActors;
                              GlStateManager.func_179114_b(loadingAnimation, 0.0F, 0.0F, 1.0F);
                              insideX = 1 + (int)loadingAnimationPassed % (3 * period) / period;
                              GlStateManager.func_179152_a((float)leveledSideInRegions, (float)leveledSideInRegions, 1.0F);

                              for(insideZ = 0; insideZ < insideX; ++insideZ) {
                                 GlStateManager.func_179114_b(step, 0.0F, 0.0F, 1.0F);
                                 func_73734_a(16, -8, 32, 8, -1);
                              }

                              GlStateManager.func_179084_k();
                              setupTextureMatricesAndTextures(brightness);
                           }

                           GlStateManager.func_179121_F();
                        }

                        if (WorldMap.settings.debug && leveledRegion instanceof MapRegion) {
                           MapRegion region = (MapRegion)leveledRegion;
                           restoreTextureStates();
                           GlStateManager.func_179094_E();
                           GlStateManager.func_179109_b((float)(512 * region.getRegionX() + 32 - flooredCameraX), (float)(512 * region.getRegionZ() + 32 - flooredCameraZ), 0.0F);
                           GlStateManager.func_179152_a(10.0F, 10.0F, 1.0F);
                           this.func_73731_b(mc.field_71466_p, "" + region.getLoadState(), 0, 0, -1);
                           GlStateManager.func_179121_F();
                           GlStateManager.func_179084_k();
                           setupTextureMatricesAndTextures(brightness);
                        }

                        if (WorldMap.settings.debug && textureLevel > 0) {
                           restoreTextureStates();

                           for(o = 0; o < leveledSideInRegions; ++o) {
                              for(textureX = 0; textureX < leveledSideInRegions; ++textureX) {
                                 p = leafRegionMinX + o;
                                 textureZ = leafRegionMinZ + textureX;
                                 MapRegion region = this.mapProcessor.getMapRegion(p, textureZ, false);
                                 if (region != null) {
                                    boolean currentlyLoading = this.mapProcessor.getMapSaveLoad().getNextToLoadByViewing() == region;
                                    if (currentlyLoading || region.isLoaded() || region.isMetaLoaded()) {
                                       GlStateManager.func_179094_E();
                                       GlStateManager.func_179109_b((float)(512 * region.getRegionX() - flooredCameraX), (float)(512 * region.getRegionZ() - flooredCameraZ), 0.0F);
                                       func_73734_a(0, 0, 512, 512, currentlyLoading ? 687800575 : (region.isLoaded() ? 671153920 : 687865600));
                                       GlStateManager.func_179121_F();
                                    }
                                 }
                              }
                           }

                           GlStateManager.func_179084_k();
                           setupTextureMatricesAndTextures(brightness);
                        }
                     }
                  }

                  ++leveledRegX;
               }
            } else if (!searchFieldPlaceHolder) {
               this.renderLoadingScreen();
            } else if (invalidRegex) {
               this.renderMessageScreen(I18n.func_135052_a("gui.xaero_no_world_map_message", new Object[0]));
            }
         }

         mc.func_110434_K().func_110577_a(WorldMap.guiTextures);
         this.func_73729_b(this.field_146294_l - 34, 2, 0, 37, 32, 32);
      }

      GlStateManager.func_179126_j();
      super.func_73863_a(scaledMouseX, scaledMouseY, partialTicks);
      GlStateManager.func_179094_E();
      GlStateManager.func_179109_b(0.0F, 0.0F, 501.0F);
      if (this.waypointMenu) {
         String searchText = this.waypointFilterField.func_146179_b();
         searchFieldPlaceHolder = searchText.isEmpty() && !this.waypointFilterField.func_146206_l();
         invalidRegex = false;
         if (searchFieldPlaceHolder) {
            this.setFieldText(this.waypointFilterField, I18n.func_135052_a("gui.xaero_filter_waypoints_by_name", new Object[0]), -11184811);
         } else if (!searchText.isEmpty() && this.waypointMenuSearchPattern == null) {
            invalidRegex = true;
         }

         this.waypointFilterField.func_146194_f();
         if (searchFieldPlaceHolder) {
            this.setFieldText(this.waypointFilterField, "");
         } else if (invalidRegex) {
            String errorMessage = I18n.func_135052_a("gui.xaero_wm_search_invalid_regex", new Object[0]);
            this.func_73731_b(mc.field_71466_p, errorMessage, this.field_146294_l - 176 - mc.field_71466_p.func_78256_a(errorMessage), this.field_146295_m - 36, -43691);
         }
      }

      Iterator var130 = this.dropdowns.iterator();

      GuiDropDown d;
      while(var130.hasNext()) {
         d = (GuiDropDown)var130.next();
         if (d.isClosed()) {
            d.drawButton(scaledMouseX, scaledMouseY, this.field_146295_m);
         }
      }

      var130 = this.dropdowns.iterator();

      while(var130.hasNext()) {
         d = (GuiDropDown)var130.next();
         if (!d.isClosed()) {
            d.drawButton(scaledMouseX, scaledMouseY, this.field_146295_m);
         }
      }

      this.dimensionSettings.postMapRender(mc, scaledMouseX, scaledMouseY, this.field_146294_l, this.field_146295_m);
      GlStateManager.func_179109_b(0.0F, 0.0F, 10.0F);
      if (mc.field_71462_r == this) {
         GlStateManager.func_179094_E();
         GlStateManager.func_179137_b(0.0D, 0.0D, 0.1D);

         for(int k = 0; k < this.field_146292_n.size(); ++k) {
            GuiButton b = (GuiButton)this.field_146292_n.get(k);
            if (b instanceof ICanTooltip) {
               ICanTooltip optionWidget = (ICanTooltip)b;
               if (scaledMouseX >= b.field_146128_h && scaledMouseY >= b.field_146129_i && scaledMouseX < b.field_146128_h + b.func_146117_b() && scaledMouseY < b.field_146129_i + b.field_146121_g && optionWidget.getTooltip() != null) {
                  optionWidget.getTooltip().drawBox(scaledMouseX, scaledMouseY, this.field_146294_l, this.field_146295_m);
               }
            }
         }

         GlStateManager.func_179121_F();
      }

      GlStateManager.func_179121_F();
      this.leftMouseButton.clicked = this.rightMouseButton.clicked = false;
   }

   private void renderLoadingScreen() {
      this.renderMessageScreen("Preparing World Map...");
   }

   private void renderMessageScreen(String message) {
      func_73734_a(0, 0, this.field_146297_k.field_71443_c, this.field_146297_k.field_71440_d, -16777216);
      GlStateManager.func_179094_E();
      GlStateManager.func_179109_b(0.0F, 0.0F, 500.0F);
      this.func_73732_a(this.field_146297_k.field_71466_p, message, this.scaledresolution.func_78326_a() / 2, this.scaledresolution.func_78328_b() / 2, -1);
      GlStateManager.func_179121_F();
   }

   public void drawDotOnMap(double x, double z, float angle, double sc) {
      this.drawObjectOnMap(x, z, angle, sc, 2.5F, 2.5F, 0, 69, 5, 5, 9729);
   }

   public void drawArrowOnMap(double x, double z, float angle, double sc) {
      this.drawObjectOnMap(x, z, angle, sc, 13.0F, 5.0F, 0, 0, 26, 28, 9729);
   }

   public void drawFarArrowOnMap(double x, double z, float angle, double sc) {
      this.drawObjectOnMap(x, z, angle * 90.0F, sc, 27.0F, 13.0F, 26, 0, 54, 13, 9729);
   }

   public void drawObjectOnMap(double x, double z, float angle, double sc, float offX, float offY, int textureX, int textureY, int w, int h, int filter) {
      GlStateManager.func_179094_E();
      GlStateManager.func_179131_c(this.colourBuffer[0], this.colourBuffer[1], this.colourBuffer[2], this.colourBuffer[3]);
      GlStateManager.func_179137_b(x, z, 0.0D);
      GlStateManager.func_179139_a(sc, sc, 1.0D);
      if (angle != 0.0F) {
         GlStateManager.func_179114_b(angle, 0.0F, 0.0F, 1.0F);
      }

      this.field_146297_k.func_110434_K().func_110577_a(WorldMap.guiTextures);
      GL11.glTexParameteri(3553, 10240, filter);
      GL11.glTexParameteri(3553, 10241, filter);
      this.func_175174_a(-offX, -offY, textureX, textureY, w, h);
      if (filter != 9728) {
         GL11.glTexParameteri(3553, 10240, 9728);
         GL11.glTexParameteri(3553, 10241, 9728);
      }

      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179121_F();
   }

   /** @deprecated */
   @Deprecated
   public static void renderTexturedModalRectWithLighting(float x, float y, int textureX, int textureY, float width, float height) {
      GL14.glBlendFuncSeparate(1, 0, 0, 1);
      renderTexturedModalRectWithLighting(x, y, width, height);
      GL14.glBlendFuncSeparate(770, 771, 1, 771);
   }

   public static void renderTexturedModalRectWithLighting(float x, float y, float width, float height) {
      Tessellator tessellator = Tessellator.func_178181_a();
      WorldRenderer worldrenderer = tessellator.func_178180_c();
      worldrenderer.func_181668_a(7, POSITION_TEX_TEX_TEX);
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + height), 0.0D).func_181673_a(0.0D, 1.0D).func_181673_a(0.0D, 1.0D).func_181673_a(0.0D, 1.0D).func_181673_a(0.0D, 1.0D).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + height), 0.0D).func_181673_a(1.0D, 1.0D).func_181673_a(1.0D, 1.0D).func_181673_a(1.0D, 1.0D).func_181673_a(1.0D, 1.0D).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + 0.0F), 0.0D).func_181673_a(1.0D, 0.0D).func_181673_a(1.0D, 0.0D).func_181673_a(1.0D, 0.0D).func_181673_a(1.0D, 0.0D).func_181675_d();
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + 0.0F), 0.0D).func_181673_a(0.0D, 0.0D).func_181673_a(0.0D, 0.0D).func_181673_a(0.0D, 0.0D).func_181673_a(0.0D, 0.0D).func_181675_d();
      tessellator.func_78381_a();
   }

   public static void renderTexturedModalSubRectWithLighting(float x, float y, float textureX1, float textureY1, float textureX2, float textureY2, float width, float height) {
      Tessellator tessellator = Tessellator.func_178181_a();
      WorldRenderer worldrenderer = tessellator.func_178180_c();
      worldrenderer.func_181668_a(7, POSITION_TEX_TEX_TEX);
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + height), 0.0D).func_181673_a((double)textureX1, (double)textureY2).func_181673_a((double)textureX1, (double)textureY2).func_181673_a((double)textureX1, (double)textureY2).func_181673_a((double)textureX1, (double)textureY2).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + height), 0.0D).func_181673_a((double)textureX2, (double)textureY2).func_181673_a((double)textureX2, (double)textureY2).func_181673_a((double)textureX2, (double)textureY2).func_181673_a((double)textureX2, (double)textureY2).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + 0.0F), 0.0D).func_181673_a((double)textureX2, (double)textureY1).func_181673_a((double)textureX2, (double)textureY1).func_181673_a((double)textureX2, (double)textureY1).func_181673_a((double)textureX2, (double)textureY1).func_181675_d();
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + 0.0F), 0.0D).func_181673_a((double)textureX1, (double)textureY1).func_181673_a((double)textureX1, (double)textureY1).func_181673_a((double)textureX1, (double)textureY1).func_181673_a((double)textureX1, (double)textureY1).func_181675_d();
      tessellator.func_78381_a();
   }

   public static void renderTexturedModalRect(float x, float y, float width, float height) {
      Tessellator tessellator = Tessellator.func_178181_a();
      WorldRenderer worldrenderer = tessellator.func_178180_c();
      worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + height), 0.0D).func_181673_a(0.0D, 1.0D).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + height), 0.0D).func_181673_a(1.0D, 1.0D).func_181675_d();
      worldrenderer.func_181662_b((double)(x + width), (double)(y + 0.0F), 0.0D).func_181673_a(1.0D, 0.0D).func_181675_d();
      worldrenderer.func_181662_b((double)(x + 0.0F), (double)(y + 0.0F), 0.0D).func_181673_a(0.0D, 0.0D).func_181675_d();
      tessellator.func_78381_a();
   }

   public void mapClicked(int button, int x, int y) {
      if (button == 1) {
         if (this.viewedOnMousePress != null && SupportMods.xaeroMinimap.waypointExists(this.viewedOnMousePress)) {
            this.handleRightClick(this.viewedOnMousePress, x / this.screenScale, y / this.screenScale);
            this.mouseDownPosX = -1;
            this.mouseDownPosY = -1;
         } else {
            this.handleRightClick(this, x / this.screenScale, y / this.screenScale);
         }
      }

   }

   private void handleRightClick(IRightClickableElement target, int x, int y) {
      if (this.rightClickMenu != null) {
         this.rightClickMenu.setClosed(true);
      }

      this.dropdowns.add(this.rightClickMenu = GuiRightClickMenu.getMenu(target, this, x, y, 150, new Consumer<GuiRightClickMenu>() {
         public void accept(GuiRightClickMenu rc) {
            GuiMap.this.onRightClickClosed(rc);
         }
      }));
   }

   private void setSearch(String search) {
      try {
         this.waypointMenuSearchPattern = Pattern.compile(search.toLowerCase());
         if (search.length() > 0) {
            if (search.charAt(0) == '^') {
               this.waypointMenuSearchStartPattern = this.waypointMenuSearchPattern;
            } else {
               this.waypointMenuSearchStartPattern = Pattern.compile('^' + search.toString().toLowerCase());
            }
         } else {
            this.waypointMenuSearchPattern = this.waypointMenuSearchStartPattern = null;
         }
      } catch (PatternSyntaxException var3) {
         this.waypointMenuSearchPattern = this.waypointMenuSearchStartPattern = null;
      }

      SupportMods.xaeroMinimap.updateFilteredList(this.waypointMenuSearchPattern, this.waypointMenuSearchStartPattern);
   }

   protected void func_146284_a(GuiButton button) throws IOException {
      super.func_146284_a(button);
      this.dimensionSettings.actionPerformed(this, this.field_146297_k, this.field_146294_l, this.field_146295_m, button);
      this.buttonClicked = true;
   }

   public void func_73869_a(char par1, int par2) throws IOException {
      super.func_73869_a(par1, par2);
      if (this.getFocused() != null) {
         this.getFocused().func_146201_a(par1, par2);
      }

      if (this.isUsingTextField()) {
         if (this.waypointMenu && this.getFocused() == this.waypointFilterField) {
            if (par1 == '\r') {
               this.waypointFilterField.func_146180_a("");
            }

            this.setSearch(this.waypointFilterField.func_146179_b());
         }
      } else {
         this.onInputPress(false, par2);
         this.onInputRelease(false, par2);
      }

   }

   public void func_146282_l() throws IOException {
      super.func_146282_l();
   }

   public static void bindMapTextureWithLighting(float brightness, MapTileChunk chunk, int magFilter, int lod) {
      setupTextureMatricesAndTextures(brightness);
      bindMapTextureWithLighting3(brightness, chunk, magFilter, lod);
   }

   /** @deprecated */
   @Deprecated
   public static void bindMapTextureWithLighting2(float brightness, MapTileChunk chunk, int magFilter, int lod) {
   }

   /** @deprecated */
   @Deprecated
   public static void bindMapTextureWithLighting3(float brightness, MapTileChunk chunk, int magFilter, int lod) {
      GlStateManager.func_179131_c(brightness, brightness, brightness, 1.0F);
      bindMapTextureWithLighting3((RegionTexture)chunk.getLeafTexture(), magFilter, lod);
   }

   public static void bindMapTextureWithLighting3(MapTileChunk chunk, int magFilter, int lod) {
      bindMapTextureWithLighting3((RegionTexture)chunk.getLeafTexture(), magFilter, lod);
   }

   public static void bindMapTextureWithLighting3(RegionTexture<?> regionTexture, int magFilter, int lod) {
      boolean hasLight = regionTexture.getTextureHasLight();
      GlStateManager.func_179138_g(33984);
      int glTexture = regionTexture.bindColorTexture(false, magFilter);
      if (hasLight) {
         GL11.glTexEnvi(8960, 8704, 34160);
      } else {
         GL11.glTexEnvi(8960, 8704, 8448);
      }

      GlStateManager.func_179138_g(33985);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(33986);
      if (hasLight) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179144_i(glTexture);
      } else {
         GlStateManager.func_179090_x();
      }

      GlStateManager.func_179138_g(33987);
      if (hasLight) {
         GlStateManager.func_179098_w();
         GlStateManager.func_179144_i(glTexture);
      } else {
         GlStateManager.func_179090_x();
      }

   }

   /** @deprecated */
   @Deprecated
   public static void setupTextureMatrices() {
   }

   private static void setupTexture0(float brightness) {
      GL11.glTexEnvi(8960, 8704, 34160);
      GL11.glTexEnvi(8960, 34161, 34023);
      GL11.glTexEnvi(8960, 34176, 5890);
      GL11.glTexEnvi(8960, 34192, 771);
      GL11.glTexEnvi(8960, 34177, 34167);
      GL11.glTexEnvi(8960, 34193, 769);
      GL11.glTexEnvi(8960, 34162, 7681);
      GL11.glTexEnvi(8960, 34184, 34167);
      GL11.glTexEnvi(8960, 34200, 770);
   }

   private static void setupTexture2() {
      GL11.glTexEnvi(8960, 8704, 34160);
      GL11.glTexEnvi(8960, 34161, 260);
      GL11.glTexEnvi(8960, 34176, 34168);
      GL11.glTexEnvi(8960, 34192, 768);
      GL11.glTexEnvi(8960, 34177, 5890);
      GL11.glTexEnvi(8960, 34193, 770);
      GL11.glTexEnvi(8960, 34162, 7681);
      GL11.glTexEnvi(8960, 34184, 34167);
      GL11.glTexEnvi(8960, 34200, 770);
   }

   private static void setupTexture3() {
      GL11.glTexEnvi(8960, 8704, 8448);
   }

   public static void setupTextures(float brightness) {
      GlStateManager.func_179131_c(brightness, brightness, brightness, 1.0F);
      GlStateManager.func_179118_c();
      GlStateManager.func_179138_g(33984);
      GlStateManager.func_179098_w();
      setupTexture0(brightness);
      GlStateManager.func_179138_g(33985);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(33986);
      setupTexture2();
      GlStateManager.func_179138_g(33987);
      setupTexture3();
      GlStateManager.func_179138_g(33984);
   }

   public static void setupTextureMatricesAndTextures(float brightness) {
      GlStateManager.func_179131_c(brightness, brightness, brightness, 1.0F);
      GlStateManager.func_179118_c();
      GlStateManager.func_179138_g(33984);
      GlStateManager.func_179098_w();
      setupTexture0(brightness);
      GlStateManager.func_179138_g(33985);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(33986);
      setupTexture2();
      GlStateManager.func_179138_g(33987);
      setupTexture3();
      GlStateManager.func_179138_g(33984);
   }

   public static void restoreTextureStates() {
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179141_d();
      GlStateManager.func_179138_g(33987);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(33986);
      GL11.glTexEnvi(8960, 34161, 8448);
      GL11.glTexEnvi(8960, 34176, 5890);
      GL11.glTexEnvi(8960, 34177, 34168);
      GL11.glTexEnvi(8960, 34193, 768);
      GL11.glTexEnvi(8960, 34162, 8448);
      GL11.glTexEnvi(8960, 34184, 5890);
      GL11.glTexEnvi(8960, 8704, 8448);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(33985);
      GL11.glTexEnvi(8960, 8704, 8448);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(33984);
      GL11.glTexEnvi(8960, 34161, 8448);
      GL11.glTexEnvi(8960, 34192, 768);
      GL11.glTexEnvi(8960, 34177, 34168);
      GL11.glTexEnvi(8960, 34193, 768);
      GL11.glTexEnvi(8960, 34162, 8448);
      GL11.glTexEnvi(8960, 34184, 5890);
      GL11.glTexEnvi(8960, 8704, 8448);
      OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, OpenGlHelper.lastBrightnessX, OpenGlHelper.lastBrightnessY);
   }

   private static long bytesToMb(long bytes) {
      return bytes / 1024L / 1024L;
   }

   private void setColourBuffer(float r, float g, float b, float a) {
      this.colourBuffer[0] = r;
      this.colourBuffer[1] = g;
      this.colourBuffer[2] = b;
      this.colourBuffer[3] = a;
   }

   private boolean isUsingTextField() {
      GuiTextField currentFocused = this.getFocused();
      return this.waypointMenu && currentFocused != null && currentFocused.func_146206_l();
   }

   public void func_73876_c() {
      super.func_73876_c();
      if (this.waypointMenu) {
         this.waypointFilterField.func_146178_a();
      }

   }

   private void setFieldText(GuiTextField field, String text) {
      this.setFieldText(field, text, -1);
   }

   private void setFieldText(GuiTextField field, String text, int color) {
      field.func_146193_g(color);
      if (!field.func_146179_b().equals(text)) {
         field.func_146180_a(text);
      }
   }

   private boolean onInputPress(boolean mouse, int code) {
      if (Misc.inputMatchesKeyBinding(mouse, code, ControlsRegister.keyOpenSettings)) {
         this.onSettingsButton(this.settingsButton);
         return true;
      } else {
         boolean result = false;
         if (Misc.inputMatchesKeyBinding(mouse, code, ControlsRegister.keyOpenMap)) {
            this.goBack();
            result = true;
         }

         if ((!mouse && code == 13 || Misc.inputMatchesKeyBinding(mouse, code, ControlsRegister.keyQuickConfirm)) && this.dimensionSettings.active) {
            this.dimensionSettings.confirm(this, this.field_146297_k, this.field_146294_l, this.field_146295_m);
            result = true;
         }

         if (SupportMods.minimap()) {
            SupportMods.xaeroMinimap.onMapKeyPressed(mouse, code, this);
            result = true;
         }

         Waypoint hoverTarget = this.getHoverTarget();
         if (hoverTarget != null && !mouse) {
            boolean isValid = hoverTarget.isRightClickValid();
            if (isValid) {
               switch(code) {
               case 35:
                  SupportMods.xaeroMinimap.disableWaypoint(hoverTarget);
                  this.closeRightClick();
                  result = true;
                  break;
               case 211:
                  SupportMods.xaeroMinimap.deleteWaypoint(hoverTarget);
                  this.closeRightClick();
                  result = true;
               }
            } else {
               this.closeRightClick();
            }
         }

         return result;
      }
   }

   private boolean onInputRelease(boolean mouse, int code) {
      if (SupportMods.minimap() && this.lastViewedDimensionId != null && !this.isUsingTextField()) {
         boolean result = false;
         int waypointDestinationX = this.mouseBlockPosX;
         int waypointDestinationY = this.mouseBlockPosY;
         int waypointDestinationZ = this.mouseBlockPosZ;
         if (this.rightClickMenu != null && this.rightClickMenu.getTarget() == this) {
            waypointDestinationX = this.rightClickX;
            waypointDestinationY = this.rightClickY;
            waypointDestinationZ = this.rightClickZ;
         }

         if (waypointDestinationY != -1) {
            if (Misc.inputMatchesKeyBinding(mouse, code, SupportMods.xaeroMinimap.getWaypointKeyBinding()) && WorldMap.settings.waypoints) {
               SupportMods.xaeroMinimap.createWaypoint(this, waypointDestinationX, waypointDestinationY + 1, waypointDestinationZ);
               this.closeRightClick();
               result = true;
            }

            if (Misc.inputMatchesKeyBinding(mouse, code, SupportMods.xaeroMinimap.getTempWaypointKeyBinding()) && WorldMap.settings.waypoints) {
               this.closeRightClick();
               SupportMods.xaeroMinimap.createTempWaypoint(waypointDestinationX, waypointDestinationY + 1, waypointDestinationZ);
               result = true;
            }
         }

         Waypoint hoverTarget = this.getHoverTarget();
         if (hoverTarget != null && !mouse && !Misc.inputMatchesKeyBinding(mouse, code, ControlsRegister.keyOpenMap)) {
            boolean isValid = hoverTarget.isRightClickValid();
            if (isValid) {
               switch(code) {
               case 18:
                  SupportMods.xaeroMinimap.openWaypoint(this, hoverTarget);
                  this.closeRightClick();
                  result = true;
                  break;
               case 20:
                  SupportMods.xaeroMinimap.teleportToWaypoint(this, hoverTarget);
                  this.closeRightClick();
                  result = true;
               }
            } else {
               this.closeRightClick();
            }
         }

         return result;
      } else {
         return false;
      }
   }

   private Waypoint getHoverTarget() {
      return this.rightClickMenu != null && this.rightClickMenu.getTarget() instanceof Waypoint ? (Waypoint)this.rightClickMenu.getTarget() : this.viewed;
   }

   private void unfocusAll() {
      if (this.getFocused() != null) {
         this.getFocused().func_146195_b(false);
      }

      this.setFocused((GuiTextField)null);
   }

   public void closeRightClick() {
      if (this.rightClickMenu != null) {
         this.rightClickMenu.setClosed(true);
      }

   }

   public void onRightClickClosed(GuiRightClickMenu rightClickMenu) {
      this.dropdownsToRemove.add(rightClickMenu);
      this.rightClickMenu = null;
   }

   private void closeDropdowns() {
      Iterator var1 = this.dropdowns.iterator();

      while(var1.hasNext()) {
         GuiDropDown dd = (GuiDropDown)var1.next();
         dd.setClosed(true);
      }

   }

   public ArrayList<RightClickOption> getRightClickOptions() {
      ArrayList<RightClickOption> options = new ArrayList();
      options.add(new RightClickOption("gui.xaero_right_click_map_title", options.size(), this) {
         public void onAction(GuiScreen screen) {
         }
      });
      if (!SupportMods.minimap() || !SupportMods.xaeroMinimap.hidingWaypointCoordinates()) {
         options.add(new RightClickOption(String.format(this.rightClickY != -1 ? "X: %1$d, Y: %2$d, Z: %3$d" : "X: %1$d, Z: %3$d", this.rightClickX, this.rightClickY, this.rightClickZ), options.size(), this) {
            public void onAction(GuiScreen screen) {
            }
         });
      }

      if (SupportMods.minimap()) {
         if (this.rightClickY != -1) {
            if (WorldMap.settings.waypoints) {
               options.add((new RightClickOption("gui.xaero_right_click_map_create_waypoint", options.size(), this) {
                  public void onAction(GuiScreen screen) {
                     SupportMods.xaeroMinimap.createWaypoint(GuiMap.this, GuiMap.this.rightClickX, GuiMap.this.rightClickY + 1, GuiMap.this.rightClickZ);
                  }
               }).setNameFormatArgs(new Object[]{Misc.getKeyName(SupportMods.xaeroMinimap.getWaypointKeyBinding())}));
               options.add((new RightClickOption("gui.xaero_right_click_map_create_temporary_waypoint", options.size(), this) {
                  public void onAction(GuiScreen screen) {
                     SupportMods.xaeroMinimap.createTempWaypoint(GuiMap.this.rightClickX, GuiMap.this.rightClickY + 1, GuiMap.this.rightClickZ);
                  }
               }).setNameFormatArgs(new Object[]{Misc.getKeyName(SupportMods.xaeroMinimap.getTempWaypointKeyBinding())}));
            }

            options.add(new RightClickOption("gui.xaero_right_click_map_teleport", options.size(), this) {
               public void onAction(GuiScreen screen) {
                  SupportMods.xaeroMinimap.teleportToCoordinates(GuiMap.this, GuiMap.this.rightClickX, GuiMap.this.rightClickY + 1, GuiMap.this.rightClickZ);
               }
            });
         }

         if (WorldMap.settings.waypoints) {
            options.add((new RightClickOption("gui.xaero_right_click_map_waypoints_menu", options.size(), this) {
               public void onAction(GuiScreen screen) {
                  SupportMods.xaeroMinimap.openWaypointsMenu(GuiMap.this.field_146297_k, GuiMap.this);
               }
            }).setNameFormatArgs(new Object[]{Misc.getKeyName(SupportMods.xaeroMinimap.getTempWaypointsMenuKeyBinding())}));
         }
      }

      options.add(new RightClickOption("gui.xaero_right_click_box_map_export", options.size(), this) {
         public void onAction(GuiScreen screen) {
            GuiMap.this.onExportButton(GuiMap.this.exportButton);
         }
      });
      options.add((new RightClickOption("gui.xaero_right_click_box_map_settings", options.size(), this) {
         public void onAction(GuiScreen screen) {
            GuiMap.this.onSettingsButton(GuiMap.this.settingsButton);
         }
      }).setNameFormatArgs(new Object[]{Misc.getKeyName(ControlsRegister.keyOpenSettings)}));
      return options;
   }

   public boolean isRightClickValid() {
      return true;
   }

   public int getRightClickTitleBackgroundColor() {
      return -10461088;
   }

   public GuiTextField getFocused() {
      return this.focusedField;
   }

   public void setFocused(GuiTextField field) {
      this.focusedField = field;
   }

   public boolean shouldSkipWorldRender() {
      return true;
   }

   static {
      TEX_2F_1 = new VertexFormatElement(1, EnumType.FLOAT, EnumUsage.UV, 2);
      TEX_2F_2 = new VertexFormatElement(2, EnumType.FLOAT, EnumUsage.UV, 2);
      TEX_2F_3 = new VertexFormatElement(3, EnumType.FLOAT, EnumUsage.UV, 2);
      POSITION_TEX_TEX_TEX.func_181721_a(DefaultVertexFormats.field_181713_m).func_181721_a(DefaultVertexFormats.field_181715_o).func_181721_a(TEX_2F_1).func_181721_a(TEX_2F_2).func_181721_a(TEX_2F_3);
      lastAmountOfRegionsViewed = 1;
      destScale = 3.0D;
      primaryScaleFBO = null;
   }
}
