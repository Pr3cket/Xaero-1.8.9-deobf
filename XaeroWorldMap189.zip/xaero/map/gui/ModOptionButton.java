package xaero.map.gui;

import net.minecraft.client.gui.GuiButton;
import xaero.map.settings.ModOptions;

public class ModOptionButton extends GuiButton implements ModOptionWidget {
   private final ModOptions modOption;

   public ModOptionButton(ModOptions modOption, int id, int p_i51132_1_, int p_i51132_2_, int w, int h, String p_i51132_6_) {
      super(id, p_i51132_1_, p_i51132_2_, w, h, p_i51132_6_);
      this.modOption = modOption;
   }

   public ModOptions getModOption() {
      return this.modOption;
   }

   public CursorBox getTooltip() {
      ModOptions modOptions = this.getModOption();
      return modOptions == null ? null : modOptions.getTooltip();
   }
}
