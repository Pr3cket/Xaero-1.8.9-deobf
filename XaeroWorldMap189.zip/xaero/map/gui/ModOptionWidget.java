package xaero.map.gui;

import xaero.map.settings.ModOptions;

public interface ModOptionWidget extends ICanTooltip {
   ModOptions getModOption();

   CursorBox getTooltip();
}
