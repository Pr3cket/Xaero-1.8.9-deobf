package xaero.map.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;

public class GuiDropDown extends Gui {
   public static final int DEFAULT_BACKGROUND = -939524096;
   public static final int SELECTED_DEFAULT_BACKGROUND = -922757376;
   public static final int SELECTED_DEFAULT_HOVERED_BACKGROUND = -10496;
   public static final int trim = -6250336;
   public static final int trimOpen = -1;
   public static final int trimInside = -13487566;
   protected static final int h = 11;
   private int x;
   private int y;
   private int xOffset;
   private int yOffset;
   private int w;
   private String[] realOptions;
   private String[] options;
   protected int selected;
   private boolean closed;
   private int scroll;
   private long scrollTime;
   private int autoScrolling;
   protected boolean openingUp;
   private IDropDownCallback callback;
   private boolean hasEmptyOption;
   protected int selectedBackground;
   protected int selectedHoveredBackground;
   protected boolean shortenFromTheRight;

   public GuiDropDown(String[] options, int x, int y, int w, Integer selected, IDropDownCallback callback) {
      this(options, x, y, w, selected, callback, true);
   }

   public GuiDropDown(String[] options, int x, int y, int w, Integer selected, IDropDownCallback callback, boolean hasEmptyOption) {
      this(options, x, y, w, selected, false, callback, hasEmptyOption);
   }

   public GuiDropDown(String[] options, int x, int y, int w, Integer selected, boolean openingUp, IDropDownCallback callback, boolean hasEmptyOption) {
      this.xOffset = 0;
      this.yOffset = 0;
      this.realOptions = new String[0];
      this.options = new String[0];
      this.selected = 0;
      this.closed = true;
      this.x = x;
      this.y = y + (openingUp ? 11 : 0);
      this.w = w;
      this.realOptions = options;
      this.callback = callback;
      int emptyOptionCount = hasEmptyOption ? 1 : 0;
      this.options = new String[this.realOptions.length + emptyOptionCount];
      System.arraycopy(this.realOptions, 0, this.options, emptyOptionCount, this.realOptions.length);
      this.selectId(selected, false);
      this.openingUp = openingUp;
      this.hasEmptyOption = hasEmptyOption;
      this.selectedBackground = -922757376;
      this.selectedHoveredBackground = -10496;
   }

   public int size() {
      return this.realOptions.length;
   }

   public int getXWithOffset() {
      return this.x + this.xOffset;
   }

   public int getYWithOffset() {
      return this.y + this.yOffset;
   }

   private void drawSlot(String text, int slotIndex, int pos, int mouseX, int mouseY, boolean scrolling, int optionLimit, int xWithOffset, int yWithOffset) {
      int emptyOptionCount = this.hasEmptyOption ? 1 : 0;
      int slotBackground;
      if (this.closed && this.onDropDown(mouseX, mouseY, scrolling, optionLimit) || !this.closed && this.onDropDownSlot(mouseX, mouseY, slotIndex, scrolling, optionLimit)) {
         slotBackground = slotIndex - emptyOptionCount == this.selected ? this.selectedHoveredBackground : -13487566;
      } else {
         slotBackground = slotIndex - emptyOptionCount == this.selected ? this.selectedBackground : -939524096;
      }

      if (this.openingUp) {
         pos = -pos - 1;
      }

      func_73734_a(xWithOffset, yWithOffset + 11 * pos, xWithOffset + this.w, yWithOffset + 11 + 11 * pos, slotBackground);
      this.func_73730_a(xWithOffset + 1, xWithOffset + this.w - 1, yWithOffset + 11 * pos, -13487566);
      int textWidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(text);

      boolean shortened;
      for(shortened = false; textWidth > this.w - 2; shortened = true) {
         text = this.shortenFromTheRight ? text.substring(0, text.length() - 1) : text.substring(1);
         textWidth = Minecraft.func_71410_x().field_71466_p.func_78256_a("..." + text);
      }

      if (shortened) {
         if (this.shortenFromTheRight) {
            text = text + "...";
         } else {
            text = "..." + text;
         }
      }

      int textColor = 16777215;
      int var10003 = xWithOffset + this.w / 2;
      this.func_73732_a(Minecraft.func_71410_x().field_71466_p, text, var10003, yWithOffset + 2 + 11 * pos, textColor);
   }

   private void drawMenu(int amount, int mouseX, int mouseY, int scaledHeight, int optionLimit) {
      boolean scrolling = this.scrolling(optionLimit);
      int totalH = 11 * (amount + (scrolling ? 2 : 0));
      if (!this.openingUp && this.y + totalH + 1 > scaledHeight) {
         this.yOffset = scaledHeight - this.y - totalH - 1;
      } else if (this.openingUp && this.y - totalH < 0) {
         this.yOffset = totalH - this.y;
      } else {
         this.yOffset = 0;
      }

      int xWithOffset = this.getXWithOffset();
      int yWithOffset = this.getYWithOffset();
      int first = this.closed ? 0 : this.scroll;
      if (scrolling) {
         this.drawSlot((this.scroll == 0 ? "§8" : "§7") + I18n.func_135052_a(this.openingUp ? "gui.xaero_down" : "gui.xaero_up", new Object[0]), -1, 0, mouseX, mouseY, scrolling, optionLimit, xWithOffset, yWithOffset);
         this.drawSlot((this.scroll + optionLimit >= this.options.length ? "§8" : "§7") + I18n.func_135052_a(this.openingUp ? "gui.xaero_up" : "gui.xaero_down", new Object[0]), -2, amount + 1, mouseX, mouseY, scrolling, optionLimit, xWithOffset, yWithOffset);
      }

      int i;
      for(i = first; i < first + amount; ++i) {
         String slotText;
         if (this.hasEmptyOption && i == 0) {
            slotText = !this.closed ? "-" : I18n.func_135052_a(this.realOptions[this.selected], new Object[0]).replace("§§", ":");
         } else {
            slotText = I18n.func_135052_a(this.options[i], new Object[0]).replace("§§", ":");
         }

         this.drawSlot(slotText, i, i - first + (scrolling ? 1 : 0), mouseX, mouseY, scrolling, optionLimit, xWithOffset, yWithOffset);
      }

      i = yWithOffset - (this.openingUp ? totalH : 0);
      int trim = this.closed ? -6250336 : -1;
      this.func_73728_b(xWithOffset, i, i + totalH, trim);
      this.func_73728_b(xWithOffset + this.w, i, i + totalH, trim);
      this.func_73730_a(xWithOffset, xWithOffset + this.w, i, trim);
      this.func_73730_a(xWithOffset, xWithOffset + this.w, i + totalH, trim);
   }

   private boolean scrolling(int optionLimit) {
      return this.options.length > optionLimit && !this.closed;
   }

   public void mouseClicked(int mouseX, int mouseY, int mouseButton, int scaledHeight) {
      if (mouseButton == 0) {
         if (!this.closed) {
            int optionLimit = this.optionLimit(scaledHeight);
            int clickedId = this.getHoveredId(mouseX, mouseY, this.scrolling(optionLimit), optionLimit);
            if (clickedId >= 0) {
               this.selectId(clickedId - (this.hasEmptyOption ? 1 : 0), true);
            } else {
               this.autoScrolling = clickedId == -1 ? 1 : -1;
               this.scrollTime = System.currentTimeMillis();
               this.mouseScrolledInternal(this.autoScrolling, mouseX, mouseY, optionLimit);
            }

            Minecraft.func_71410_x().func_147118_V().func_147682_a(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0F));
         } else if (this.options.length > 1) {
            this.setClosed(false);
            this.scroll = 0;
         }

      }
   }

   public void mouseReleased(int mouseX, int mouseY, int mouseButton, int scaledHeight) {
      this.autoScrolling = 0;
   }

   private int getHoveredId(int mouseX, int mouseY, boolean scrolling, int optionLimit) {
      int yOnMenu = mouseY - this.getYWithOffset();
      int visibleSlotIndex = (this.openingUp ? -yOnMenu - 1 : yOnMenu) / 11;
      if (scrolling && visibleSlotIndex == 0) {
         return -1;
      } else if (visibleSlotIndex >= optionLimit + (scrolling ? 1 : 0)) {
         return -2;
      } else {
         int slot = this.scroll + visibleSlotIndex - (scrolling ? 1 : 0);
         if (slot >= this.options.length) {
            slot = this.options.length - 1;
         }

         return slot;
      }
   }

   public boolean onDropDown(int mouseX, int mouseY, int scaledHeight) {
      int optionLimit = this.optionLimit(scaledHeight);
      return this.onDropDown(mouseX, mouseY, this.scrolling(optionLimit), optionLimit);
   }

   public boolean onDropDown(int mouseX, int mouseY, boolean scrolling, int optionLimit) {
      int menuTop = this.getYWithOffset();
      int menuHeight = this.closed ? 11 : (Math.min(this.options.length, optionLimit) + (scrolling ? 2 : 0)) * 11;
      if (this.openingUp) {
         menuTop -= menuHeight;
      }

      int xOnMenu = mouseX - this.getXWithOffset();
      int yOnMenu = mouseY - menuTop;
      return xOnMenu >= 0 && yOnMenu >= 0 && xOnMenu <= this.w && yOnMenu < menuHeight;
   }

   private boolean onDropDownSlot(int mouseX, int mouseY, int id, boolean scrolling, int optionLimit) {
      if (!this.onDropDown(mouseX, mouseY, scrolling, optionLimit)) {
         return false;
      } else {
         int hoveredSlot = this.getHoveredId(mouseX, mouseY, scrolling, optionLimit);
         return hoveredSlot == id;
      }
   }

   public void selectId(int id, boolean callCallback) {
      if (id == -1) {
         this.setClosed(true);
      } else {
         boolean newId = id != this.selected;
         if (newId && (!callCallback || this.callback.onSelected(this, id))) {
            this.selected = id;
         }

         this.setClosed(true);
      }
   }

   public void drawButton(int mouseX, int mouseY, int scaledHeight) {
      int optionLimit = this.optionLimit(scaledHeight);
      if (this.autoScrolling != 0 && System.currentTimeMillis() - this.scrollTime > 100L) {
         this.scrollTime = System.currentTimeMillis();
         this.mouseScrolledInternal(this.autoScrolling, mouseX, mouseY, optionLimit);
      }

      this.drawMenu(this.closed ? 1 : Math.min(optionLimit, this.options.length), mouseX, mouseY, scaledHeight, optionLimit);
   }

   public boolean isClosed() {
      return this.closed;
   }

   public void setClosed(boolean closed) {
      if (!closed && this.closed) {
         Minecraft.func_71410_x().func_147118_V().func_147682_a(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0F));
      }

      this.closed = closed;
   }

   public void mouseScrolled(int wheel, int mouseXScaled, int mouseYScaled, int scaledHeight) {
      this.mouseScrolledInternal(wheel * (this.openingUp ? -1 : 1), mouseXScaled, mouseYScaled, this.optionLimit(scaledHeight));
   }

   private void mouseScrolledInternal(int wheel, int mouseXScaled, int mouseYScaled, int optionLimit) {
      int newScroll = this.scroll - wheel;
      if (newScroll + optionLimit > this.options.length) {
         newScroll = this.options.length - optionLimit;
      }

      if (newScroll < 0) {
         newScroll = 0;
      }

      this.scroll = newScroll;
   }

   private int optionLimit(int scaledHeight) {
      return Math.max(1, scaledHeight / 11 - 2);
   }

   public int getSelected() {
      return this.selected;
   }
}
