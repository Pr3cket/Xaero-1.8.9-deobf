package xaero.map.gui;

import net.minecraft.client.gui.GuiButton;

public class TooltipButton extends GuiButton implements ICanTooltip {
   protected CursorBox tooltip;

   public TooltipButton(int p_i232256_1_, int p_i232256_2_, int p_i232256_3_, int p_i232256_4_, String p_i232256_5_, CursorBox tooltip) {
      super(-1, p_i232256_1_, p_i232256_2_, p_i232256_3_, p_i232256_4_, p_i232256_5_);
      this.tooltip = tooltip;
   }

   public CursorBox getTooltip() {
      return this.tooltip;
   }
}
