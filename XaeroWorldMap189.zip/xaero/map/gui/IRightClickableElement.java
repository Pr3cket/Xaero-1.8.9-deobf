package xaero.map.gui;

import java.util.ArrayList;

public interface IRightClickableElement {
   ArrayList<RightClickOption> getRightClickOptions();

   boolean isRightClickValid();

   int getRightClickTitleBackgroundColor();
}
