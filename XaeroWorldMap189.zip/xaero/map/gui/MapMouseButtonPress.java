package xaero.map.gui;

public class MapMouseButtonPress {
   public boolean isDown;
   public boolean clicked;
   public int pressedAtX = -1;
   public int pressedAtY = -1;
}
