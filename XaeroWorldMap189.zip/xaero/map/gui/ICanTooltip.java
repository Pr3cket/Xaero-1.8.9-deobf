package xaero.map.gui;

import javax.annotation.Nullable;

public interface ICanTooltip {
   @Nullable
   CursorBox getTooltip();
}
