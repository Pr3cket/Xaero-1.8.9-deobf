package xaero.map.gui;

import net.minecraft.client.gui.GuiYesNoCallback;

public abstract class YesNoCallbackImplementation implements GuiYesNoCallback {
   public abstract void func_73878_a(boolean var1, int var2);
}
