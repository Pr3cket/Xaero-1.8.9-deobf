package xaero.map.gui;

import java.util.ArrayList;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.client.gui.GuiScreen;

public class GuiRightClickMenu extends GuiDropDown {
   private IRightClickableElement target;
   private Consumer<GuiRightClickMenu> closedCallback;
   private ArrayList<RightClickOption> actionOptions;
   private GuiScreen screen;
   private boolean removed;

   private GuiRightClickMenu(IRightClickableElement target, ArrayList<RightClickOption> options, GuiScreen screen, int x, int y, int w, int titleBackgroundColor, Consumer<GuiRightClickMenu> closedCallback) {
      super(convertOptions(options), x - (shouldOpenLeft(options.size(), x, w, screen.field_146294_l) ? w : 0), y, w, -1, false, (IDropDownCallback)null, false);
      this.openingUp = false;
      this.target = target;
      this.screen = screen;
      this.closedCallback = closedCallback;
      this.setClosed(false);
      this.actionOptions = options;
      this.selectedBackground = this.selectedHoveredBackground = titleBackgroundColor;
      this.shortenFromTheRight = true;
   }

   private static boolean shouldOpenLeft(int optionCount, int x, int w, int screenWidth) {
      return x + w - screenWidth > 0;
   }

   private static boolean shouldOpenUp(int optionCount, int y, int screenHeight) {
      int potentialHeight = 11 * optionCount;
      return y + potentialHeight - screenHeight > potentialHeight / 2;
   }

   public void setClosed(boolean closed) {
      if (!this.isClosed() && closed) {
         this.removed = true;
         this.closedCallback.accept(this);
      }

      super.setClosed(closed);
   }

   public void selectId(int id, boolean callCallback) {
      if (id != -1) {
         if (!this.removed) {
            ((RightClickOption)this.actionOptions.get(id)).onSelected(this.screen);
            this.setClosed(true);
         }
      }
   }

   public static GuiRightClickMenu getMenu(IRightClickableElement rightClickable, GuiScreen screen, int x, int y, int w, Consumer<GuiRightClickMenu> closedCallback) {
      return new GuiRightClickMenu(rightClickable, rightClickable.getRightClickOptions(), screen, x, y, w, rightClickable.getRightClickTitleBackgroundColor(), closedCallback);
   }

   public IRightClickableElement getTarget() {
      return this.target;
   }

   private static String[] convertOptions(ArrayList<RightClickOption> options) {
      Supplier<ArrayList<Object>> factory = new Supplier<ArrayList<Object>>() {
         public ArrayList<Object> get() {
            return new ArrayList();
         }
      };
      BiConsumer<ArrayList<Object>, Object> accumulator = new BiConsumer<ArrayList<Object>, Object>() {
         public void accept(ArrayList<Object> t, Object u) {
            t.add(u);
         }
      };
      BiConsumer<ArrayList<Object>, ArrayList<Object>> combiner = new BiConsumer<ArrayList<Object>, ArrayList<Object>>() {
         public void accept(ArrayList<Object> t, ArrayList<Object> u) {
            t.addAll(u);
         }
      };
      return (String[])((ArrayList)options.stream().map(new Function<RightClickOption, Object>() {
         public Object apply(RightClickOption o) {
            return o.getDisplayName();
         }
      }).collect(factory, accumulator, combiner)).toArray(new String[0]);
   }
}
