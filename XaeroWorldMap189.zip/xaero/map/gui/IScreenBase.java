package xaero.map.gui;

public interface IScreenBase {
   boolean shouldSkipWorldRender();
}
