package xaero.map.gui;

import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class GuiTexturedButton extends GuiActionButton {
   protected int textureX;
   protected int textureY;
   protected int textureW;
   protected int textureH;
   protected ResourceLocation texture;

   public GuiTexturedButton(int x, int y, int w, int h, int textureX, int textureY, int textureW, int textureH, ResourceLocation texture, Consumer<GuiButton> action, CursorBox tooltip) {
      super(x, y, w, h, "", tooltip, action);
      this.textureX = textureX;
      this.textureY = textureY;
      this.textureW = textureW;
      this.textureH = textureH;
      this.texture = texture;
   }

   public void func_146112_a(Minecraft mc, int mouseX, int mouseY) {
      Minecraft.func_71410_x().func_110434_K().func_110577_a(this.texture);
      int iconX = this.field_146128_h + this.field_146120_f / 2 - this.textureW / 2;
      int iconY = this.field_146129_i + this.field_146121_g / 2 - this.textureH / 2;
      if (this.field_146124_l) {
         if (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g) {
            --iconY;
            GlStateManager.func_179131_c(0.9F, 0.9F, 0.9F, 1.0F);
         } else {
            GlStateManager.func_179131_c(0.9882F, 0.9882F, 0.9882F, 1.0F);
         }
      } else {
         GlStateManager.func_179131_c(0.25F, 0.25F, 0.25F, 1.0F);
      }

      this.func_73729_b(iconX, iconY, this.textureX, this.textureY, this.textureW, this.textureH);
   }
}
