package xaero.map.gui;

public interface IDropDownCallback {
   boolean onSelected(GuiDropDown var1, int var2);
}
