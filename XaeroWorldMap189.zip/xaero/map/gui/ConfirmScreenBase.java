package xaero.map.gui;

import java.io.IOException;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.renderer.GlStateManager;
import xaero.map.misc.Misc;

public class ConfirmScreenBase extends GuiYesNo implements IScreenBase {
   public GuiScreen parent;
   public GuiScreen escape;
   private boolean renderEscapeInBackground;
   protected boolean canSkipWorldRender;

   public ConfirmScreenBase(GuiScreen parent, GuiScreen escape, boolean renderEscapeInBackground, GuiYesNoCallback parentScreenIn, String messageLine1In, String messageLine2In, int parentButtonClickedIdIn) {
      super(parentScreenIn, messageLine1In, messageLine2In, parentButtonClickedIdIn);
      this.parent = parent;
      this.escape = escape;
      this.renderEscapeInBackground = renderEscapeInBackground;
      this.canSkipWorldRender = true;
   }

   public ConfirmScreenBase(GuiScreen parent, GuiScreen escape, boolean renderEscapeInBackground, GuiYesNoCallback parentScreenIn, String messageLine1In, String messageLine2In, String confirmButtonTextIn, String cancelButtonTextIn, int parentButtonClickedIdIn) {
      super(parentScreenIn, messageLine1In, messageLine2In, confirmButtonTextIn, cancelButtonTextIn, parentButtonClickedIdIn);
      this.parent = parent;
      this.escape = escape;
      this.renderEscapeInBackground = renderEscapeInBackground;
      this.canSkipWorldRender = true;
   }

   protected void onExit(GuiScreen screen) {
      this.field_146297_k.func_147108_a(screen);
   }

   protected void goBack() {
      this.onExit(this.parent);
   }

   protected void func_73869_a(char typedChar, int keyCode) throws IOException {
      if (keyCode == 1) {
         this.onClose();
         if (this.field_146297_k.field_71462_r == null) {
            this.field_146297_k.func_71381_h();
         }
      }

   }

   public void onClose() {
      this.onExit(this.escape);
   }

   public void renderEscapeScreen(int p_230430_2_, int p_230430_3_, float p_230430_4_) {
      if (this.escape != null) {
         this.escape.func_73863_a(p_230430_2_, p_230430_3_, p_230430_4_);
      }

      GlStateManager.func_179086_m(256);
   }

   public void func_73863_a(int p_230430_2_, int p_230430_3_, float p_230430_4_) {
      if (this.renderEscapeInBackground) {
         this.renderEscapeScreen(p_230430_2_, p_230430_3_, p_230430_4_);
      }

      super.func_73863_a(p_230430_2_, p_230430_3_, p_230430_4_);
   }

   public void func_146280_a(Minecraft p_231158_1_, int p_231158_2_, int p_231158_3_) {
      super.func_146280_a(p_231158_1_, p_231158_2_, p_231158_3_);
      if (this.escape != null) {
         this.escape.func_146280_a(p_231158_1_, p_231158_2_, p_231158_3_);
      }

   }

   public boolean shouldSkipWorldRender() {
      return this.canSkipWorldRender && this.renderEscapeInBackground && Misc.screenShouldSkipWorldRender(this.escape, true);
   }

   public List<GuiButton> getButtonList() {
      return this.field_146292_n;
   }
}
