package xaero.map.gui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.resources.I18n;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.misc.KeySortableByOther;
import xaero.map.world.MapDimension;
import xaero.map.world.MapWorld;

public class GuiMapSwitching {
   private MapProcessor mapProcessor;
   private MapDimension settingsDimension;
   private String[] mwDropdownValues;
   private GuiButton switchingButton;
   private GuiButton multiworldTypeOptionButton;
   private GuiButton renameButton;
   private GuiButton deleteButton;
   private CursorBox serverSelectionModeBox = new CursorBox("gui.xaero_mw_server_box");
   private CursorBox mapSelectionBox = new CursorBox("gui.xaero_map_selection_box");
   public boolean active;
   private boolean writableOnInit;

   public GuiMapSwitching(MapProcessor mapProcessor) {
      this.mapProcessor = mapProcessor;
      this.mapSelectionBox.setBoxWidth(200);
      this.serverSelectionModeBox.setBoxWidth(200);
   }

   public void init(final GuiMap mapScreen, List<GuiDropDown> dropdowns, final Minecraft minecraft, int width, int height) {
      this.multiworldTypeOptionButton = null;
      MapWorld mapWorld = this.mapProcessor.getMapWorld();
      this.settingsDimension = mapWorld != null && mapWorld.getCurrentDimensionId() != null ? mapWorld.getCurrentDimension() : null;
      if (this.settingsDimension != null && mapWorld.isMultiplayer()) {
         this.writableOnInit = this.settingsDimension.futureMultiworldWritable;
         mapScreen.addGuiButton(this.switchingButton = new GuiMapSwitchingButton(this.active, 0, height - 20));
         if (this.active) {
            String currentMultiworld = this.settingsDimension.getFutureMultiworldUnsynced();
            List<KeySortableByOther<String>> sortableList = new ArrayList();
            Iterator var9 = this.settingsDimension.getMultiworldIdsCopy().iterator();

            while(var9.hasNext()) {
               String mwId = (String)var9.next();
               sortableList.add(new KeySortableByOther(mwId, new Comparable[]{this.settingsDimension.getMultiworldName(mwId).toLowerCase()}));
            }

            Collections.sort(sortableList);
            List<String> dropdownValuesList = new ArrayList();
            Iterator var15 = sortableList.iterator();

            while(var15.hasNext()) {
               KeySortableByOther<String> sortableKey = (KeySortableByOther)var15.next();
               dropdownValuesList.add(sortableKey.getKey());
            }

            int selected = this.getDropdownSelectionIdFromValue(dropdownValuesList, currentMultiworld);
            if (selected == dropdownValuesList.size()) {
               dropdownValuesList.add(currentMultiworld);
            }

            this.mwDropdownValues = (String[])dropdownValuesList.toArray(new String[0]);
            List<String> mwDropdownNames = new ArrayList();
            Iterator var12 = dropdownValuesList.iterator();

            while(var12.hasNext()) {
               String s = (String)var12.next();
               mwDropdownNames.add(this.settingsDimension.getMultiworldName(s));
            }

            if (this.settingsDimension.getMapWorld().isMultiplayer()) {
               mwDropdownNames.add("§8" + I18n.func_135052_a("gui.xaero_create_new_map", new Object[0]));
            }

            GuiDropDown createdDropdown = new GuiDropDown((String[])mwDropdownNames.toArray(new String[0]), width / 2 - 100, 30, 200, selected, new IDropDownCallback() {
               public boolean onSelected(GuiDropDown dd, int i) {
                  if (i < GuiMapSwitching.this.mwDropdownValues.length) {
                     GuiMapSwitching.this.mapProcessor.setMultiworld(GuiMapSwitching.this.settingsDimension, GuiMapSwitching.this.mwDropdownValues[i]);
                     GuiMapSwitching.this.updateButtons();
                     return true;
                  } else {
                     minecraft.func_147108_a(new GuiMapName(GuiMapSwitching.this.mapProcessor, mapScreen, mapScreen, GuiMapSwitching.this.settingsDimension, (String)null));
                     return false;
                  }
               }
            });
            dropdowns.add(createdDropdown);
            mapScreen.addGuiButton(this.multiworldTypeOptionButton = new TooltipButton(0, height - 45, 150, 20, this.getMultiworldTypeButtonMessage(), this.settingsDimension.isFutureMultiworldServerBased() ? this.serverSelectionModeBox : this.mapSelectionBox));
            mapScreen.addGuiButton(this.renameButton = new GuiButton(-1, width / 2 + 109, 26, 60, 20, I18n.func_135052_a("gui.xaero_rename", new Object[0])));
            mapScreen.addGuiButton(this.deleteButton = new GuiButton(-1, width / 2 - 168, 26, 60, 20, I18n.func_135052_a("gui.xaero_delete", new Object[0])));
            this.updateButtons();
            this.multiworldTypeOptionButton.field_146124_l = this.isMapSelectionOptionEnabled();
            this.renameButton.field_146124_l = this.settingsDimension.getMapWorld().isMultiplayer();
            mapScreen.addGuiButton(new GuiButton(200, width / 2 - 50, 50, 100, 20, I18n.func_135052_a("gui.xaero_confirm", new Object[0])));
         }
      }

   }

   private boolean isMapSelectionOptionEnabled() {
      return !this.settingsDimension.isFutureMultiworldServerBased() && this.settingsDimension.getMapWorld().isMultiplayer();
   }

   private void updateButtons() {
      this.switchingButton.field_146124_l = this.settingsDimension != null && this.settingsDimension.futureMultiworldWritable;
      this.deleteButton.field_146124_l = this.settingsDimension.getMapWorld().isMultiplayer() && this.mwDropdownValues.length > 1 && this.settingsDimension.getFutureCustomSelectedMultiworld() != null;
   }

   private String getMultiworldTypeButtonMessage() {
      int multiworldType = this.settingsDimension.getMapWorld().getFutureMultiworldType(this.settingsDimension);
      return I18n.func_135052_a("gui.xaero_map_selection", new Object[0]) + ": " + I18n.func_135052_a(this.settingsDimension.isFutureMultiworldServerBased() ? "gui.xaero_mw_server" : (multiworldType == 0 ? "gui.xaero_mw_single" : (multiworldType == 1 ? "gui.xaero_mw_manual" : "gui.xaero_mw_spawn")), new Object[0]);
   }

   public void confirm(GuiMap mapScreen, Minecraft minecraft, int width, int height) {
      if (this.mapProcessor.confirmMultiworld(this.settingsDimension)) {
         this.active = false;
         mapScreen.func_146280_a(minecraft, width, height);
      }

   }

   private int getDropdownSelectionIdFromValue(List<String> values, String value) {
      int selected = false;

      int selected;
      for(selected = 0; selected < values.size() && !((String)values.get(selected)).equals(value); ++selected) {
      }

      return selected;
   }

   public void preMapRender(GuiMap mapScreen, List<GuiDropDown> dropdowns, Minecraft minecraft, int width, int height) {
      MapDimension currentDim = !this.mapProcessor.isMapWorldUsable() ? null : this.mapProcessor.getMapWorld().getCurrentDimension();
      if (currentDim != this.settingsDimension) {
         this.active = false;
         mapScreen.func_146280_a(minecraft, width, height);
      }

      if (!this.active && this.settingsDimension != null && !this.settingsDimension.futureMultiworldWritable) {
         this.active = true;
         mapScreen.func_146280_a(minecraft, width, height);
      }

      if (this.active && this.settingsDimension != null && ((GuiDropDown)dropdowns.get(0)).isClosed()) {
         String currentMultiworld = this.settingsDimension.getFutureMultiworldUnsynced();
         String currentDropdownSelection = this.mwDropdownValues[((GuiDropDown)dropdowns.get(0)).getSelected()];
         if (!currentMultiworld.equals(currentDropdownSelection) || this.writableOnInit != this.settingsDimension.futureMultiworldWritable) {
            mapScreen.func_146280_a(minecraft, width, height);
         }
      }

   }

   public void renderText(Minecraft minecraft, int mouseX, int mouseY, int width, int height) {
      if (this.active) {
         String selectMapString = I18n.func_135052_a("gui.xaero_select_map", new Object[0]) + ":";
         minecraft.field_71466_p.func_175063_a(selectMapString, (float)(width / 2 - minecraft.field_71466_p.func_78256_a(selectMapString) / 2), 19.0F, -1);
      }
   }

   public void postMapRender(Minecraft minecraft, int mouseX, int mouseY, int width, int height) {
   }

   public void actionPerformed(final GuiMap mapScreen, final Minecraft minecraft, final int width, final int height, GuiButton b) {
      if (b.field_146124_l) {
         if (b == this.switchingButton) {
            this.active = !this.active;
            mapScreen.func_146280_a(minecraft, width, height);
         } else if (b == this.multiworldTypeOptionButton) {
            if (this.isMapSelectionOptionEnabled()) {
               this.mapProcessor.toggleMultiworldType(this.settingsDimension);
               b.field_146126_j = this.getMultiworldTypeButtonMessage();
            }
         } else if (b == this.renameButton) {
            minecraft.func_147108_a(new GuiMapName(this.mapProcessor, mapScreen, mapScreen, this.settingsDimension, this.settingsDimension.getFutureMultiworldUnsynced()));
         } else if (b == this.deleteButton) {
            if (this.settingsDimension.getFutureCustomSelectedMultiworld() != null) {
               final String selectedMWId = this.settingsDimension.getFutureCustomSelectedMultiworld();
               minecraft.func_147108_a(new GuiYesNo(new YesNoCallbackImplementation() {
                  public void func_73878_a(boolean result, int id) {
                     if (result) {
                        String mapNameAndIdLine = I18n.func_135052_a("gui.xaero_delete_map_msg4", new Object[0]) + ": " + GuiMapSwitching.this.settingsDimension.getMultiworldName(selectedMWId) + " (" + selectedMWId + ")";
                        minecraft.func_147108_a(new GuiYesNo(new YesNoCallbackImplementation() {
                           public void func_73878_a(boolean result2, int id) {
                              if (result2) {
                                 synchronized(GuiMapSwitching.this.mapProcessor.uiSync) {
                                    if (GuiMapSwitching.this.mapProcessor.getMapWorld() == GuiMapSwitching.this.settingsDimension.getMapWorld()) {
                                       MapDimension currentDimension = !GuiMapSwitching.this.mapProcessor.isMapWorldUsable() ? null : GuiMapSwitching.this.mapProcessor.getMapWorld().getCurrentDimension();
                                       if (GuiMapSwitching.this.settingsDimension == currentDimension && GuiMapSwitching.this.settingsDimension.getCurrentMultiworld().equals(selectedMWId)) {
                                          if (WorldMap.settings.debug) {
                                             System.out.println("Delayed map deletion!");
                                          }

                                          GuiMapSwitching.this.mapProcessor.requestCurrentMapDeletion();
                                       } else {
                                          if (WorldMap.settings.debug) {
                                             System.out.println("Instant map deletion!");
                                          }

                                          GuiMapSwitching.this.settingsDimension.deleteMultiworldMapDataUnsynced(selectedMWId);
                                       }

                                       GuiMapSwitching.this.settingsDimension.deleteMultiworldId(selectedMWId);
                                       GuiMapSwitching.this.settingsDimension.pickDefaultCustomMultiworldUnsynced();
                                       GuiMapSwitching.this.settingsDimension.saveConfigUnsynced();
                                       GuiMapSwitching.this.settingsDimension.futureMultiworldWritable = false;
                                       mapScreen.func_146280_a(minecraft, width, height);
                                    }
                                 }
                              }

                              minecraft.func_147108_a(mapScreen);
                           }
                        }, I18n.func_135052_a("gui.xaero_delete_map_msg3", new Object[0]), mapNameAndIdLine, -1));
                     } else {
                        minecraft.func_147108_a(mapScreen);
                     }

                  }
               }, I18n.func_135052_a("gui.xaero_delete_map_msg1", new Object[0]), I18n.func_135052_a("gui.xaero_delete_map_msg2", new Object[0]), -1));
            }
         } else if (b.field_146127_k == 200) {
            this.confirm(mapScreen, minecraft, width, height);
         }
      }

   }
}
