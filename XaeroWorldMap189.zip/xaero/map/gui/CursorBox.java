package xaero.map.gui;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.resources.I18n;

public class CursorBox {
   private static final int BOX_OFFSET_X = 12;
   private static final int BOX_OFFSET_Y = 10;
   private static final int USUAL_WIDTH = 200;
   private ArrayList<String> strings;
   private String language;
   private String fullCode;
   private String formatting;
   private int boxWidth;
   private static final int color = -939524096;
   private boolean customLines;
   private boolean flippedByDefault;

   public CursorBox(String code) {
      this(code, "");
   }

   public CursorBox(String code, String formatting) {
      this(code, formatting, false);
   }

   public CursorBox(String code, String formatting, boolean flippedByDefault) {
      this.fullCode = "";
      this.boxWidth = 15;
      this.fullCode = code;
      this.formatting = formatting;
      this.flippedByDefault = flippedByDefault;
   }

   public CursorBox(int size) {
      this.fullCode = "";
      this.boxWidth = 15;
      this.strings = new ArrayList();

      for(int i = 0; i < size; ++i) {
         this.strings.add("");
      }

      this.customLines = true;
   }

   public void setBoxWidth(int boxWidth) {
      this.boxWidth = boxWidth;
   }

   private String currentLanguage() {
      return Minecraft.func_71410_x().func_135016_M().func_135041_c().func_135034_a();
   }

   public void createLines(String text) {
      try {
         this.language = this.currentLanguage();
      } catch (NullPointerException var8) {
         this.language = "en_us";
      }

      this.strings = new ArrayList();
      String[] words = text.split(" ");
      int spaceWidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(" ");
      StringBuilder line = new StringBuilder();
      int width = 0;

      for(int i = 0; i < words.length; ++i) {
         int wordWidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(words[i]);
         if (width + spaceWidth + wordWidth <= 185) {
            this.boxWidth = Math.max(this.boxWidth, Math.min(200, width + spaceWidth + wordWidth + 15));
         }

         if (width == 0 && wordWidth > this.boxWidth - 15) {
            this.boxWidth = wordWidth + 15;
         }

         if (!words[i].equals("\\n") && width + wordWidth <= this.boxWidth - 15) {
            width += spaceWidth + wordWidth;
            line.append(words[i]).append(" ");
         } else {
            this.strings.add(this.formatting + line.toString());
            line.delete(0, line.length());
            width = 0;
            if (!words[i].equals("\\n")) {
               --i;
            }
         }

         if (i == words.length - 1) {
            this.strings.add(this.formatting + line.toString());
         }
      }

   }

   public String getString(int line) {
      return (String)this.strings.get(line);
   }

   public void drawBox(int x, int y, int width, int height) {
      try {
         if (!this.customLines && (this.language == null || !this.language.equals(this.currentLanguage()))) {
            this.createLines(I18n.func_135052_a(this.fullCode, new Object[0]));
         }
      } catch (Exception var12) {
      }

      int drawX = x + 12;
      int drawY = y + 10;
      int overEdgeX = drawX + this.boxWidth - width;
      if (!this.flippedByDefault && overEdgeX <= 9) {
         if (overEdgeX > 0) {
            drawX -= overEdgeX;
         }
      } else {
         drawX = x - 12 - this.boxWidth;
      }

      if (drawX < 0) {
         drawX = 0;
      }

      int h = 5 + this.strings.size() * 10 + 5;
      int overEdgeY = drawY + h - height;
      if (overEdgeY > h / 2) {
         drawY = y - 10 - h;
      } else if (overEdgeY > 0) {
         drawY -= overEdgeY;
      }

      if (drawY < 0) {
         drawY = 0;
      }

      Gui.func_73734_a(drawX, drawY, drawX + this.boxWidth, drawY + h, -939524096);

      for(int i = 0; i < this.strings.size(); ++i) {
         String s = this.getString(i);
         Minecraft.func_71410_x().field_71466_p.func_78276_b("§f" + s, drawX + 10, drawY + 5 + 10 * i, 16777215);
      }

   }

   public CursorBox withWidth(int boxWidth) {
      this.boxWidth = boxWidth;
      return this;
   }
}
