package xaero.map.gui;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiButton;

public class GuiActionButton extends TooltipButton {
   private Consumer<GuiButton> action;

   public GuiActionButton(int p_i232256_1_, int p_i232256_2_, int p_i232256_3_, int p_i232256_4_, String p_i232256_5_, CursorBox tooltip, Consumer<GuiButton> action) {
      super(p_i232256_1_, p_i232256_2_, p_i232256_3_, p_i232256_4_, p_i232256_5_, tooltip);
      this.action = action;
   }

   public Consumer<GuiButton> getAction() {
      return this.action;
   }
}
