package xaero.map.biome;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import xaero.map.cache.BlockStateColorTypeCache;

public interface BiomeInfoSupplier {
   void getBiomeInfo(BlockStateColorTypeCache var1, World var2, IBlockState var3, BlockPos var4, int[] var5, int var6);
}
