package xaero.map.biome;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import xaero.map.cache.BlockStateColorTypeCache;
import xaero.map.misc.Misc;
import xaero.map.region.MapBlock;
import xaero.map.region.Overlay;

public class WriterBiomeInfoSupplier implements BiomeInfoSupplier {
   private MapBlock currentPixel;
   private boolean canReuseBiomeColours;
   private BlockPos mutableGlobalPos;

   public WriterBiomeInfoSupplier(BlockPos mutableGlobalPos) {
      this.mutableGlobalPos = mutableGlobalPos;
   }

   public void set(MapBlock currentPixel, boolean canReuseBiomeColours) {
      this.currentPixel = currentPixel;
      this.canReuseBiomeColours = canReuseBiomeColours;
   }

   public void getBiomeInfo(BlockStateColorTypeCache colorTypeCache, World world, IBlockState state, BlockPos pos, int[] biomeBuffer, int blockBiome) {
      MapBlock currentPixel = this.currentPixel;
      if (this.canReuseBiomeColours && currentPixel != null && currentPixel.getNumberOfOverlays() > 0 && Misc.getStateById(((Overlay)currentPixel.getOverlays().get(0)).getState()) == state) {
         Overlay currentTopOverlay = (Overlay)currentPixel.getOverlays().get(0);
         biomeBuffer[0] = currentTopOverlay.getColourType();
         biomeBuffer[1] = currentTopOverlay.getColourType() == 1 ? currentPixel.getBiome() : -1;
         biomeBuffer[2] = currentTopOverlay.getCustomColour();
      } else {
         colorTypeCache.getOverlayBiomeColour(world, state, pos, biomeBuffer, blockBiome);
      }

   }
}
