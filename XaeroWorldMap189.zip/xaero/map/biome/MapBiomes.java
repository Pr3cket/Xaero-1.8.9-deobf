package xaero.map.biome;

import java.util.Random;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.BiomeGenForest;
import net.minecraft.world.biome.BiomeGenMesa;
import net.minecraft.world.biome.BiomeGenSwamp;
import net.minecraft.world.gen.NoiseGeneratorPerlin;

public class MapBiomes {
   protected final NoiseGeneratorPerlin GRASS_COLOR_NOISE = new NoiseGeneratorPerlin(new Random(2345L), 1);

   public int getBiomeGrassColour(int biomeId, BiomeGenBase biome, BlockPos pos) {
      if (this.isVanilla(biomeId)) {
         if (biome instanceof BiomeGenForest) {
            return this.forestGrassColor(biomeId, biome, pos);
         } else if (biome instanceof BiomeGenMesa) {
            return 9470285;
         } else {
            return biome instanceof BiomeGenSwamp ? this.swampGrassColor(pos) : this.defaultGrassColor(biome, pos);
         }
      } else {
         return biome.func_180627_b(pos);
      }
   }

   public int getBiomeFoliageColour(int biomeId, BiomeGenBase biome, BlockPos pos) {
      if (this.isVanilla(biomeId)) {
         if (biome instanceof BiomeGenMesa) {
            return 10387789;
         } else {
            return biome instanceof BiomeGenSwamp ? 6975545 : this.defaultFoliageColor(biome, pos);
         }
      } else {
         return biome.func_180625_c(pos);
      }
   }

   public int getBiomeWaterColour(int biomeId, BiomeGenBase biome) {
      if (this.isVanilla(biomeId)) {
         return biome instanceof BiomeGenSwamp ? 14745518 : this.defaultWaterColor(biome);
      } else {
         return biome.getWaterColorMultiplier();
      }
   }

   private boolean isVanilla(int biomeId) {
      return biomeId < 40;
   }

   private int defaultGrassColor(BiomeGenBase biome, BlockPos pos) {
      double d0 = (double)MathHelper.func_76131_a(biome.func_180626_a(pos), 0.0F, 1.0F);
      double d1 = (double)MathHelper.func_76131_a(biome.func_76727_i(), 0.0F, 1.0F);
      return ColorizerGrass.func_77480_a(d0, d1);
   }

   private int forestGrassColor(int biomeId, BiomeGenBase biome, BlockPos pos) {
      int i = this.defaultGrassColor(biome, pos);
      return biome == BiomeGenBase.field_150585_R ? (i & 16711422) + 2634762 >> 1 : i;
   }

   private int swampGrassColor(BlockPos pos) {
      double d0 = this.GRASS_COLOR_NOISE.func_151601_a((double)pos.func_177958_n() * 0.0225D, (double)pos.func_177952_p() * 0.0225D);
      return d0 < -0.1D ? 5011004 : 6975545;
   }

   private int defaultFoliageColor(BiomeGenBase biome, BlockPos pos) {
      double d0 = (double)MathHelper.func_76131_a(biome.func_180626_a(pos), 0.0F, 1.0F);
      double d1 = (double)MathHelper.func_76131_a(biome.func_76727_i(), 0.0F, 1.0F);
      return ColorizerFoliage.func_77470_a(d0, d1);
   }

   private int defaultWaterColor(BiomeGenBase biome) {
      return 16777215;
   }
}
