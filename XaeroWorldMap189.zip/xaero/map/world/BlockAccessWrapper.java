package xaero.map.world;

import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;

public class BlockAccessWrapper implements IBlockAccess {
   private IBlockAccess original;
   private IBlockState forcedBlockState;
   private BlockPos pos;

   public IBlockAccess withValues(IBlockAccess original, IBlockState forcedBlockState, BlockPos pos) {
      this.original = original;
      this.forcedBlockState = forcedBlockState;
      this.pos = pos;
      return this;
   }

   public TileEntity func_175625_s(BlockPos pos) {
      return this.original.func_175625_s(pos);
   }

   public int func_175626_b(BlockPos pos, int lightValue) {
      return this.original.func_175626_b(pos, lightValue);
   }

   public IBlockState func_180495_p(BlockPos pos) {
      return pos.equals(this.pos) ? this.forcedBlockState : this.original.func_180495_p(pos);
   }

   public boolean func_175623_d(BlockPos pos) {
      return pos.equals(this.pos) ? this.forcedBlockState.func_177230_c().isAir(this, pos) : this.original.func_175623_d(pos);
   }

   public BiomeGenBase func_180494_b(BlockPos pos) {
      return this.original.func_180494_b(pos);
   }

   public boolean func_72806_N() {
      return this.original.func_72806_N();
   }

   public int func_175627_a(BlockPos pos, EnumFacing direction) {
      return this.original.func_175627_a(pos, direction);
   }

   public WorldType func_175624_G() {
      return this.original.func_175624_G();
   }

   public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean _default) {
      return this.original.isSideSolid(pos, side, _default);
   }
}
