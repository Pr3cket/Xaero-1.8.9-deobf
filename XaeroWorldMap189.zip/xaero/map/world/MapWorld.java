package xaero.map.world;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import net.minecraft.world.World;
import xaero.map.MapProcessor;
import xaero.map.file.MapSaveLoad;

public class MapWorld {
   private MapProcessor mapProcessor;
   private boolean isMultiplayer;
   private String mainId;
   private String oldUnfixedMainId;
   private Hashtable<Integer, MapDimension> dimensions;
   private Integer currentDimensionId;
   private int futureDimensionId;
   private int futureMultiworldType;
   private int currentMultiworldType;
   private boolean futureMultiworldTypeConfirmed = true;
   private boolean currentMultiworldTypeConfirmed = false;
   private boolean ignoreServerLevelId;

   public MapWorld(String mainId, String oldUnfixedMainId, MapProcessor mapProcessor) {
      this.mainId = mainId;
      this.oldUnfixedMainId = oldUnfixedMainId;
      this.mapProcessor = mapProcessor;
      this.isMultiplayer = mapProcessor.isWorldMultiplayer(mapProcessor.isWorldRealms(mainId), mainId);
      this.dimensions = new Hashtable();
      this.futureMultiworldType = this.currentMultiworldType = 0;
   }

   public MapDimension getDimension(int dimId) {
      synchronized(this.dimensions) {
         return (MapDimension)this.dimensions.get(dimId);
      }
   }

   public MapDimension createDimensionUnsynced(World world, int dimId) {
      synchronized(this.dimensions) {
         MapDimension result = (MapDimension)this.dimensions.get(dimId);
         if (result == null) {
            this.dimensions.put(dimId, result = new MapDimension(this, dimId));
            result.renameLegacyFolder(world);
            result.onCreationUnsynced();
         }

         return result;
      }
   }

   public String getMainId() {
      return this.mainId;
   }

   public String getOldUnfixedMainId() {
      return this.oldUnfixedMainId;
   }

   public String getCurrentMultiworld() {
      MapDimension container = this.getDimension(this.currentDimensionId);
      return container.getCurrentMultiworld();
   }

   public String getFutureMultiworldUnsynced() {
      MapDimension container = this.getDimension(this.futureDimensionId);
      return container.getFutureMultiworldUnsynced();
   }

   public MapDimension getCurrentDimension() {
      return this.getDimension(this.currentDimensionId);
   }

   public MapDimension getFutureDimension() {
      return this.getDimension(this.futureDimensionId);
   }

   public Integer getCurrentDimensionId() {
      return this.currentDimensionId;
   }

   public int getFutureDimensionId() {
      return this.futureDimensionId;
   }

   public void setFutureDimensionId(int dimension) {
      this.futureDimensionId = dimension;
   }

   public void switchToFutureUnsynced() {
      this.currentDimensionId = this.futureDimensionId;
      this.getDimension(this.currentDimensionId).switchToFutureUnsynced();
   }

   public List<MapDimension> getDimensionsList() {
      List<MapDimension> destList = new ArrayList();
      this.getDimensions(destList);
      return destList;
   }

   public void getDimensions(List<MapDimension> dest) {
      synchronized(this.dimensions) {
         dest.addAll(this.dimensions.values());
      }
   }

   public int getCurrentMultiworldType() {
      return this.currentMultiworldType;
   }

   public boolean isMultiplayer() {
      return this.isMultiplayer;
   }

   public boolean isCurrentMultiworldTypeConfirmed() {
      return this.currentMultiworldTypeConfirmed;
   }

   public int getFutureMultiworldType(MapDimension dim) {
      return dim.isFutureMultiworldServerBased() ? 2 : this.futureMultiworldType;
   }

   public void toggleMultiworldTypeUnsynced() {
      this.unconfirmMultiworldTypeUnsynced();
      this.futureMultiworldType = (this.futureMultiworldType + 1) % 3;
      this.getCurrentDimension().resetCustomMultiworldUnsynced();
      this.saveConfig();
   }

   public void unconfirmMultiworldTypeUnsynced() {
      this.futureMultiworldTypeConfirmed = false;
   }

   public void confirmMultiworldTypeUnsynced() {
      this.futureMultiworldTypeConfirmed = true;
   }

   public boolean isFutureMultiworldTypeConfirmed(MapDimension dim) {
      return dim.isFutureMultiworldServerBased() ? true : this.futureMultiworldTypeConfirmed;
   }

   public void switchToFutureMultiworldTypeUnsynced() {
      MapDimension futureDim = this.getFutureDimension();
      this.currentMultiworldType = this.getFutureMultiworldType(this.getFutureDimension());
      this.currentMultiworldTypeConfirmed = this.isFutureMultiworldTypeConfirmed(futureDim);
   }

   public void load() {
      Path rootSavePath = MapSaveLoad.getRootFolder(this.mainId);
      this.loadConfig(rootSavePath, 10);
   }

   private void loadConfig(Path rootSavePath, int attempts) {
      MapProcessor mp = this.mapProcessor;
      BufferedReader reader = null;

      try {
         if (!Files.exists(rootSavePath, new LinkOption[0])) {
            Files.createDirectories(rootSavePath);
         }

         Path configFile = rootSavePath.resolve("server_config.txt");
         Path oldOverworldSavePath = mp.getMapSaveLoad().getOldFolder(this.oldUnfixedMainId, "null");
         Path oldConfigFile = oldOverworldSavePath.resolve("server_config.txt");
         if (!Files.exists(configFile, new LinkOption[0]) && Files.exists(oldConfigFile, new LinkOption[0])) {
            Files.move(oldConfigFile, configFile);
         }

         if (Files.exists(configFile, new LinkOption[0])) {
            reader = new BufferedReader(new FileReader(configFile.toFile()));

            String line;
            while((line = reader.readLine()) != null) {
               String[] args = line.split(":");
               if (args[0].equals("multiworldType")) {
                  this.futureMultiworldType = Integer.parseInt(args[1]);
               } else if (args[0].equals("ignoreServerLevelId")) {
                  this.ignoreServerLevelId = args[1].equals("true");
               }
            }

            return;
         }

         this.saveConfig();
         return;
      } catch (IOException var22) {
         if (attempts <= 1) {
            throw new RuntimeException(var22);
         }

         if (reader != null) {
            try {
               reader.close();
            } catch (IOException var21) {
               throw new RuntimeException(var21);
            }
         }

         System.out.println("IO exception while loading world map config. Retrying... " + attempts);

         try {
            Thread.sleep(20L);
         } catch (InterruptedException var20) {
         }

         this.loadConfig(rootSavePath, attempts - 1);
      } finally {
         if (reader != null) {
            try {
               reader.close();
            } catch (IOException var19) {
               var19.printStackTrace();
            }
         }

      }

   }

   public void saveConfig() {
      MapProcessor mp = this.mapProcessor;
      mp.getMapSaveLoad();
      Path rootSavePath = MapSaveLoad.getRootFolder(this.mainId);
      PrintWriter writer = null;

      try {
         writer = new PrintWriter(new FileWriter(rootSavePath.resolve("server_config.txt").toFile()));
         writer.println("multiworldType:" + this.futureMultiworldType);
         writer.println("ignoreServerLevelId:" + this.ignoreServerLevelId);
      } catch (IOException var8) {
         var8.printStackTrace();
      } finally {
         if (writer != null) {
            writer.close();
         }

      }

   }

   MapProcessor getMapProcessor() {
      return this.mapProcessor;
   }

   public boolean isIgnoreServerLevelId() {
      return this.ignoreServerLevelId;
   }
}
