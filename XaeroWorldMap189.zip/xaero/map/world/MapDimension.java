package xaero.map.world;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraftforge.common.DimensionManager;
import org.apache.commons.io.FileUtils;
import xaero.map.MapProcessor;
import xaero.map.file.RegionDetection;
import xaero.map.region.LeveledRegion;
import xaero.map.region.LeveledRegionManager;
import xaero.map.region.MapRegion;

public class MapDimension {
   private final MapWorld mapWorld;
   private final int dimId;
   private final List<String> multiworldIds;
   private final Hashtable<String, String> multiworldNames;
   private final Hashtable<String, String> autoMultiworldBindings;
   private String futureAutoMultiworldBinding;
   private String futureCustomSelectedMultiworld;
   public boolean futureMultiworldWritable;
   public boolean futureMultiworldServerBased;
   private String currentMultiworld;
   public boolean currentMultiworldWritable;
   private String confirmedMultiworld;
   private LeveledRegionManager mapRegions;
   private List<MapRegion> regionBackCompList;
   private Hashtable<Integer, Hashtable<Integer, RegionDetection>> detectedRegions;
   public final ArrayList<LeveledRegion<?>> regionsToCache;

   public MapDimension(MapWorld mapWorld, int dimId) {
      this.mapWorld = mapWorld;
      this.dimId = dimId;
      this.multiworldIds = new ArrayList();
      this.multiworldNames = new Hashtable();
      this.mapRegions = new LeveledRegionManager();
      this.autoMultiworldBindings = new Hashtable();
      this.regionsToCache = new ArrayList();
      this.regionBackCompList = new ArrayList();
   }

   public String getCurrentMultiworld() {
      return this.currentMultiworld;
   }

   public List<String> getMultiworldIdsCopy() {
      synchronized(this.multiworldIds) {
         return new ArrayList(this.multiworldIds);
      }
   }

   public void updateFutureAutomaticUnsynced(Minecraft mc, Object baseObject) {
      if (mc.func_71401_C() != null) {
         this.futureAutoMultiworldBinding = "";
      } else if (baseObject != null) {
         if (baseObject instanceof BlockPos) {
            BlockPos dimSpawn = (BlockPos)baseObject;
            this.futureAutoMultiworldBinding = "mw" + (dimSpawn.func_177958_n() >> 6) + "," + (dimSpawn.func_177956_o() >> 6) + "," + (dimSpawn.func_177952_p() >> 6);
            this.futureMultiworldServerBased = false;
         } else if (baseObject instanceof Integer) {
            int levelId = (Integer)baseObject;
            this.futureAutoMultiworldBinding = "mw$" + levelId;
            this.futureCustomSelectedMultiworld = null;
            this.futureMultiworldWritable = true;
            this.futureMultiworldServerBased = true;
         }
      } else {
         this.futureAutoMultiworldBinding = "unknown";
      }

   }

   public String getFutureCustomSelectedMultiworld() {
      return this.futureCustomSelectedMultiworld;
   }

   public String getFutureMultiworldUnsynced() {
      return this.futureCustomSelectedMultiworld == null ? this.getFutureAutoMultiworld() : this.futureCustomSelectedMultiworld;
   }

   public void switchToFutureUnsynced() {
      this.currentMultiworld = this.getFutureMultiworldUnsynced();
      this.addMultiworldChecked(this.currentMultiworld);
   }

   public void switchToFutureMultiworldWritableValueUnsynced() {
      this.currentMultiworldWritable = this.futureMultiworldWritable;
   }

   public LeveledRegionManager getMapRegions() {
      return this.mapRegions;
   }

   /** @deprecated */
   @Deprecated
   public List<MapRegion> getMapRegionsList() {
      return this.regionBackCompList;
   }

   public Hashtable<Integer, Hashtable<Integer, RegionDetection>> getDetectedRegions() {
      return this.detectedRegions;
   }

   public Hashtable<Integer, Hashtable<Integer, RegionDetection>> createDetectedRegions() {
      if (this.detectedRegions == null) {
         this.detectedRegions = new Hashtable();
      }

      return this.detectedRegions;
   }

   public void clearLists() {
      this.mapRegions.clear();
      this.regionBackCompList.clear();
      this.detectedRegions = null;
   }

   public Path getMainFolderPath() {
      return this.mapWorld.getMapProcessor().getMapSaveLoad().getMainFolder(this.mapWorld.getMainId(), this.mapWorld.getMapProcessor().getDimensionName(this.dimId));
   }

   public Path getOldFolderPath() {
      return this.mapWorld.getMapProcessor().getMapSaveLoad().getOldFolder(this.mapWorld.getOldUnfixedMainId(), this.mapWorld.getMapProcessor().getDimensionName(this.dimId));
   }

   public void saveConfigUnsynced() {
      Path dimensionSavePath = this.getMainFolderPath();
      PrintWriter writer = null;

      try {
         writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dimensionSavePath.resolve("dimension_config.txt").toFile()), StandardCharsets.UTF_8));
         if (this.mapWorld.isMultiplayer()) {
            if (this.confirmedMultiworld != null) {
               writer.println("confirmedMultiworld:" + this.confirmedMultiworld);
            }

            Iterator var3 = this.autoMultiworldBindings.entrySet().iterator();

            Entry bindingEntry;
            while(var3.hasNext()) {
               bindingEntry = (Entry)var3.next();
               writer.println("autoMWBinding:" + (String)bindingEntry.getKey() + ":" + (String)bindingEntry.getValue());
            }

            var3 = this.multiworldNames.entrySet().iterator();

            while(var3.hasNext()) {
               bindingEntry = (Entry)var3.next();
               writer.println("MWName:" + (String)bindingEntry.getKey() + ":" + ((String)bindingEntry.getValue()).replace(":", "^col^"));
            }
         }
      } catch (IOException var8) {
         var8.printStackTrace();
      } finally {
         if (writer != null) {
            writer.close();
         }

      }

   }

   private void loadConfigUnsynced(int attempts) {
      Path dimensionSavePath = this.getMainFolderPath();
      BufferedReader reader = null;

      try {
         try {
            Path oldDimensionSavePath = this.getOldFolderPath();
            if (!Files.exists(dimensionSavePath, new LinkOption[0]) && Files.exists(oldDimensionSavePath, new LinkOption[0])) {
               Files.move(oldDimensionSavePath, dimensionSavePath);
            }

            if (!Files.exists(dimensionSavePath, new LinkOption[0])) {
               Files.createDirectories(dimensionSavePath);
            }

            this.loadMultiworldsList(dimensionSavePath);
            Path configFile = dimensionSavePath.resolve("dimension_config.txt");
            if (Files.exists(configFile, new LinkOption[0])) {
               reader = new BufferedReader(new InputStreamReader(new FileInputStream(configFile.toFile()), "UTF8"));

               String line;
               while((line = reader.readLine()) != null) {
                  String[] args = line.split(":");
                  if (this.mapWorld.isMultiplayer()) {
                     if (args[0].equals("confirmedMultiworld")) {
                        if (this.multiworldIds.contains(args[1])) {
                           this.confirmedMultiworld = args[1];
                        }
                     } else if (args[0].equals("autoMWBinding")) {
                        this.bindAutoMultiworld(args[1], args[2]);
                     } else if (args[0].equals("MWName")) {
                        this.setMultiworldName(args[1], args[2].replace("^col^", ":"));
                     }
                  }
               }

               return;
            }

            this.saveConfigUnsynced();
            return;
         } catch (IOException var20) {
            if (attempts <= 1) {
               throw new RuntimeException(var20);
            }

            if (reader != null) {
               try {
                  reader.close();
               } catch (IOException var19) {
                  throw new RuntimeException(var19);
               }
            }
         }

         System.out.println("IO exception while loading world map dimension config. Retrying... " + attempts);

         try {
            Thread.sleep(20L);
         } catch (InterruptedException var18) {
         }

         this.loadConfigUnsynced(attempts - 1);
      } finally {
         if (reader != null) {
            try {
               reader.close();
            } catch (IOException var17) {
               var17.printStackTrace();
            }
         }

      }

   }

   public void pickDefaultCustomMultiworldUnsynced() {
      if (this.multiworldIds.isEmpty()) {
         this.futureCustomSelectedMultiworld = "mw$default";
         this.multiworldIds.add(this.futureCustomSelectedMultiworld);
         this.setMultiworldName(this.futureCustomSelectedMultiworld, "Default");
      } else {
         int indexOfAuto = this.multiworldIds.indexOf(this.getFutureAutoMultiworld());
         this.futureCustomSelectedMultiworld = (String)this.multiworldIds.get(indexOfAuto != -1 ? indexOfAuto : 0);
      }

   }

   private void loadMultiworldsList(Path dimensionSavePath) {
      if (this.mapWorld.isMultiplayer()) {
         try {
            Stream<Path> subFolders = Files.list(dimensionSavePath);
            Iterator iter = subFolders.iterator();

            while(true) {
               String folderName;
               boolean autoMultiworldFormat;
               boolean customMultiworldFormat;
               do {
                  Path path;
                  do {
                     if (!iter.hasNext()) {
                        subFolders.close();
                        return;
                     }

                     path = (Path)iter.next();
                  } while(!path.toFile().isDirectory());

                  folderName = path.getFileName().toString();
                  autoMultiworldFormat = folderName.matches("^mw(-?\\d+),(-?\\d+),(-?\\d+)$");
                  customMultiworldFormat = folderName.startsWith("mw$");
               } while(!autoMultiworldFormat && !customMultiworldFormat);

               this.multiworldIds.add(folderName);
            }
         } catch (IOException var8) {
            var8.printStackTrace();
         }
      }
   }

   public void confirmMultiworldUnsynced() {
      if (!this.futureMultiworldWritable) {
         this.futureMultiworldWritable = true;
         if (this.mapWorld.getFutureMultiworldType(this) == 2 && this.futureCustomSelectedMultiworld != null) {
            this.makeCustomSelectedMultiworldAuto();
         }

         this.confirmedMultiworld = this.getFutureMultiworldUnsynced();
         this.saveConfigUnsynced();
      }

   }

   private void makeCustomSelectedMultiworldAuto() {
      String currentAutoMultiworld = this.getFutureAutoMultiworld();
      boolean currentBindingFound = false;
      Iterator var3 = this.autoMultiworldBindings.entrySet().iterator();

      while(var3.hasNext()) {
         Entry<String, String> bindingEntry = (Entry)var3.next();
         if (((String)bindingEntry.getValue()).equals(this.futureCustomSelectedMultiworld)) {
            this.bindAutoMultiworld((String)bindingEntry.getKey(), currentAutoMultiworld);
            currentBindingFound = true;
            break;
         }
      }

      if (!currentBindingFound && !this.futureCustomSelectedMultiworld.startsWith("mw$")) {
         this.bindAutoMultiworld(this.futureCustomSelectedMultiworld, currentAutoMultiworld);
      }

      this.bindAutoMultiworld(this.futureAutoMultiworldBinding, this.futureCustomSelectedMultiworld);
      this.futureCustomSelectedMultiworld = null;
      this.saveConfigUnsynced();
   }

   private void bindAutoMultiworld(String binding, String multiworld) {
      if (binding.equals(multiworld)) {
         this.autoMultiworldBindings.remove(binding);
      } else {
         this.autoMultiworldBindings.put(binding, multiworld);
      }

   }

   public void resetCustomMultiworldUnsynced() {
      this.futureCustomSelectedMultiworld = this.mapWorld.getFutureMultiworldType(this) == 2 ? null : this.confirmedMultiworld;
      if (this.futureCustomSelectedMultiworld == null && this.mapWorld.getFutureMultiworldType(this) < 2) {
         this.pickDefaultCustomMultiworldUnsynced();
      }

      this.futureMultiworldWritable = this.mapWorld.getFutureMultiworldType(this) != 1 && this.mapWorld.isFutureMultiworldTypeConfirmed(this);
   }

   public void setMultiworldUnsynced(String nextMW) {
      String cmw = this.futureCustomSelectedMultiworld == null ? this.getFutureMultiworldUnsynced() : this.futureCustomSelectedMultiworld;
      this.futureCustomSelectedMultiworld = nextMW;
      this.futureMultiworldWritable = false;
      System.out.println(cmw + " -> " + this.futureCustomSelectedMultiworld);
   }

   private boolean multiworldExists(String mw) {
      synchronized(this.multiworldIds) {
         return this.multiworldIds.contains(mw);
      }
   }

   public boolean addMultiworldChecked(String mw) {
      synchronized(this.multiworldIds) {
         if (!this.multiworldIds.contains(mw)) {
            this.multiworldIds.add(mw);
            return true;
         } else {
            return false;
         }
      }
   }

   public String getMultiworldName(String mwId) {
      String tableName = (String)this.multiworldNames.get(mwId);
      if (tableName != null) {
         return tableName;
      } else if (!this.multiworldExists(mwId)) {
         return mwId;
      } else {
         int var4 = 1;

         String automaticName;
         while(this.multiworldNames.containsValue(automaticName = "Map " + var4++)) {
         }

         this.setMultiworldName(mwId, automaticName);
         synchronized(this.mapWorld.getMapProcessor().uiSync) {
            this.saveConfigUnsynced();
            return automaticName;
         }
      }
   }

   public void setMultiworldName(String mwId, String mwName) {
      this.multiworldNames.put(mwId, mwName);
   }

   private String getFutureAutoMultiworld() {
      if (this.futureAutoMultiworldBinding == null) {
         return null;
      } else {
         String boundMultiworld = (String)this.autoMultiworldBindings.get(this.futureAutoMultiworldBinding);
         return boundMultiworld == null ? this.futureAutoMultiworldBinding : boundMultiworld;
      }
   }

   public MapWorld getMapWorld() {
      return this.mapWorld;
   }

   public void deleteMultiworldMapDataUnsynced(String mwId) {
      try {
         Path currentDimFolder = this.getMainFolderPath();
         Path currentMWFolder = currentDimFolder.resolve(mwId);
         Path binFolder = currentDimFolder.resolve("last deleted");
         Path binMWFolder = binFolder.resolve(mwId);
         if (!Files.exists(binFolder, new LinkOption[0])) {
            Files.createDirectories(binFolder);
         }

         FileUtils.cleanDirectory(binFolder.toFile());
         Files.move(currentMWFolder, binMWFolder);
      } catch (Exception var6) {
         var6.printStackTrace();
      }

   }

   public void deleteMultiworldId(String mwId) {
      synchronized(this.multiworldIds) {
         this.multiworldIds.remove(mwId);
         this.multiworldNames.remove(mwId);
         if (mwId.equals(this.confirmedMultiworld)) {
            this.confirmedMultiworld = null;
         }

      }
   }

   public int getDimId() {
      return this.dimId;
   }

   public boolean hasConfirmedMultiworld() {
      return this.confirmedMultiworld != null;
   }

   public boolean isFutureMultiworldServerBased() {
      return this.futureMultiworldServerBased;
   }

   public void renameLegacyFolder(World world) {
      MapProcessor mapProcessor = this.mapWorld.getMapProcessor();
      Path newerFolderPath = this.getOldFolderPath();
      if (!Files.exists(this.getMainFolderPath(), new LinkOption[0]) && !Files.exists(newerFolderPath, new LinkOption[0])) {
         String legacyFolderName;
         if (world != null) {
            legacyFolderName = mapProcessor.getDimensionLegacyName(world.field_73011_w);
         } else {
            WorldProvider dimWorldProvider = null;

            try {
               dimWorldProvider = DimensionManager.createProviderFor(this.dimId);
               legacyFolderName = mapProcessor.getDimensionLegacyName(dimWorldProvider);
            } catch (RuntimeException var8) {
               System.out.println("Couldn't create world provider to get dimension folder name: " + this.dimId);
               return;
            }
         }

         Path legacyFolderPath = mapProcessor.getMapSaveLoad().getOldFolder(this.mapWorld.getOldUnfixedMainId(), legacyFolderName);
         if (Files.exists(legacyFolderPath, new LinkOption[0])) {
            try {
               Files.move(legacyFolderPath, newerFolderPath);
            } catch (IOException var7) {
               throw new RuntimeException(var7);
            }
         }
      }

   }

   public void onCreationUnsynced() {
      this.loadConfigUnsynced(10);
   }
}
