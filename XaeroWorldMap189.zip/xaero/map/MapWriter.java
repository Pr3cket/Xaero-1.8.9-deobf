package xaero.map;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.UnmodifiableIterator;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockGlass;
import net.minecraft.block.BlockGrass;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockOre;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.IResource;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.minecraftforge.common.property.IExtendedBlockState;
import net.minecraftforge.common.property.IUnlistedProperty;
import xaero.map.biome.MapBiomes;
import xaero.map.biome.WriterBiomeInfoSupplier;
import xaero.map.cache.BlockStateColorTypeCache;
import xaero.map.core.XaeroWorldMapCore;
import xaero.map.exception.SilentException;
import xaero.map.misc.Misc;
import xaero.map.region.MapBlock;
import xaero.map.region.MapRegion;
import xaero.map.region.MapTile;
import xaero.map.region.MapTileChunk;
import xaero.map.region.OverlayBuilder;
import xaero.map.region.OverlayManager;

public class MapWriter {
   public static final String[] DEFAULT_RESOURCE = new String[]{"minecraft", ""};
   private int X;
   private int Z;
   private int playerChunkX;
   private int playerChunkZ;
   private int loadDistance;
   private int startTileChunkX;
   private int startTileChunkZ;
   private int endTileChunkX;
   private int endTileChunkZ;
   private int insideX;
   private int insideZ;
   private long updateCounter;
   private boolean clearCachedColours;
   private MapBlock loadingObject = new MapBlock();
   private OverlayBuilder overlayBuilder;
   private MutableBlockPos mutableLocalPos;
   private MutableBlockPos mutableGlobalPos;
   private int[] biomeBuffer;
   private long lastWrite = -1L;
   private long lastWriteTry = -1L;
   private int workingFrameCount;
   private long framesFreedTime = -1L;
   public long writeFreeSinceLastWrite = -1L;
   private int writeFreeSizeTiles;
   private int writeFreeFullUpdateTargetTime;
   private BlockStateColorTypeCache colorTypeCache;
   private MapProcessor mapProcessor;
   private ArrayList<IBlockState> buggedStates;
   private WriterBiomeInfoSupplier writerBiomeInfoSupplier;
   private MapTileChunk rightChunk = null;
   private MapTileChunk bottomRightChunk = null;
   private HashMap<String, Integer> textureColours = new HashMap();
   private HashMap<Integer, Integer> blockColours = new HashMap();
   private int lastBlockStateForTextureColor = -1;
   private int lastBlockStateForTextureColorResult = -1;

   public MapWriter(OverlayManager overlayManager, BlockStateColorTypeCache colorTypeCache) {
      this.overlayBuilder = new OverlayBuilder(overlayManager);
      this.mutableLocalPos = new MutableBlockPos();
      this.mutableGlobalPos = new MutableBlockPos();
      this.biomeBuffer = new int[3];
      this.colorTypeCache = colorTypeCache;
      this.buggedStates = new ArrayList();
      this.writerBiomeInfoSupplier = new WriterBiomeInfoSupplier(this.mutableGlobalPos);
   }

   public void onRender() {
      long var1 = System.nanoTime();

      try {
         if (WorldMap.crashHandler.getCrashedBy() == null) {
            synchronized(this.mapProcessor.renderThreadPauseSync) {
               if (!this.mapProcessor.isWritingPaused() && !this.mapProcessor.isWaitingForWorldUpdate() && this.mapProcessor.getMapSaveLoad().isRegionDetectionComplete() && this.mapProcessor.isCurrentMultiworldWritable()) {
                  if (this.mapProcessor.getWorld() == null || !this.mapProcessor.caveStartIsDetermined()) {
                     return;
                  }

                  if (this.mapProcessor.getCurrentWorldId() != null && !this.mapProcessor.ignoreWorld(this.mapProcessor.getWorld()) && (WorldMap.settings.updateChunks || WorldMap.settings.loadChunks)) {
                     double playerX;
                     double playerY;
                     double playerZ;
                     synchronized(this.mapProcessor.mainStuffSync) {
                        if (this.mapProcessor.mainWorld != this.mapProcessor.getWorld()) {
                           return;
                        }

                        playerX = this.mapProcessor.mainPlayerX;
                        playerY = this.mapProcessor.mainPlayerY;
                        playerZ = this.mapProcessor.mainPlayerZ;
                     }

                     XaeroWorldMapCore.ensureField();
                     int lengthX = this.endTileChunkX - this.startTileChunkX + 1;
                     int lengthZ = this.endTileChunkZ - this.startTileChunkZ + 1;
                     if (this.lastWriteTry == -1L) {
                        lengthX = 3;
                        lengthZ = 3;
                     }

                     int sizeTileChunks = lengthX * lengthZ;
                     int sizeTiles = sizeTileChunks * 4 * 4;
                     int sizeBasedTargetTime = sizeTiles * 1000 / 1500;
                     int fullUpdateTargetTime = Math.max(100, sizeBasedTargetTime);
                     long time = System.currentTimeMillis();
                     long passed = this.lastWrite == -1L ? 0L : time - this.lastWrite;
                     if (this.lastWriteTry == -1L || this.writeFreeSizeTiles != sizeTiles || this.writeFreeFullUpdateTargetTime != fullUpdateTargetTime || this.workingFrameCount > 30) {
                        this.framesFreedTime = time;
                        this.writeFreeSizeTiles = sizeTiles;
                        this.writeFreeFullUpdateTargetTime = fullUpdateTargetTime;
                        this.workingFrameCount = 0;
                     }

                     long sinceLastWrite = Math.min(passed, this.writeFreeSinceLastWrite);
                     if (this.framesFreedTime != -1L) {
                        sinceLastWrite = time - this.framesFreedTime;
                     }

                     long tilesToUpdate = Math.min(sinceLastWrite * (long)sizeTiles / (long)fullUpdateTargetTime, 100L);
                     if (this.lastWrite == -1L || tilesToUpdate != 0L) {
                        this.lastWrite = time;
                     }

                     int timeLimit;
                     if (tilesToUpdate != 0L) {
                        if (this.framesFreedTime != -1L) {
                           this.writeFreeSinceLastWrite = sinceLastWrite;
                           this.framesFreedTime = -1L;
                        } else {
                           timeLimit = (int)(Math.min(sinceLastWrite, 50L) * 86960L);
                           long writeStartNano = System.nanoTime();
                           boolean loadChunks = WorldMap.settings.loadChunks;
                           boolean updateChunks = WorldMap.settings.updateChunks;
                           boolean ignoreHeightmaps = WorldMap.settings.ignoreHeightmaps;
                           boolean flowers = WorldMap.settings.flowers;
                           boolean detailedDebug = WorldMap.settings.detailed_debug;

                           for(int i = 0; (long)i < tilesToUpdate; ++i) {
                              this.writeMap(this.mapProcessor.getWorld(), playerX, playerY, playerZ, loadChunks, updateChunks, ignoreHeightmaps, flowers, detailedDebug);
                              if (System.nanoTime() - writeStartNano >= (long)timeLimit) {
                                 break;
                              }
                           }

                           ++this.workingFrameCount;
                        }
                     }

                     this.lastWriteTry = time;
                     timeLimit = this.startTileChunkX >> 3;
                     int startRegionZ = this.startTileChunkZ >> 3;
                     int endRegionX = this.endTileChunkX >> 3;
                     int endRegionZ = this.endTileChunkZ >> 3;

                     for(int visitRegionX = timeLimit; visitRegionX <= endRegionX; ++visitRegionX) {
                        for(int visitRegionZ = startRegionZ; visitRegionZ <= endRegionZ; ++visitRegionZ) {
                           MapRegion visitRegion = this.mapProcessor.getMapRegion(visitRegionX, visitRegionZ, false);
                           if (visitRegion != null && visitRegion.getLoadState() == 2) {
                              visitRegion.registerVisit();
                           }
                        }
                     }
                  }
               }

               return;
            }
         }
      } catch (Throwable var36) {
         WorldMap.crashHandler.setCrashedBy(var36);
      }

   }

   private int getWriteDistance() {
      return Math.min(32, Minecraft.func_71410_x().field_71474_y.field_151451_c);
   }

   public void writeMap(World world, double playerX, double playerY, double playerZ, boolean loadChunks, boolean updateChunks, boolean ignoreHeightmaps, boolean flowers, boolean detailedDebug) {
      boolean onlyLoad = loadChunks && (!updateChunks || this.updateCounter % 5L != 0L);
      synchronized(world) {
         if (this.insideX == 0 && this.insideZ == 0) {
            this.playerChunkX = (int)Math.floor(playerX) >> 4;
            this.playerChunkZ = (int)Math.floor(playerZ) >> 4;
            this.loadDistance = this.getWriteDistance();
            this.startTileChunkX = this.playerChunkX - this.loadDistance >> 2;
            this.startTileChunkZ = this.playerChunkZ - this.loadDistance >> 2;
            this.endTileChunkX = this.playerChunkX + this.loadDistance >> 2;
            this.endTileChunkZ = this.playerChunkZ + this.loadDistance >> 2;
         }

         this.writeChunk(world, this.loadDistance, onlyLoad, loadChunks, updateChunks, ignoreHeightmaps, flowers, detailedDebug);
      }
   }

   public void writeChunk(World world, int distance, boolean onlyLoad, boolean loadChunks, boolean updateChunks, boolean ignoreHeightmaps, boolean flowers, boolean detailedDebug) {
      int result = 1;
      int tileChunkX = this.startTileChunkX + this.X;
      int tileChunkZ = this.startTileChunkZ + this.Z;
      int tileChunkLocalX = tileChunkX & 7;
      int tileChunkLocalZ = tileChunkZ & 7;
      int regionX = tileChunkX >> 3;
      int regionZ = tileChunkZ >> 3;
      MapRegion region = this.mapProcessor.getMapRegion(regionX, regionZ, true);
      MapTileChunk tileChunk = null;
      this.rightChunk = null;
      MapTileChunk bottomChunk = null;
      this.bottomRightChunk = null;
      synchronized(region.writerThreadPauseSync) {
         if (!region.isWritingPaused()) {
            boolean regionIsResting;
            boolean isProperLoadState;
            synchronized(region) {
               isProperLoadState = region.getLoadState() == 2;
               if (isProperLoadState) {
                  region.registerVisit();
               }

               regionIsResting = region.isResting();
               if (regionIsResting) {
                  region.setBeingWritten(true);
                  tileChunk = region.getChunk(tileChunkLocalX, tileChunkLocalZ);
                  if (isProperLoadState && tileChunk == null) {
                     region.setChunk(tileChunkLocalX, tileChunkLocalZ, tileChunk = new MapTileChunk(region, tileChunkX, tileChunkZ));
                     tileChunk.setLoadState((byte)2);
                  } else if (!region.reloadHasBeenRequested() && !region.recacheHasBeenRequested() && (region.getLoadState() == 0 || region.getLoadState() == 4)) {
                     this.mapProcessor.getMapSaveLoad().requestLoad(region, "writing");
                  }
               }
            }

            if (regionIsResting && isProperLoadState) {
               if (tileChunk != null && tileChunk.getLoadState() == 2) {
                  if (!tileChunk.getLeafTexture().shouldUpload()) {
                     int caveStart = this.mapProcessor.getCaveStart();
                     int chunkX = tileChunkX * 4 + this.insideX;
                     int chunkZ = tileChunkZ * 4 + this.insideZ;
                     if (chunkX >= this.playerChunkX - distance && chunkX < this.playerChunkX + distance && chunkZ >= this.playerChunkZ - distance && chunkZ < this.playerChunkZ + distance) {
                        Chunk chunk = world.func_72964_e(chunkX, chunkZ);
                        MapTile mapTile = tileChunk.getTile(this.insideX, this.insideZ);
                        boolean chunkUpdated = false;

                        try {
                           chunkUpdated = chunk != null && (mapTile == null || !(Boolean)XaeroWorldMapCore.chunkCleanField.get(chunk));
                        } catch (IllegalAccessException | IllegalArgumentException var47) {
                           throw new RuntimeException(var47);
                        }

                        if (chunkUpdated && chunk.func_177410_o()) {
                           boolean connectedToOthers = false;

                           label313:
                           for(int i = -1; i < 2; ++i) {
                              for(int j = -1; j < 2; ++j) {
                                 if (i != 0 || j != 0) {
                                    Chunk neighbor = world.func_72964_e(chunkX + i, chunkZ + j);
                                    if (neighbor != null && neighbor.func_177410_o()) {
                                       connectedToOthers = true;
                                       break label313;
                                    }
                                 }
                              }
                           }

                           if (connectedToOthers && (mapTile == null && loadChunks || mapTile != null && updateChunks && !onlyLoad)) {
                              if (mapTile == null) {
                                 mapTile = this.mapProcessor.getTilePool().get(this.mapProcessor.getCurrentDimension(), chunkX, chunkZ);
                                 tileChunk.setChanged(true);
                              }

                              MapTileChunk prevTileChunk = tileChunk.getNeighbourTileChunk(0, -1, this.mapProcessor, false);
                              MapTileChunk prevTileChunkDiagonal = tileChunk.getNeighbourTileChunk(-1, -1, this.mapProcessor, false);
                              MapTileChunk prevTileChunkHorisontal = tileChunk.getNeighbourTileChunk(-1, 0, this.mapProcessor, false);
                              int sectionBasedHeight = this.getSectionBasedHeight(chunk, 64);
                              MapTile bottomTile = this.insideZ < 3 ? tileChunk.getTile(this.insideX, this.insideZ + 1) : null;
                              MapTile rightTile = this.insideX < 3 ? tileChunk.getTile(this.insideX + 1, this.insideZ) : null;
                              boolean triedFetchingBottomChunk = false;
                              boolean triedFetchingRightChunk = false;
                              int x = 0;

                              while(true) {
                                 if (x >= 16) {
                                    tileChunk.setTile(this.insideX, this.insideZ, mapTile);
                                    mapTile.setWrittenOnce(true);
                                    mapTile.setLoaded(true);

                                    try {
                                       XaeroWorldMapCore.chunkCleanField.set(chunk, true);
                                       break;
                                    } catch (IllegalAccessException | IllegalArgumentException var46) {
                                       throw new RuntimeException(var46);
                                    }
                                 }

                                 for(int z = 0; z < 16; ++z) {
                                    int startHeight;
                                    if (caveStart != -1) {
                                       startHeight = caveStart;
                                    } else {
                                       int mappedHeight = chunk.func_76611_b(x, z);
                                       if (!ignoreHeightmaps && mappedHeight != -1) {
                                          startHeight = mappedHeight + 3;
                                       } else {
                                          startHeight = sectionBasedHeight;
                                       }
                                    }

                                    MapBlock currentPixel = mapTile.isLoaded() ? mapTile.getBlock(x, z) : null;
                                    this.loadPixel(world, this.loadingObject, currentPixel, chunk, x, z, startHeight, 0, caveStart != -1, mapTile.wasWrittenOnce(), flowers);
                                    this.loadingObject.fixHeightType(x, z, mapTile, tileChunk, prevTileChunk, prevTileChunkDiagonal, prevTileChunkHorisontal, this.loadingObject.getHeight(), true);
                                    boolean equalsSlopesExcluded = this.loadingObject.equalsSlopesExcluded(currentPixel);
                                    boolean fullyEqual = this.loadingObject.equals(currentPixel, equalsSlopesExcluded);
                                    if (!fullyEqual) {
                                       mapTile.setBlock(x, z, this.loadingObject);
                                       if (currentPixel != null) {
                                          this.loadingObject = currentPixel;
                                       } else {
                                          this.loadingObject = new MapBlock();
                                       }

                                       if (!equalsSlopesExcluded) {
                                          tileChunk.setChanged(true);
                                          boolean zEdge = z == 15;
                                          boolean xEdge = x == 15;
                                          if (zEdge) {
                                             if (!triedFetchingBottomChunk && bottomTile == null && this.insideZ == 3 && tileChunkLocalZ < 7) {
                                                bottomChunk = region.getChunk(tileChunkLocalX, tileChunkLocalZ + 1);
                                                triedFetchingBottomChunk = true;
                                                bottomTile = bottomChunk != null ? bottomChunk.getTile(this.insideX, 0) : null;
                                                if (bottomTile != null) {
                                                   bottomChunk.setChanged(true);
                                                }
                                             }

                                             if (bottomTile != null) {
                                                bottomTile.getBlock(x, 0).setSlopeUnknown(true);
                                                if (!xEdge) {
                                                   bottomTile.getBlock(x + 1, 0).setSlopeUnknown(true);
                                                }
                                             }

                                             if (xEdge) {
                                                this.updateBottomRightTile(region, tileChunk, bottomChunk, tileChunkLocalX, tileChunkLocalZ);
                                             }
                                          } else if (xEdge) {
                                             if (!triedFetchingRightChunk && rightTile == null && this.insideX == 3 && tileChunkLocalX < 7) {
                                                this.rightChunk = region.getChunk(tileChunkLocalX + 1, tileChunkLocalZ);
                                                triedFetchingRightChunk = true;
                                                rightTile = this.rightChunk != null ? this.rightChunk.getTile(0, this.insideZ) : null;
                                                if (rightTile != null) {
                                                   this.rightChunk.setChanged(true);
                                                }
                                             }

                                             if (rightTile != null) {
                                                rightTile.getBlock(0, z + 1).setSlopeUnknown(true);
                                             }
                                          }
                                       }

                                       result = 3;
                                    }
                                 }

                                 ++x;
                              }
                           }
                        }
                     }
                  }

                  if (!tileChunk.includeInSave()) {
                     region.setChunk(tileChunkX & 7, tileChunkZ & 7, (MapTileChunk)null);
                     tileChunk = null;
                  }
               }

               if (tileChunk != null && this.insideX == 3 && this.insideZ == 3 && tileChunk.wasChanged()) {
                  tileChunk.updateBuffers(this.mapProcessor, detailedDebug);
                  int var50 = result + 2;
                  if (bottomChunk == null && tileChunkLocalZ < 7) {
                     bottomChunk = region.getChunk(tileChunkLocalX, tileChunkLocalZ + 1);
                  }

                  if (this.rightChunk == null && tileChunkLocalX < 7) {
                     this.rightChunk = region.getChunk(tileChunkLocalX + 1, tileChunkLocalZ);
                  }

                  if (this.bottomRightChunk == null && tileChunkLocalX < 7 && tileChunkLocalZ < 7) {
                     this.bottomRightChunk = region.getChunk(tileChunkLocalX + 1, tileChunkLocalZ + 1);
                  }

                  if (bottomChunk != null && bottomChunk.wasChanged()) {
                     bottomChunk.updateBuffers(this.mapProcessor, detailedDebug);
                     bottomChunk.setChanged(false);
                     var50 += 2;
                  }

                  if (this.rightChunk != null && this.rightChunk.wasChanged()) {
                     this.rightChunk.setToUpdateBuffers(true);
                     this.rightChunk.setChanged(false);
                  }

                  if (this.bottomRightChunk != null && this.bottomRightChunk.wasChanged()) {
                     this.bottomRightChunk.setToUpdateBuffers(true);
                     this.bottomRightChunk.setChanged(false);
                  }

                  tileChunk.setChanged(false);
               }
            }
         }
      }

      ++this.insideZ;
      if (this.insideZ > 3) {
         this.insideZ = 0;
         ++this.insideX;
         if (this.insideX > 3) {
            this.insideX = 0;
            ++this.Z;
            if (this.Z > this.endTileChunkZ - this.startTileChunkZ) {
               this.Z = 0;
               ++this.X;
               if (this.X > this.endTileChunkX - this.startTileChunkX) {
                  this.X = 0;
                  ++this.updateCounter;
               }
            }
         }
      }

   }

   public void updateBottomRightTile(MapRegion region, MapTileChunk tileChunk, MapTileChunk bottomChunk, int tileChunkLocalX, int tileChunkLocalZ) {
      MapTile bottomRightTile = this.insideX < 3 && this.insideZ < 3 ? tileChunk.getTile(this.insideX + 1, this.insideZ + 1) : null;
      if (bottomRightTile == null) {
         if (this.insideX == 3 && tileChunkLocalX < 7) {
            if (this.insideZ == 3) {
               if (tileChunkLocalZ < 7) {
                  this.bottomRightChunk = region.getChunk(tileChunkLocalX + 1, tileChunkLocalZ + 1);
               }

               bottomRightTile = this.bottomRightChunk != null ? this.bottomRightChunk.getTile(0, 0) : null;
               if (bottomRightTile != null) {
                  this.bottomRightChunk.setChanged(true);
               }
            } else {
               if (this.rightChunk == null) {
                  this.rightChunk = region.getChunk(tileChunkLocalX + 1, tileChunkLocalZ);
               }

               bottomRightTile = this.rightChunk != null ? this.rightChunk.getTile(0, this.insideZ + 1) : null;
               if (bottomRightTile != null) {
                  this.rightChunk.setChanged(true);
               }
            }
         } else if (this.insideX != 3 && this.insideZ == 3 && tileChunkLocalZ < 7) {
            bottomRightTile = bottomChunk != null ? bottomChunk.getTile(this.insideX + 1, 0) : null;
            if (bottomRightTile != null) {
               bottomChunk.setChanged(true);
            }
         }
      }

      if (bottomRightTile != null) {
         bottomRightTile.getBlock(0, 0).setSlopeUnknown(true);
      }

   }

   public int getSectionBasedHeight(Chunk bchunk, int startY) {
      ExtendedBlockStorage[] sections = bchunk.func_76587_i();
      int playerSection = startY >> 4;
      int result = -1;

      int i;
      ExtendedBlockStorage searchedSection;
      for(i = playerSection; i < sections.length; ++i) {
         searchedSection = sections[i];
         if (searchedSection != null) {
            result = (i << 4) + 15;
         }
      }

      if (playerSection > 0 && result == -1) {
         for(i = playerSection - 1; i >= 0; --i) {
            searchedSection = sections[i];
            if (searchedSection != null) {
               result = (i << 4) + 15;
               break;
            }
         }
      }

      return result;
   }

   public int getBiomeColor(int type, MutableBlockPos pos, MapTile tile, World world) {
      int i = 0;
      int j = 0;
      int k = 0;
      int total = 0;
      int initX = pos.func_177958_n();
      int initZ = pos.func_177952_p();
      MapBiomes mapBiomes = this.mapProcessor.getMapBiomes();

      for(int o = -1; o < 2; ++o) {
         for(int p = -1; p < 2; ++p) {
            pos.func_181079_c(initX + o, pos.func_177956_o(), initZ + p);
            int b = this.getBiomeAtPos(pos, tile);
            if (b != -1) {
               int l = false;
               BiomeGenBase gen = BiomeGenBase.func_150568_d(b);
               if (gen == null) {
                  gen = world.field_73011_w.func_177499_m().func_180300_a(pos, BiomeGenBase.field_76772_c);
                  b = gen.field_76756_M;
               }

               if (gen != null) {
                  int l;
                  if (type == 0) {
                     l = mapBiomes.getBiomeGrassColour(b, gen, pos);
                  } else if (type == 1) {
                     l = mapBiomes.getBiomeFoliageColour(b, gen, pos);
                  } else {
                     l = mapBiomes.getBiomeWaterColour(b, gen);
                  }

                  i += l >> 16 & 255;
                  j += l >> 8 & 255;
                  k += l & 255;
                  ++total;
               }
            }
         }
      }

      pos.func_181079_c(initX, pos.func_177956_o(), initZ);
      if (total == 0) {
         return -1;
      } else {
         return (i / total & 255) << 16 | (j / total & 255) << 8 | k / total & 255;
      }
   }

   public int getBiomeAtPos(net.minecraft.util.BlockPos pos, MapTile centerTile) {
      int tileX = pos.func_177958_n() >> 4;
      int tileZ = pos.func_177952_p() >> 4;
      MapTile tile = tileX == centerTile.getChunkX() && tileZ == centerTile.getChunkZ() ? centerTile : this.mapProcessor.getMapTile(tileX, tileZ);
      return tile != null && tile.isLoaded() ? tile.getBlock(pos.func_177958_n() & 15, pos.func_177952_p() & 15).getBiome() : -1;
   }

   public boolean isGlowing(Block b) {
      return (double)b.func_149750_m() >= 0.5D;
   }

   public boolean shouldOverlay(Block b, int lightOpacity) {
      return b instanceof BlockLiquid && lightOpacity != 255 && lightOpacity != 0 || b.func_180664_k() == EnumWorldBlockLayer.TRANSLUCENT && lightOpacity != 255 || b instanceof BlockGlass;
   }

   public boolean isInvisible(World world, IBlockState state, Block b, boolean flowers) {
      if (b.func_149645_b() == -1) {
         return true;
      } else if (b == Blocks.field_150478_aa) {
         return true;
      } else if (b == Blocks.field_150329_H) {
         return true;
      } else if (b == Blocks.field_150398_cm) {
         return true;
      } else if ((b instanceof BlockFlower || b instanceof BlockDoublePlant) && !flowers) {
         return true;
      } else {
         synchronized(this.buggedStates) {
            if (this.buggedStates.contains(state)) {
               return true;
            }
         }

         MapColor materialColor = null;

         try {
            materialColor = b.func_180659_g(state);
         } catch (Throwable var10) {
            synchronized(this.buggedStates) {
               this.buggedStates.add(state);
            }

            System.out.println("Broken vanilla map color definition found: " + b.getRegistryName());
         }

         return materialColor == null || materialColor.field_76291_p == 0;
      }
   }

   public void loadPixel(World world, MapBlock pixel, MapBlock currentPixel, Chunk bchunk, int insideX, int insideZ, int highY, int lowY, boolean cave, boolean canReuseBiomeColours, boolean flowers) {
      pixel.prepareForWriting();
      this.overlayBuilder.startBuilding();
      IBlockState prevOverlay = null;
      boolean underair = !cave;
      IBlockState opaqueState = null;
      byte workingLight = -1;
      this.mutableGlobalPos.func_181079_c((bchunk.field_76635_g << 4) + insideX, lowY - 1, (bchunk.field_76647_h << 4) + insideZ);

      int h;
      IBlockState state;
      for(h = highY; h >= lowY; --h) {
         this.mutableLocalPos.func_181079_c(insideX, h, insideZ);
         state = bchunk.func_177435_g(this.mutableLocalPos);
         if (state == null) {
            state = Blocks.field_150350_a.func_176223_P();
         }

         Block b = state.func_177230_c();
         if (b instanceof BlockAir) {
            underair = true;
         } else if (underair) {
            int stateId = Block.func_176210_f(state);
            this.mutableGlobalPos.func_181079_c(this.mutableGlobalPos.func_177958_n(), h, this.mutableGlobalPos.func_177952_p());
            this.mutableLocalPos.func_181079_c(insideX, Math.min(h + 1, 255), insideZ);
            if (!this.isInvisible(world, state, b, flowers)) {
               workingLight = (byte)bchunk.func_177413_a(EnumSkyBlock.BLOCK, this.mutableLocalPos);
               if (!this.shouldOverlay(b, b.func_149717_k())) {
                  opaqueState = state;
                  break;
               }

               this.writerBiomeInfoSupplier.set(currentPixel, canReuseBiomeColours);
               this.overlayBuilder.build(stateId, this.biomeBuffer, b.func_149717_k(), workingLight, world, this.mapProcessor, this.mutableGlobalPos, this.overlayBuilder.getOverlayBiome(), this.colorTypeCache, this.writerBiomeInfoSupplier);
            }
         }
      }

      if (h < lowY) {
         h = lowY;
      }

      state = opaqueState == null ? Blocks.field_150350_a.func_176223_P() : opaqueState;
      int stateId = Block.func_176210_f(state);
      byte light = opaqueState == null ? 0 : workingLight;
      this.overlayBuilder.finishBuilding(pixel);
      if (canReuseBiomeColours && currentPixel != null && currentPixel.getState() == stateId) {
         this.biomeBuffer[0] = currentPixel.getColourType();
         this.biomeBuffer[1] = currentPixel.getBiome();
         this.biomeBuffer[2] = currentPixel.getCustomColour();
      } else {
         this.colorTypeCache.getBlockBiomeColour(world, state, this.mutableGlobalPos, this.biomeBuffer, -1);
      }

      if (this.overlayBuilder.getOverlayBiome() != -1) {
         this.biomeBuffer[1] = this.overlayBuilder.getOverlayBiome();
      }

      boolean glowing = this.isGlowing(state.func_177230_c());
      pixel.write(stateId, h, this.biomeBuffer, light, glowing, cave);
   }

   public int loadBlockColourFromTexture(int stateId, boolean convert, net.minecraft.util.BlockPos globalPos) {
      if (this.clearCachedColours) {
         this.textureColours.clear();
         this.blockColours.clear();
         this.lastBlockStateForTextureColor = -1;
         this.lastBlockStateForTextureColorResult = -1;
         this.clearCachedColours = false;
         if (WorldMap.settings.debug) {
            System.out.println("Xaero's World Map cache cleared!");
         }
      }

      if (stateId == this.lastBlockStateForTextureColor) {
         return this.lastBlockStateForTextureColorResult;
      } else {
         Integer c = (Integer)this.blockColours.get(stateId);
         int red = false;
         int green = false;
         int blue = false;
         IBlockState state = Misc.getStateById(stateId);
         Block b = state.func_177230_c();
         if (c == null) {
            TextureAtlasSprite texture = Minecraft.func_71410_x().func_175602_ab().func_175023_a().func_178122_a(Block.func_176220_d(stateId));
            String name = null;
            boolean passedPropertyCheck = false;

            try {
               if (texture == null) {
                  throw new SilentException("Null texture " + state);
               }

               if (state instanceof IExtendedBlockState) {
                  ResourceLocation blockResource = (ResourceLocation)Block.field_149771_c.func_177774_c(b);
                  if (blockResource == null || !blockResource.func_110624_b().equals("minecraft")) {
                     ImmutableMap<IUnlistedProperty<?>, Optional<?>> properties = ((IExtendedBlockState)state).getUnlistedProperties();
                     UnmodifiableIterator var15 = properties.keySet().iterator();

                     while(var15.hasNext()) {
                        IUnlistedProperty<?> p = (IUnlistedProperty)var15.next();
                        ((Optional)properties.get(p)).get();
                     }
                  }
               }

               passedPropertyCheck = true;
               name = texture.func_94215_i() + ".png";
               if (b instanceof BlockGrass) {
                  name = "minecraft:blocks/grass_top.png";
               } else if (b == Blocks.field_150419_aX) {
                  name = "minecraft:blocks/mushroom_block_skin_red.png";
               } else if (b == Blocks.field_150420_aW) {
                  name = "minecraft:blocks/mushroom_block_skin_brown.png";
               } else if (b instanceof BlockOre && b != Blocks.field_150449_bY) {
                  name = "minecraft:blocks/stone.png";
               }

               if (convert) {
                  name = name.replaceAll("_side", "_top").replaceAll("_front.png", "_top.png");
               }

               c = -1;
               String[] args = name.split(":");
               if (args.length < 2) {
                  DEFAULT_RESOURCE[1] = args[0];
                  args = DEFAULT_RESOURCE;
               }

               Integer cachedColour = (Integer)this.textureColours.get(name);
               if (cachedColour == null) {
                  ResourceLocation location = new ResourceLocation(args[0], "textures/" + args[1]);
                  IResource resource = Minecraft.func_71410_x().func_110442_L().func_110536_a(location);
                  if (resource == null) {
                     throw new SilentException("No texture " + location);
                  }

                  InputStream input = resource.func_110527_b();
                  BufferedImage img = TextureUtil.func_177053_a(input);
                  int red = 0;
                  int green = 0;
                  int blue = 0;
                  int total = 0;
                  int ts = Math.min(img.getWidth(), img.getHeight());
                  if (ts > 0) {
                     int diff = Math.max(1, Math.min(4, ts / 8));
                     int parts = ts / diff;
                     Raster raster = img.getData();
                     int[] colorHolder = null;

                     for(int i = 0; i < parts; ++i) {
                        for(int j = 0; j < parts; ++j) {
                           int rgb;
                           int sample;
                           if (img.getColorModel().getNumComponents() < 3) {
                              colorHolder = raster.getPixel(i * diff, j * diff, colorHolder);
                              sample = colorHolder[0] & 255;
                              int a = 255;
                              if (colorHolder.length > 1) {
                                 a = colorHolder[1];
                              }

                              rgb = a << 24 | sample << 16 | sample << 8 | sample;
                           } else {
                              rgb = img.getRGB(i * diff, j * diff);
                           }

                           sample = rgb >> 24 & 255;
                           if (rgb != 0 && sample != 0) {
                              red += rgb >> 16 & 255;
                              green += rgb >> 8 & 255;
                              blue += rgb & 255;
                              ++total;
                           }
                        }
                     }
                  }

                  input.close();
                  if (total == 0) {
                     total = 1;
                  }

                  red /= total;
                  green /= total;
                  blue /= total;
                  if (convert && red == 0 && green == 0 && blue == 0) {
                     throw new SilentException("Black texture " + ts);
                  }

                  c = -16777216 | red << 16 | green << 8 | blue;
                  this.textureColours.put(name, c);
               } else {
                  c = cachedColour;
               }
            } catch (FileNotFoundException var30) {
               if (convert) {
                  return this.loadBlockColourFromTexture(stateId, false, globalPos);
               }

               System.out.println("Block file not found: " + b.func_149732_F());
               c = 0;
               if (b.func_180659_g(state) != null) {
                  c = b.func_180659_g(state).field_76291_p;
               }

               if (name != null) {
                  this.textureColours.put(name, c);
               }
            } catch (Exception var31) {
               System.out.println("Exception when loading " + b.func_149732_F() + " texture, using material colour.");
               c = 0;
               if (b.func_180659_g(state) != null) {
                  c = b.func_180659_g(state).field_76291_p;
               }

               if (name != null) {
                  this.textureColours.put(name, c);
               }

               if (var31 instanceof NoSuchElementException && !passedPropertyCheck) {
                  System.out.println("Didn't pass the unlisted property check.");
               } else if (var31 instanceof SilentException) {
                  System.out.println(var31.getMessage());
               } else {
                  var31.printStackTrace();
               }
            }

            if (c != null) {
               this.blockColours.put(stateId, c);
            }
         }

         this.lastBlockStateForTextureColor = stateId;
         this.lastBlockStateForTextureColorResult = c;
         return c;
      }
   }

   public long getUpdateCounter() {
      return this.updateCounter;
   }

   public void resetPosition() {
      this.X = 0;
      this.Z = 0;
      this.insideX = 0;
      this.insideZ = 0;
   }

   public void requestCachedColoursClear() {
      this.clearCachedColours = true;
   }

   public BlockStateColorTypeCache getColorTypeCache() {
      return this.colorTypeCache;
   }

   public void setMapProcessor(MapProcessor mapProcessor) {
      this.mapProcessor = mapProcessor;
   }

   public void setDirtyInWriteDistance(EntityPlayer player, World level) {
      int writeDistance = this.getWriteDistance();
      int playerChunkX = player.func_180425_c().func_177958_n() >> 4;
      int playerChunkZ = player.func_180425_c().func_177952_p() >> 4;
      int startChunkX = playerChunkX - writeDistance;
      int startChunkZ = playerChunkZ - writeDistance;
      int endChunkX = playerChunkX + writeDistance;
      int endChunkZ = playerChunkZ + writeDistance;

      for(int x = startChunkX; x < endChunkX; ++x) {
         for(int z = startChunkZ; z < endChunkZ; ++z) {
            Chunk chunk = level.func_72964_e(x, z);
            if (chunk != null) {
               try {
                  XaeroWorldMapCore.chunkCleanField.set(chunk, false);
               } catch (IllegalAccessException | IllegalArgumentException var14) {
                  throw new RuntimeException(var14);
               }
            }
         }
      }

   }
}
