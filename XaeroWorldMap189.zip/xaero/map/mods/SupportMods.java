package xaero.map.mods;

public class SupportMods {
   public static SupportXaeroMinimap xaeroMinimap = null;
   public static boolean vivecraft;

   public static boolean minimap() {
      return xaeroMinimap != null && xaeroMinimap.modMain != null;
   }

   public static void load() {
      Class optifineClassTest;
      try {
         optifineClassTest = Class.forName("xaero.common.IXaeroMinimap");
         xaeroMinimap = new SupportXaeroMinimap();
      } catch (ClassNotFoundException var2) {
      }

      try {
         optifineClassTest = Class.forName("org.vivecraft.gameplay.OpenVRPlayer");
         vivecraft = true;
         System.out.println("Vivecraft!");
      } catch (ClassNotFoundException var1) {
         vivecraft = false;
         System.out.println("No Vivecraft!");
      }

   }
}
