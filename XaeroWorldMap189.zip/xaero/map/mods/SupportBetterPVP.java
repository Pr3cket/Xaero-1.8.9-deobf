package xaero.map.mods;

import xaero.common.IXaeroMinimap;
import xaero.pvp.BetterPVP;

public class SupportBetterPVP {
   public static IXaeroMinimap getMain() {
      return BetterPVP.instance;
   }
}
