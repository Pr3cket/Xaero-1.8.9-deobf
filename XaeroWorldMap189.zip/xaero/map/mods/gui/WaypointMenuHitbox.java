package xaero.map.mods.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class WaypointMenuHitbox extends WaypointMenuElement {
   private int x;
   private int y;
   private int w;
   private int h;

   public WaypointMenuHitbox(int x, int y, int w, int h) {
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
   }

   public void setY(int y) {
      this.y = y;
   }

   public void setH(int h) {
      this.h = h;
   }

   public int getLeftSideLength(Minecraft mc) {
      return 0;
   }

   public void renderInMenu(GuiScreen gui, int x, int y, int mouseX, int mouseY, double scale, boolean enabled, boolean hovered, Minecraft mc, boolean pressed) {
   }

   public boolean isMouseOverElement(int menuX, int menuY, int mouseX, int mouseY, Minecraft mc) {
      int hitboxMinX = menuX + this.x;
      int hitboxMinY = menuY + this.y;
      int hitboxMaxX = hitboxMinX + this.w;
      int hitboxMaxY = hitboxMinY + this.h;
      return mouseX >= hitboxMinX && mouseX < hitboxMaxX && mouseY >= hitboxMinY && mouseY < hitboxMaxY;
   }
}
