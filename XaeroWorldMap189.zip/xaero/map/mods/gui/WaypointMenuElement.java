package xaero.map.mods.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public abstract class WaypointMenuElement {
   public abstract int getLeftSideLength(Minecraft var1);

   public abstract void renderInMenu(GuiScreen var1, int var2, int var3, int var4, int var5, double var6, boolean var8, boolean var9, Minecraft var10, boolean var11);

   public boolean isMouseOverElement(int x, int y, int mouseX, int mouseY, Minecraft mc) {
      int topEdge = y - 8;
      if (mouseY < topEdge) {
         return false;
      } else {
         int bottomEdge = y + 8;
         if (mouseY >= bottomEdge) {
            return false;
         } else {
            int rightEdge = x + 5;
            if (mouseX >= rightEdge) {
               return false;
            } else {
               int leftEdge = x - this.getLeftSideLength(mc);
               return mouseX >= leftEdge;
            }
         }
      }
   }
}
