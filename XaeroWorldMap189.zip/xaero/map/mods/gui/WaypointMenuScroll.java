package xaero.map.mods.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;

public class WaypointMenuScroll extends WaypointMenuElement {
   private String name;
   private String icon;
   private int direction;
   private long lastScroll;

   public WaypointMenuScroll(String name, String icon, int direction) {
      this.name = name;
      this.icon = icon;
      this.direction = direction;
   }

   public int getLeftSideLength(Minecraft mc) {
      return 9 + mc.field_71466_p.func_78256_a(I18n.func_135052_a(this.name, new Object[0]));
   }

   public void renderInMenu(GuiScreen gui, int x, int y, int mouseX, int mouseY, double scale, boolean enabled, boolean hovered, Minecraft mc, boolean pressed) {
      GlStateManager.func_179094_E();
      if (enabled && hovered) {
         GlStateManager.func_179109_b(pressed ? 1.0F : 2.0F, 0.0F, 0.0F);
      }

      GlStateManager.func_179109_b((float)x, (float)y, 0.0F);
      if (enabled) {
         GlStateManager.func_179139_a(scale, scale, 1.0D);
      }

      GlStateManager.func_179109_b(-4.0F, -4.0F, 0.0F);
      GlStateManager.func_179147_l();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      int color = enabled ? -1 : -11184811;
      mc.field_71466_p.func_175063_a(this.icon, (float)(5 - mc.field_71466_p.func_78256_a(this.icon) / 2), 1.0F, color);
      String name = I18n.func_135052_a(this.name, new Object[0]);
      int len = mc.field_71466_p.func_78256_a(name);
      mc.field_71466_p.func_175063_a(name, (float)(-3 - len), 0.0F, color);
      GlStateManager.func_179147_l();
      GlStateManager.func_179121_F();
   }

   public int getDirection() {
      return this.direction;
   }

   public int scroll() {
      long currentTime = System.currentTimeMillis();
      if (this.lastScroll != 0L && currentTime - this.lastScroll <= 100L) {
         return 0;
      } else {
         this.lastScroll = currentTime;
         return this.direction;
      }
   }

   public void onMouseRelease() {
      this.lastScroll = 0L;
   }
}
