package xaero.map.mods.gui;

import java.nio.IntBuffer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import xaero.map.WorldMap;
import xaero.map.graphics.ImprovedFramebuffer;
import xaero.map.misc.Misc;

public class WaypointSymbolCreator {
   public static final ResourceLocation minimapTextures = new ResourceLocation("xaerobetterpvp", "gui/guis.png");
   public static final int white = -1;
   private Minecraft mc = Minecraft.func_71410_x();
   private int deathSymbolTexture;
   private Map<String, Integer> charSymbols = new HashMap();
   private ImprovedFramebuffer symbolFramebuffer32;
   private ImprovedFramebuffer symbolFramebuffer64;

   public int getDeathSymbolTexture(ScaledResolution scaledRes) {
      if (this.deathSymbolTexture == 0) {
         this.createDeathSymbolTexture(scaledRes);
      }

      return this.deathSymbolTexture;
   }

   private void createDeathSymbolTexture(ScaledResolution scaledRes) {
      this.deathSymbolTexture = this.createCharSymbol(true, (String)null, scaledRes);
   }

   public int getSymbolTexture(String c, ScaledResolution scaledRes) {
      Integer textureId;
      synchronized(this.charSymbols) {
         textureId = (Integer)this.charSymbols.get(c);
      }

      if (textureId == null) {
         textureId = this.createCharSymbol(false, c, scaledRes);
      }

      return textureId;
   }

   private int createCharSymbol(boolean death, String c, ScaledResolution scaledRes) {
      if (this.symbolFramebuffer32 == null) {
         this.symbolFramebuffer32 = new ImprovedFramebuffer(32, 32, false);
      }

      if (this.symbolFramebuffer64 == null) {
         this.symbolFramebuffer64 = new ImprovedFramebuffer(64, 32, false);
      }

      int frameWidth = 32;
      if (this.mc.field_71466_p.func_78256_a(c) / 2 > 4) {
         frameWidth = 64;
      }

      ImprovedFramebuffer symbolFramebuffer = frameWidth == 32 ? this.symbolFramebuffer32 : this.symbolFramebuffer64;
      int textureId = GlStateManager.func_179146_y();
      GlStateManager.func_179144_i(textureId);
      GL11.glTexParameteri(3553, 33085, 0);
      GL11.glTexParameterf(3553, 33082, 0.0F);
      GL11.glTexParameterf(3553, 33083, 0.0F);
      GL11.glTexParameterf(3553, 34049, 0.0F);
      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
      GL11.glTexParameteri(3553, 10242, 33071);
      GL11.glTexParameteri(3553, 10243, 33071);
      GL11.glTexImage2D(3553, 0, 32856, frameWidth, 32, 0, 6408, 5121, (IntBuffer)null);
      symbolFramebuffer.func_147610_a(true);
      symbolFramebuffer.field_147617_g = textureId;
      ImprovedFramebuffer.framebufferTexture2D(symbolFramebuffer.getType(), 36160, 36064, 3553, textureId, 0);
      symbolFramebuffer.func_147606_d();
      symbolFramebuffer.func_147610_a(true);
      GlStateManager.func_179082_a(0.0F, 0.0F, 0.0F, 0.0F);
      GlStateManager.func_179086_m(16384);
      GlStateManager.func_179128_n(5889);
      GlStateManager.func_179096_D();
      GlStateManager.func_179130_a(0.0D, (double)frameWidth, 32.0D, 0.0D, -1.0D, 1000.0D);
      GlStateManager.func_179128_n(5888);
      GlStateManager.func_179094_E();
      GlStateManager.func_179096_D();
      GlStateManager.func_179109_b(1.0F, 1.0F, 0.0F);
      if (!death) {
         GlStateManager.func_179152_a(3.0F, 3.0F, 1.0F);
         this.mc.field_71466_p.func_175063_a(c, 0.0F, 0.0F, -1);
      } else {
         GlStateManager.func_179152_a(3.0F, 3.0F, 1.0F);
         GlStateManager.func_179141_d();
         this.mc.func_110434_K().func_110577_a(minimapTextures);
         GlStateManager.func_179131_c(0.2431F, 0.2431F, 0.2431F, 1.0F);
         Gui.func_146110_a(1, 1, 0.0F, 78.0F, 9, 9, 256.0F, 256.0F);
         GlStateManager.func_179131_c(0.9882F, 0.9882F, 0.9882F, 1.0F);
         Gui.func_146110_a(0, 0, 0.0F, 78.0F, 9, 9, 256.0F, 256.0F);
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      }

      GlStateManager.func_179128_n(5889);
      Misc.minecraftOrtho(scaledRes);
      GlStateManager.func_179128_n(5888);
      GlStateManager.func_179121_F();
      symbolFramebuffer.func_147609_e();
      this.mc.func_147110_a().func_147610_a(false);
      GlStateManager.func_179083_b(0, 0, this.mc.field_71443_c, this.mc.field_71440_d);
      if (death) {
         this.deathSymbolTexture = textureId;
      } else {
         this.charSymbols.put(c, textureId);
      }

      return textureId;
   }

   public void resetChars() {
      synchronized(this.charSymbols) {
         Collection<Integer> valueSet = this.charSymbols.values();
         Iterator var3 = valueSet.iterator();

         while(var3.hasNext()) {
            Integer textureId = (Integer)var3.next();
            WorldMap.glObjectDeleter.requestTextureDeletion(textureId);
         }

         this.charSymbols.clear();
      }
   }
}
