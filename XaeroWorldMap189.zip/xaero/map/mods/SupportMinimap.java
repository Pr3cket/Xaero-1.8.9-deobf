package xaero.map.mods;

import xaero.common.IXaeroMinimap;
import xaero.minimap.XaeroMinimap;

public class SupportMinimap {
   public static IXaeroMinimap getMain() {
      return XaeroMinimap.instance;
   }
}
