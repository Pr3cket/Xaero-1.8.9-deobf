package xaero.map.mods;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.opengl.GL11;
import xaero.common.IXaeroMinimap;
import xaero.common.XaeroMinimapSession;
import xaero.common.effect.Effects;
import xaero.common.gui.GuiAddWaypoint;
import xaero.common.gui.GuiWaypoints;
import xaero.common.minimap.waypoints.WaypointSet;
import xaero.common.minimap.waypoints.WaypointWorld;
import xaero.common.minimap.waypoints.WaypointWorldContainer;
import xaero.common.minimap.waypoints.WaypointsManager;
import xaero.common.mods.SupportXaeroWorldmap;
import xaero.common.settings.ModSettings;
import xaero.map.WorldMap;
import xaero.map.gui.GuiDropDown;
import xaero.map.gui.GuiMap;
import xaero.map.misc.KeySortableByOther;
import xaero.map.misc.Misc;
import xaero.map.mods.gui.Waypoint;
import xaero.map.mods.gui.WaypointMenuElement;
import xaero.map.mods.gui.WaypointMenuRenderer;
import xaero.map.mods.gui.WaypointSymbolCreator;

public class SupportXaeroMinimap {
   IXaeroMinimap modMain;
   public int compatibilityVersion;
   private boolean deathpoints = true;
   private boolean refreshWaypoints = true;
   private WaypointWorld waypointWorld;
   private WaypointSet waypointSet;
   private boolean allSets;
   private ArrayList<Waypoint> waypoints;
   private ArrayList<Waypoint> waypointsSorted;
   private ArrayList<Waypoint> waypointsFiltered;
   private WaypointMenuRenderer waypointMenuRenderer;

   public SupportXaeroMinimap() {
      try {
         Class mmClassTest = Class.forName("xaero.pvp.BetterPVP");
         this.modMain = SupportBetterPVP.getMain();
         System.out.println("Xaero's WorldMap Mod: Better PVP found!");
      } catch (ClassNotFoundException var5) {
         try {
            Class mmClassTest = Class.forName("xaero.minimap.XaeroMinimap");
            this.modMain = SupportMinimap.getMain();
            System.out.println("Xaero's WorldMap Mod: Xaero's minimap found!");
         } catch (ClassNotFoundException var4) {
         }
      }

      if (this.modMain != null) {
         try {
            this.compatibilityVersion = SupportXaeroWorldmap.WORLDMAP_COMPATIBILITY_VERSION;
         } catch (NoSuchFieldError var3) {
         }

         if (this.compatibilityVersion < 3) {
            throw new RuntimeException("Xaero's Minimap 20.23.0 or newer required!");
         }
      }

   }

   public boolean waypointIsGood(Waypoint w) {
      return w.getType() != 1 || this.deathpoints;
   }

   public ArrayList<Waypoint> convertWaypoints() {
      if (this.waypointSet == null) {
         return null;
      } else {
         ArrayList<Waypoint> result = new ArrayList();
         if (!this.allSets) {
            this.convertSet(this.waypointSet, result);
         } else {
            HashMap<String, WaypointSet> sets = this.waypointWorld.getSets();
            Iterator var3 = sets.values().iterator();

            while(var3.hasNext()) {
               WaypointSet set = (WaypointSet)var3.next();
               this.convertSet(set, result);
            }
         }

         this.deathpoints = this.modMain.getSettings().getDeathpoints();
         return result;
      }
   }

   private void convertSet(WaypointSet set, ArrayList<Waypoint> result) {
      ArrayList<xaero.common.minimap.waypoints.Waypoint> list = set.getList();
      String setName = set.getName();

      for(int i = 0; i < list.size(); ++i) {
         xaero.common.minimap.waypoints.Waypoint w = (xaero.common.minimap.waypoints.Waypoint)list.get(i);
         result.add(this.convertWaypoint(w, true, setName));
      }

   }

   public Waypoint convertWaypoint(xaero.common.minimap.waypoints.Waypoint w, boolean editable, String setName) {
      Waypoint converted = new Waypoint(w, w.getX(), w.getY(), w.getZ(), w.getName(), w.getSymbol(), ModSettings.COLORS[w.getColor()], w.getType(), editable, setName);
      converted.setDisabled(w.isDisabled());
      converted.setYaw(w.getYaw());
      converted.setRotation(w.isRotation());
      converted.setTemporary(w.isTemporary());
      converted.setGlobal(w.isGlobal());
      return converted;
   }

   public void openWaypoint(GuiMap parent, Waypoint waypoint) {
      if (waypoint.isEditable()) {
         XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
         GuiAddWaypoint addScreen;
         if (this.compatibilityVersion >= 6) {
            addScreen = new GuiAddWaypoint(this.modMain, minimapSession.getWaypointsManager(), parent, parent, (xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal(), this.waypointWorld.getContainer().getRootContainer().getKey(), this.waypointWorld, waypoint.getSetName());
         } else {
            addScreen = new GuiAddWaypoint(this.modMain, minimapSession.getWaypointsManager(), parent, (xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal(), this.waypointWorld.getContainer().getRootContainer().getKey(), this.waypointWorld);
         }

         Minecraft.func_71410_x().func_147108_a(addScreen);
      }
   }

   public void createWaypoint(GuiMap parent, int x, int y, int z) {
      if (this.waypointWorld != null) {
         XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
         WaypointsManager waypointsManager = minimapSession.getWaypointsManager();
         double dimDiv;
         if (this.compatibilityVersion < 2) {
            dimDiv = waypointsManager.divideBy8(this.waypointWorld.getContainer().getKey()) ? 8.0D : 1.0D;
         } else {
            dimDiv = waypointsManager.getDimensionDivision(this.waypointWorld.getContainer().getKey());
         }

         xaero.common.minimap.waypoints.Waypoint w = new xaero.common.minimap.waypoints.Waypoint(Misc.myFloor((double)x * dimDiv), y, Misc.myFloor((double)z * dimDiv), "", "", -1);
         GuiAddWaypoint addScreen;
         if (this.compatibilityVersion >= 6) {
            addScreen = new GuiAddWaypoint(this.modMain, minimapSession.getWaypointsManager(), parent, parent, w, this.waypointWorld.getContainer().getRootContainer().getKey(), this.waypointWorld, this.waypointWorld.getCurrent());
         } else {
            addScreen = new GuiAddWaypoint(this.modMain, minimapSession.getWaypointsManager(), parent, w, this.waypointWorld.getContainer().getRootContainer().getKey(), this.waypointWorld);
         }

         Minecraft.func_71410_x().func_147108_a(addScreen);
      }
   }

   public void createTempWaypoint(int x, int y, int z) {
      if (this.waypointWorld != null) {
         XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
         WaypointsManager waypointsManager = minimapSession.getWaypointsManager();
         waypointsManager.createTemporaryWaypoints(this.waypointWorld, x, y, z);
         this.requestWaypointsRefresh();
      }
   }

   public boolean canTeleport() {
      XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
      WaypointsManager waypointsManager = minimapSession.getWaypointsManager();
      return this.waypointWorld != null && waypointsManager.canTeleport(waypointsManager.isWorldTeleportable(this.waypointWorld), this.waypointWorld);
   }

   public void teleportToWaypoint(GuiScreen screen, Waypoint w) {
      if (this.waypointWorld != null) {
         XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
         WaypointsManager waypointsManager = minimapSession.getWaypointsManager();
         waypointsManager.teleportToWaypoint((xaero.common.minimap.waypoints.Waypoint)w.getOriginal(), this.waypointWorld, screen);
      }
   }

   public void disableWaypoint(Waypoint waypoint) {
      ((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).setDisabled(!((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).isDisabled());

      try {
         this.modMain.getSettings().saveWaypoints(this.waypointWorld);
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      waypoint.setDisabled(((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).isDisabled());
      waypoint.setTemporary(((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).isTemporary());
   }

   public void deleteWaypoint(Waypoint waypoint) {
      if (!this.allSets) {
         this.waypointSet.getList().remove((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal());
      } else {
         HashMap<String, WaypointSet> sets = this.waypointWorld.getSets();
         Iterator var3 = sets.values().iterator();

         while(var3.hasNext()) {
            WaypointSet set = (WaypointSet)var3.next();
            if (set.getList().remove((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal())) {
               break;
            }
         }
      }

      try {
         this.modMain.getSettings().saveWaypoints(this.waypointWorld);
      } catch (IOException var5) {
         var5.printStackTrace();
      }

      this.waypoints.remove(waypoint);
      this.waypointsSorted.remove(waypoint);
      this.waypointsFiltered.remove(waypoint);
   }

   public boolean isOnScreen(Waypoint w, double cameraX, double cameraZ, int width, int height, double scale) {
      double xOnScreen = ((double)w.getX() - cameraX) * scale + (double)(width / 2);
      double zOnScreen = ((double)w.getZ() - cameraZ) * scale + (double)(height / 2);
      return xOnScreen < (double)width && xOnScreen > 0.0D && zOnScreen < (double)height && zOnScreen > 0.0D;
   }

   public void checkWaypoints(boolean multiplayer, int dimId, String multiworldId, int width, int height, GuiMap screen, Pattern regex, Pattern regexStartsWith) {
      XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
      WaypointsManager waypointsManager = minimapSession.getWaypointsManager();
      String containerId = waypointsManager.getAutoRootContainerID() + "/" + waypointsManager.getDimensionDirectoryName(dimId);
      WaypointWorldContainer container = waypointsManager.getWorldContainerNullable(containerId);
      WaypointWorld checkingWaypointWorld = container == null ? null : (WaypointWorld)container.worlds.get(!multiplayer ? "waypoints" : multiworldId);
      Minecraft mc = Minecraft.func_71410_x();
      if (this.compatibilityVersion >= 4 && mc.field_71439_g.func_70644_a(Effects.NO_WAYPOINTS)) {
         checkingWaypointWorld = null;
      } else if (this.compatibilityVersion >= 5 && (mc.field_71439_g.func_70644_a(Effects.NO_WAYPOINTS_BENEFICIAL) || mc.field_71439_g.func_70644_a(Effects.NO_WAYPOINTS_HARMFUL))) {
         checkingWaypointWorld = null;
      }

      boolean shouldRefresh = this.refreshWaypoints;
      if (checkingWaypointWorld != this.waypointWorld) {
         this.waypointWorld = checkingWaypointWorld;
         screen.closeRightClick();
         if (screen.waypointMenu) {
            screen.func_146280_a(Minecraft.func_71410_x(), width, height);
         }

         shouldRefresh = true;
      }

      WaypointSet checkingSet = checkingWaypointWorld == null ? null : checkingWaypointWorld.getCurrentSet();
      if (checkingSet != this.waypointSet) {
         this.waypointSet = checkingSet;
         shouldRefresh = true;
      }

      if (this.allSets != this.modMain.getSettings().renderAllSets) {
         this.allSets = this.modMain.getSettings().renderAllSets;
         shouldRefresh = true;
      }

      if (shouldRefresh) {
         this.waypoints = this.convertWaypoints();
         if (this.waypoints == null) {
            this.waypointsSorted = null;
         } else {
            Collections.sort(this.waypoints);
            this.waypointsSorted = new ArrayList();
            ArrayList<KeySortableByOther<Waypoint>> sortingList = new ArrayList();
            Iterator var18 = this.waypoints.iterator();

            while(var18.hasNext()) {
               Waypoint w = (Waypoint)var18.next();
               sortingList.add(new KeySortableByOther(w, new Comparable[]{w.getComparisonName(), w.getName()}));
            }

            Collections.sort(sortingList);
            var18 = sortingList.iterator();

            while(var18.hasNext()) {
               KeySortableByOther<Waypoint> e = (KeySortableByOther)var18.next();
               this.waypointsSorted.add(e.getKey());
            }
         }

         this.updateFilteredList(regex, regexStartsWith);
      }

      this.refreshWaypoints = false;
   }

   public void updateFilteredList(Pattern regex, Pattern regexStartsWith) {
      if (this.waypointsSorted == null) {
         this.waypointsFiltered = null;
      } else {
         if (this.waypointsFiltered == null) {
            this.waypointsFiltered = new ArrayList();
         } else {
            this.waypointsFiltered.clear();
         }

         boolean showingDisabled = WorldMap.settings.showDisabledWaypoints;
         Iterator var4 = this.waypointsSorted.iterator();

         while(true) {
            Waypoint w;
            do {
               if (!var4.hasNext()) {
                  return;
               }

               w = (Waypoint)var4.next();
            } while(!showingDisabled && w.isDisabled());

            if (regex == null) {
               this.waypointsFiltered.add(w);
            } else if (regexStartsWith.matcher(w.getName().toLowerCase()).find()) {
               this.waypointsFiltered.add(0, w);
            } else if (regex.matcher(w.getName().toLowerCase()).find()) {
               this.waypointsFiltered.add(w);
            }
         }
      }
   }

   public Waypoint renderWaypoints(GuiScreen gui, double cameraX, double cameraZ, int width, int height, double guiBasedScale, double scale, double mouseX, double mouseZ, Pattern regex, Pattern regexStartsWith, float brightness, Waypoint oldViewed, Minecraft mc, ScaledResolution scaledRes) {
      if (this.waypoints == null) {
         return null;
      } else {
         boolean renderBackgrounds = WorldMap.settings.waypointBackgrounds;
         Waypoint viewed = null;
         TextureManager textureManager = mc.func_110434_K();
         FontRenderer fontRenderer = mc.field_71466_p;
         WaypointSymbolCreator symbolCreator = WorldMap.waypointSymbolCreator;
         textureManager.func_110577_a(WorldMap.guiTextures);
         GL11.glTexParameteri(3553, 10241, 9729);
         GL11.glTexParameteri(3553, 10240, 9729);
         double wpScale = guiBasedScale * (double)WorldMap.settings.worldmapWaypointsScale / scale;
         boolean showingHiddenWaypoints = WorldMap.settings.showDisabledWaypoints;
         double cursorHitMinY = (double)(renderBackgrounds ? -41 : -12) * wpScale;
         double cursorHitMaxY = (double)(renderBackgrounds ? 0 : 12) * wpScale;

         for(int i = this.waypoints.size() - 1; i >= 0; --i) {
            Waypoint w = (Waypoint)this.waypoints.get(i);
            if (this.waypointIsGood(w) && (showingHiddenWaypoints || !w.isDisabled()) && (double)w.getZ() + cursorHitMaxY > mouseZ && (double)w.getZ() + cursorHitMinY < mouseZ && Math.abs((double)w.getX() - mouseX) <= (double)(w.getSymbol().length() > 1 ? 20.5F : 14.0F) * wpScale) {
               viewed = w;
               break;
            }
         }

         Waypoint viewedToReturn = viewed;
         if (viewed == null) {
            viewed = oldViewed;
         }

         Waypoint w;
         Iterator var38;
         if (renderBackgrounds) {
            var38 = this.waypoints.iterator();

            label88:
            while(true) {
               do {
                  do {
                     if (!var38.hasNext()) {
                        break label88;
                     }

                     w = (Waypoint)var38.next();
                  } while(!this.waypointIsGood(w));
               } while(!showingHiddenWaypoints && w.isDisabled());

               if (this.isOnScreen(w, cameraX, cameraZ, width, height, scale)) {
                  w.renderShadow(brightness, gui, wpScale, (float)((double)w.getX() - cameraX), (float)((double)w.getZ() - cameraZ), textureManager);
               }
            }
         }

         var38 = this.waypoints.iterator();

         while(true) {
            do {
               do {
                  if (!var38.hasNext()) {
                     if (viewed != null) {
                        viewed.renderWaypoint(gui, wpScale, (float)((double)viewed.getX() - cameraX), (float)((double)viewed.getZ() - cameraZ), true, textureManager, fontRenderer, symbolCreator, true, scaledRes);
                     }

                     Minecraft.func_71410_x().func_110434_K().func_110577_a(WorldMap.guiTextures);
                     GL11.glTexParameteri(3553, 10241, 9728);
                     GL11.glTexParameteri(3553, 10240, 9728);
                     return viewedToReturn;
                  }

                  w = (Waypoint)var38.next();
               } while(!this.waypointIsGood(w));
            } while(!showingHiddenWaypoints && w.isDisabled());

            if (w != viewed && this.isOnScreen(w, cameraX, cameraZ, width, height, scale)) {
               w.renderWaypoint(gui, wpScale, (float)((double)w.getX() - cameraX), (float)((double)w.getZ() - cameraZ), false, textureManager, fontRenderer, symbolCreator, renderBackgrounds, scaledRes);
            }
         }
      }
   }

   public WaypointMenuElement renderWaypointsMenu(GuiMap gui, ArrayList<Waypoint> sideWaypoints, double scale, int width, int height, int offset, int mouseX, int mouseY, boolean leftMousePressed, boolean leftMouseClicked, Minecraft mc) {
      return this.waypointMenuRenderer.renderWaypointsMenu(gui, sideWaypoints, scale, width, height, offset, mouseX, mouseY, leftMousePressed, leftMouseClicked, mc);
   }

   public void requestWaypointsRefresh() {
      this.refreshWaypoints = true;
   }

   public KeyBinding getWaypointKeyBinding() {
      return ModSettings.newWaypoint;
   }

   public KeyBinding getTempWaypointKeyBinding() {
      return ModSettings.keyInstantWaypoint;
   }

   public KeyBinding getTempWaypointsMenuKeyBinding() {
      return ModSettings.keyWaypoints;
   }

   public void onMapKeyPressed(boolean mouse, int code, GuiMap screen) {
      KeyBinding kb = null;
      if (Misc.inputMatchesKeyBinding(mouse, code, ModSettings.keySwitchSet)) {
         kb = ModSettings.keySwitchSet;
      }

      if (Misc.inputMatchesKeyBinding(mouse, code, ModSettings.keyAllSets)) {
         kb = ModSettings.keyAllSets;
      }

      if (Misc.inputMatchesKeyBinding(mouse, code, ModSettings.keyWaypoints)) {
         kb = ModSettings.keyWaypoints;
      }

      KeyBinding minimapSettingsKB = (KeyBinding)this.modMain.getSettingsKey();
      if (Misc.inputMatchesKeyBinding(mouse, code, minimapSettingsKB)) {
         kb = minimapSettingsKB;
      }

      Minecraft mc = Minecraft.func_71410_x();
      if (kb != null) {
         if (kb == ModSettings.keyWaypoints) {
            this.openWaypointsMenu(mc, screen);
            return;
         }

         if (minimapSettingsKB != null && kb == minimapSettingsKB) {
            this.openSettings(mc, screen, screen);
            return;
         }

         this.handleMinimapKeyBinding(kb, screen);
      }

   }

   public void handleMinimapKeyBinding(KeyBinding kb, GuiMap screen) {
      XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
      minimapSession.getControls().keyDown(kb, false, false);
      if ((kb == ModSettings.keySwitchSet || kb == ModSettings.keyAllSets) && screen.waypointMenu) {
         screen.func_146280_a(Minecraft.func_71410_x(), screen.field_146294_l, screen.field_146295_m);
      }

   }

   public void drawSetChange(ScaledResolution resolution) {
      XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
      this.modMain.getInterfaces().getMinimapInterface().getWaypointsGuiRenderer().drawSetChange(minimapSession.getWaypointsManager(), resolution);
   }

   public float getMinimapBrightnessOldCompatibility() {
      return this.modMain.getSupportMods().worldmapSupport.getMinimapBrightness();
   }

   public void openSettings(Minecraft mc, GuiScreen current, GuiScreen escape) {
      if (this.compatibilityVersion >= 6) {
         this.modMain.getGuiHelper().openMinimapSettingsFromScreen(current, escape);
      } else {
         XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
         minimapSession.getControls().keyDown((KeyBinding)this.modMain.getSettingsKey(), false, false);
      }

   }

   public String getControlsTooltip() {
      return I18n.func_135052_a("gui.xaero_box_controls_minimap", new Object[]{Misc.getKeyName(ModSettings.newWaypoint), Misc.getKeyName(ModSettings.keyInstantWaypoint), Misc.getKeyName(ModSettings.keySwitchSet), Misc.getKeyName(ModSettings.keyAllSets), Misc.getKeyName(ModSettings.keyWaypoints)});
   }

   public void onMapMouseRelease(double par1, double par2, int par3) {
      this.waypointMenuRenderer.onMapMouseRelease(par1, par2, par3);
   }

   public void onMapConstruct() {
      this.waypointMenuRenderer = new WaypointMenuRenderer();
   }

   public void onMapInit(GuiMap mapScreen, List<GuiDropDown> dropdowns, Minecraft mc, int width, int height) {
      this.waypointMenuRenderer.onMapInit(mapScreen, dropdowns, mc, width, height, this.waypointWorld, this.modMain, XaeroMinimapSession.getCurrentSession());
   }

   public ArrayList<Waypoint> getWaypointsFiltered() {
      return this.waypointsFiltered;
   }

   public boolean waypointExists(Waypoint w) {
      return this.waypoints != null && this.waypoints.contains(w);
   }

   public void toggleTemporaryWaypoint(Waypoint waypoint) {
      ((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).setTemporary(!((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).isTemporary());

      try {
         this.modMain.getSettings().saveWaypoints(this.waypointWorld);
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      waypoint.setDisabled(((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).isDisabled());
      waypoint.setTemporary(((xaero.common.minimap.waypoints.Waypoint)waypoint.getOriginal()).isTemporary());
   }

   public void teleportToCoordinates(GuiMap screen, int rightClickX, int rightClickY, int rightClickZ) {
      this.teleportToWaypoint(screen, this.convertWaypoint(new xaero.common.minimap.waypoints.Waypoint(rightClickX, rightClickY, rightClickZ, "", "", -1), false, ""));
   }

   public void openWaypointsMenu(Minecraft mc, GuiMap screen) {
      XaeroMinimapSession minimapSession = XaeroMinimapSession.getCurrentSession();
      if (this.compatibilityVersion >= 6) {
         mc.func_147108_a(new GuiWaypoints(this.modMain, minimapSession, screen, screen));
      } else {
         mc.func_147108_a(new GuiWaypoints(this.modMain, minimapSession, screen));
      }

   }

   public boolean screenShouldSkipWorldRender(GuiScreen currentScreen) {
      return this.compatibilityVersion < 6 ? false : xaero.common.misc.Misc.screenShouldSkipWorldRender(this.modMain, currentScreen, false);
   }

   public boolean hidingWaypointCoordinates() {
      return this.modMain.getSettings().hideWaypointCoordinates;
   }
}
