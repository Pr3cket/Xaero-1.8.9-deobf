package xaero.map.controls;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import xaero.map.MapProcessor;
import xaero.map.WorldMap;
import xaero.map.WorldMapSession;
import xaero.map.gui.GuiMap;
import xaero.map.gui.GuiWorldMapSettings;

public class ControlsHandler {
   private MapProcessor mapProcessor;
   private ArrayList<KeyEvent> keyEvents = new ArrayList();
   private ArrayList<KeyEvent> oldKeyEvents = new ArrayList();

   public ControlsHandler(MapProcessor mapProcessor) {
      this.mapProcessor = mapProcessor;
   }

   public static void setKeyState(KeyBinding kb, boolean pressed) {
      if (kb.func_151470_d() != pressed) {
         KeyBinding.func_74510_a(kb.func_151463_i(), pressed);
      }

   }

   public static boolean isDown(KeyBinding kb) {
      return GameSettings.func_100015_a(kb);
   }

   public static boolean isKeyRepeat(KeyBinding kb) {
      return kb != ControlsRegister.keyOpenMap && kb != ControlsRegister.keyOpenSettings;
   }

   public void keyDown(KeyBinding kb, boolean tickEnd, boolean isRepeat) {
      Minecraft mc = Minecraft.func_71410_x();
      if (!tickEnd) {
         if (kb == ControlsRegister.keyOpenMap) {
            mc.func_147108_a(new GuiMap((GuiScreen)null, (GuiScreen)null, this.mapProcessor, mc.func_175606_aa()));
         } else if (kb == ControlsRegister.keyOpenSettings) {
            mc.func_147108_a(new GuiWorldMapSettings());
         } else if (kb == ControlsRegister.keyQuickConfirm) {
            WorldMapSession worldmapSession = WorldMapSession.getCurrentSession();
            MapProcessor mapProcessor = worldmapSession.getMapProcessor();
            mapProcessor.quickConfirmMultiworld();
         }
      }

   }

   public void keyUp(KeyBinding kb, boolean tickEnd) {
      if (!tickEnd) {
      }

   }

   public void handleKeyEvents() {
      Minecraft mc = Minecraft.func_71410_x();
      this.onKeyInput(mc);

      int i;
      KeyEvent ke;
      for(i = 0; i < this.keyEvents.size(); ++i) {
         ke = (KeyEvent)this.keyEvents.get(i);
         if (mc.field_71462_r == null) {
            this.keyDown(ke.getKb(), ke.isTickEnd(), ke.isRepeat());
         }

         if (!ke.isRepeat()) {
            if (!this.oldEventExists(ke.getKb())) {
               this.oldKeyEvents.add(ke);
            }

            this.keyEvents.remove(i);
            --i;
         } else if (!isDown(ke.getKb())) {
            this.keyUp(ke.getKb(), ke.isTickEnd());
            this.keyEvents.remove(i);
            --i;
         }
      }

      for(i = 0; i < this.oldKeyEvents.size(); ++i) {
         ke = (KeyEvent)this.oldKeyEvents.get(i);
         if (!isDown(ke.getKb())) {
            this.keyUp(ke.getKb(), ke.isTickEnd());
            this.oldKeyEvents.remove(i);
            --i;
         }
      }

   }

   public void onKeyInput(Minecraft mc) {
      List<KeyBinding> kbs = WorldMap.controlsRegister.keybindings;

      for(int i = 0; i < kbs.size(); ++i) {
         KeyBinding kb = (KeyBinding)kbs.get(i);

         try {
            boolean pressed = kb.func_151468_f();

            while(kb.func_151468_f()) {
            }

            if (Minecraft.func_71410_x().field_71462_r == null && !this.eventExists(kb) && pressed) {
               this.keyEvents.add(new KeyEvent(kb, false, isKeyRepeat(kb), true));
            }
         } catch (Exception var6) {
         }
      }

   }

   private boolean eventExists(KeyBinding kb) {
      Iterator var2 = this.keyEvents.iterator();

      KeyEvent o;
      do {
         if (!var2.hasNext()) {
            return this.oldEventExists(kb);
         }

         o = (KeyEvent)var2.next();
      } while(o.getKb() != kb);

      return true;
   }

   private boolean oldEventExists(KeyBinding kb) {
      Iterator var2 = this.oldKeyEvents.iterator();

      KeyEvent o;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         o = (KeyEvent)var2.next();
      } while(o.getKb() != kb);

      return true;
   }
}
