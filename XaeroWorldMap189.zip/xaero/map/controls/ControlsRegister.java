package xaero.map.controls;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;

public class ControlsRegister {
   public static final KeyBinding keyOpenMap = new KeyBinding("gui.xaero_open_map", 50, "Xaero's World Map");
   public static final KeyBinding keyOpenSettings = new KeyBinding("gui.xaero_open_settings", 27, "Xaero's World Map");
   public static final KeyBinding keyZoomIn = new KeyBinding("gui.xaero_map_zoom_in", 0, "Xaero's World Map");
   public static final KeyBinding keyZoomOut = new KeyBinding("gui.xaero_map_zoom_out", 0, "Xaero's World Map");
   public static final KeyBinding keyQuickConfirm = new KeyBinding("gui.xaero_quick_confirm", 54, "Xaero's World Map");
   public final List<KeyBinding> keybindings;

   public ControlsRegister() {
      this.keybindings = Lists.newArrayList(new KeyBinding[]{keyOpenMap, keyOpenSettings, keyZoomIn, keyZoomOut, keyQuickConfirm});
      Iterator var1 = this.keybindings.iterator();

      while(var1.hasNext()) {
         KeyBinding kb = (KeyBinding)var1.next();
         ClientRegistry.registerKeyBinding(kb);
      }

   }
}
