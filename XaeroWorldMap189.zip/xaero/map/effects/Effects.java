package xaero.map.effects;

import net.minecraft.potion.Potion;

public class Effects {
   public static final Potion NO_WORLD_MAP;
   public static final Potion NO_WORLD_MAP_HARMFUL;
   public static final Potion NO_WORLD_MAP_BENEFICIAL;

   static {
      NO_WORLD_MAP = new NoWorldMapEffect(WorldMapBaseEffect.EffectType.NEUTRAL);
      NO_WORLD_MAP_HARMFUL = new NoWorldMapEffect(WorldMapBaseEffect.EffectType.HARMFUL);
      NO_WORLD_MAP_BENEFICIAL = new NoWorldMapEffect(WorldMapBaseEffect.EffectType.BENEFICIAL);
   }
}
