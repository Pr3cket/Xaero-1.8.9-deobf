package xaero.map.effects;

public class NoWorldMapEffect extends WorldMapEffect {
   protected NoWorldMapEffect(WorldMapBaseEffect.EffectType type) {
      super(type, -16777216, "no_world_map");
   }
}
