package xaero.map.effects;

import net.minecraft.util.ResourceLocation;

public class WorldMapEffect extends WorldMapBaseEffect {
   protected WorldMapEffect(WorldMapBaseEffect.EffectType type, int liquidColorIn, String idPrefix) {
      super(type, liquidColorIn, new ResourceLocation("xaeroworldmap", idPrefix + (type == WorldMapBaseEffect.EffectType.BENEFICIAL ? "_beneficial" : (type == WorldMapBaseEffect.EffectType.HARMFUL ? "_harmful" : ""))));
   }
}
