package xaero.map.effects;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

public class WorldMapBaseEffect extends Potion {
   private ResourceLocation iconTexture;

   public WorldMapBaseEffect(WorldMapBaseEffect.EffectType type, int liquidColorIn, ResourceLocation id) {
      super(id, type == WorldMapBaseEffect.EffectType.HARMFUL, liquidColorIn);
      this.func_76390_b("effect." + id.func_110624_b() + "." + id.func_110623_a());
      this.iconTexture = new ResourceLocation(id.func_110624_b(), "textures/mob_effect/" + id.func_110623_a() + ".png");
   }

   public void renderInventoryEffect(int x, int y, PotionEffect effect, Minecraft mc) {
      super.renderInventoryEffect(x, y, effect, mc);
      Minecraft.func_71410_x().func_110434_K().func_110577_a(this.iconTexture);
      Gui.func_146110_a(x + 6, y + 7, 0.0F, 0.0F, 18, 18, 18.0F, 18.0F);
   }

   public static enum EffectType {
      NEUTRAL,
      BENEFICIAL,
      HARMFUL;
   }
}
